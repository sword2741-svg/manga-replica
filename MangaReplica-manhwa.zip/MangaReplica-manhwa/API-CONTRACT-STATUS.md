# MangaReplica — API contract status

## Confirmed from the supplied APK (static string extraction)
- Main API host string: `https://api.mangaslayers.com`
- Config-related route string: `/source/main_source_config`
- Custom-list search route string: `/manga/custom_list_search`
- External manga-related hosts also present: `dilar.tube`, `io.lek-manga.net`,
  `s4solo.lek-manga.net`, `images.weserv.nl`, and AniList CDN.

## Not yet confirmed
The complete HTTP method, query parameters, response JSON schema, authentication
requirements, pagination rules, rate limits, and meaning of every route are not
verified. A string found in an APK is not proof that a route is publicly callable.

## Integration approach
`ApiConfig` and `MangaRemoteRepository` provide a Retrofit adapter with
configurable paths. Keep the route fields blank until the exact contract is
verified. Do not embed user passwords, session cookies, private tokens, or
third-party API keys in the APK.

## Next verification required
1. Obtain API documentation or permission to inspect the service.
2. Confirm a harmless read-only endpoint and its response shape.
3. Confirm search, details, chapter list, and page extraction separately.
4. Add typed DTOs only after the JSON schema is known.
5. Test rate-limit, unavailable-source, malformed-response, and offline cases.

## Dependencies to add to app/build.gradle.kts
```kotlin
implementation("com.squareup.retrofit2:retrofit:2.11.0")
implementation("com.squareup.retrofit2:converter-gson:2.11.0")
implementation("com.google.code.gson:gson:2.11.0")
```
