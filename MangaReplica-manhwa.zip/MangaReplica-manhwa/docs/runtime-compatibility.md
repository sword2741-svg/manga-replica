# توافق Mihon Runtime

## عقد الإضافة

يدعم TachiyomiX واجهة الإضافات 1.6 ويوثق metadata مثل `tachiyomix.extensionLib` و`tachiyomi.extension.class` [1]. يطلب من المضيف حد Android API 26 ومكتبات runtime متوافقة؛ اعتمد المشروع هذا الحد الأدنى، ويقبل حاليًا واجهات 1.4 و1.5 و1.6 فقط. كما يقيد المصادر المحملة باللغتين العربية والإنجليزية وفق نطاق التطبيق.

## الإصدارات التي حُلّت وبُنيت

- Android: `compileSdk=37`، `minSdk=26`، `targetSdk=35`.
- AGP 9.5.1، Kotlin 2.4.20، KSP 2.3.13، Gradle Wrapper 9.7.1.
- Coroutines 1.11.0، kotlinx.serialization 1.11.0، OkHttp 5.5.0، Jsoup 1.23.1، xmlutil 1.0.2، QuickJS Android 0.9.2، وInjekt من Mihon.

تطلب بيانات AAR الخاصة بـOkHttp 5.5.0 التجميع على API 37 أو أحدث؛ لذلك لا يكفي SDK 35. ثبتت منصة Android SDK 37.2 محليًا وبُني APK بنجاح على `compileSdk=37`. لا يعني ذلك تغيير حد الأجهزة المثبت عليها التطبيق: بقي `minSdk=26`، كما بقي `targetSdk=35`. تشرح وثائق Android الفرق بين SDK platform المطلوب للتجميع وصور النظام اللازمة لتشغيل المحاكي [2].

استُخدم KSP 2.3.13 بعد تعذر حل 2.4.0 من Plugin Portal أثناء التحقق. كما نُقلت إعدادات Kotlin إلى compilerOptions بما يلائم AGP 9 وKotlin المدمج [3].

## الخدمات وحقن Injekt

يسجل Mihon خدمات JSON وXML وProtoBuf وNetworkHelper ضمن ربط التطبيق [4]. أضاف MangaReplica أيضًا حقن `Context` و`Application` عند توفرها وخدمة `JavaScriptEngine` عبر QuickJS. ينشأ محرك QuickJS جديد لكل تقييم لأن الكائنات تملك موارد native وليست آمنة للمشاركة المتزامنة. ويستخدم XML إعدادًا متسامحًا مع عناصر XML غير المعروفة.

## قيود الإثبات

نجاح compilation أو parsing metadata لا يثبت تحميل DEX وتشغيل إضافة فعلية. الاختبارات هنا لا تتضمن تثبيت APK إضافة وتشغيلها على Android runtime، ولا اختبار طلبات كل مصدر أو Cloudflare. يجب الفصل بين اختبارات الوحدة وبين تحقق الجهاز/المحاكي.

## References

[1]: https://github.com/mihonapp/tachiyomix "TachiyomiX extension API repository"
[2]: https://developer.android.com/tools/releases/platforms "Android SDK Platform release information"
[3]: https://developer.android.com/build/migrate-to-built-in-kotlin "Android Gradle Plugin built-in Kotlin migration"
[4]: https://github.com/mihonapp/mihon/blob/main/app/src/main/java/mihon/app/di/AppBindings.kt "Mihon AppBindings"
