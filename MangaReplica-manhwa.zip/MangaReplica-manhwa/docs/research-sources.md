# مراجع وحقائق المصدر المتحققة

## Keiyoushi

- المستودع المنشور: [keiyoushi/extensions](https://github.com/keiyoushi/extensions)، وفرع التوزيع `repo`. تعليمات المشروع تستخدم `https://github.com/keiyoushi/extensions/raw/repo/index.pb`.
- البيانات الوصفية الحية في [`repo.json`](https://raw.githubusercontent.com/keiyoushi/extensions/repo/repo.json) تعلن اسم Keiyoushi ورابط الموقع وبصمة مفتاح التوقيع `9add655a78e96c4ec7a53ef89dccb557cb5d767489fac5e785d671a5a75d4da2`.
- صيغة `index.json` الكامل كائن يحوي `extensionList.extensions`، وسجلاته تستخدم حقولًا مثل `packageName` و`resources.apkUrl/jarUrl/iconUrl` و`extensionLib` و`versionCode` و`versionName` و`contentWarning` و` sources` (ومنها `id/name/language/homeUrl`).
- نسخة `index.min.json` التي فُحصت كانت إعلانات توافق مثل “Outdated App” و“Update to Mihon 0.20.1+”، وليست القائمة الكاملة؛ لذلك يستخدم التنفيذ `index.json` الكامل كـfallback عندما لا يحتوي Protobuf على العناصر.
- المخطط الرسمي في [`index.proto`](https://github.com/keiyoushi/extensions-source/blob/main/.github/scripts/index.proto) هو proto3. رسالة `Index` تحمل metadata وواحدًا من `ExtensionList` في الحقل 101 أو رابط قائمة بعيدة في الحقل 102. موارد الإضافة تشمل `jarUrl` بالحقل 501.
- جرى تنزيل `index.pb` الرسمي أثناء التنفيذ؛ استجاب HTTP 200 بحجم 116,259 بايت وبداية GZIP (`1f8b0800`). يتضمن الاختبار الاختياري مسارًا محليًا لاختبار مخطط الملف الحي دون شبكة في كل بناء.

## توافق إضافات Mihon وحدود التطبيق

- مصدر الشيفرة المنشور: [keiyoushi/extensions-source](https://github.com/keiyoushi/extensions-source).
- يبيّن محمّل Mihon الرسمي [ExtensionLoader](https://github.com/mihonapp/mihon/blob/main/app/src/main/java/eu/kanade/tachiyomi/extension/util/ExtensionLoader.kt) و[ExtensionManager](https://github.com/mihonapp/mihon/blob/main/app/src/main/java/eu/kanade/tachiyomi/extension/ExtensionManager.kt) أن الإضافات APK شيفرة تنفيذية، وتحتاج فحوص الثقة والتوقيع ونسخة مكتبة متوافقة وآلية تحميل Mihon الخاصة.
- واجهة Mihon [`Source`](https://github.com/mihonapp/mihon/blob/main/source-api/src/main/kotlin/eu/kanade/tachiyomi/source/Source.kt) تستخدم أنواعًا وحزمًا خاصة بها وعمليات suspend؛ وهي ليست تلقائيًا متوافقة مع عقد `MangaSource` المحلي في MangaReplica.
- نتيجة التصميم: المشروع يفك الفهرس ويتحقق من الحزمة والتوقيع ويفتح مثبت Android بعد موافقة المستخدم، لكنه **لا** يحمّل DEX ولا يشغل إضافات Mihon كمصادر داخل التطبيق. هذا الحد مقصود ومعلن في شاشة الإضافات وREADME إلى أن يُنفذ runtime متوافق وآمن.

## MangaDex

- توثيق MangaDex العام: [Swagger/API documentation](https://api.mangadex.org/docs/swagger.html) و[استرجاع صور الفصل](https://api.mangadex.org/docs/04-chapter/retrieving-chapter/).
- اختبارات الاتصال السابقة واجهت اختلاف اسم مضيف شهادة TLS في شبكة بيئة البناء؛ لا يتجاوز المشروع التحقق من الشهادات أو أسماء المضيفين.
