# حالة مصادر Keiyoushi والعربية

يعرض فهرس Keiyoushi بيانات اللغة على مستوى الحزمة والمصدر، وقد تكون الحزمة نفسها بلغة `all` مع احتوائها مصدرًا عربيًا. لذلك يفحص MangaReplica لغة كل مصدر قبل تسجيله، ويتيح العربية والإنجليزية في الواجهة.

يوجد الآن Mihon extension runtime في المشروع. يكتشف الحزم المثبتة، ويتحقق من حالة التوقيع وموافقة المستخدم وإصدار الواجهة، ثم يحاول تحميل فئات المصدر وإنشاء adapters للبحث والتفاصيل والفصول والصفحات. يدعم runtime واجهات 1.4 و1.5 و1.6، ويتطلب Android API 26 على الأقل لتوافق TachiyomiX 1.6. هذا وصف للتنفيذ داخل الشيفرة، وليس ادعاء بأن كل إضافة منشورة اختُبرت على جهاز حقيقي؛ يجب توثيق نتائج الاختبارات الفعلية في `COMPLETION-STATUS.md`.

## المصادر

- [مستودع Keiyoushi للإضافات](https://github.com/keiyoushi/extensions) — مستودع إضافات Mihon وفروعه ويعرض فهرس `index.pb`.
- [قائمة إضافات Keiyoushi المنشورة](https://keiyoushi.github.io/extensions/) — تعرض إضافات بلغات ومصادر متعددة وتتغير مع تحديثات المستودع.
- [طلب Arabtaku رقم 20646](https://github.com/keiyoushi/extensions-source/issues/20646) — طلب مصدر عربي أُغلق كمكتمل.
- [Commit إضافة Arabtaku](https://github.com/keiyoushi/extensions-source/commit/7b92ecad2b7c9173606e0c2fa43e810136de7bbf) — يضيف وحدة المصدر `ar/arabtaku` إلى كود إضافات Keiyoushi.
- [TachiyomiX الرسمي](https://github.com/mihonapp/tachiyomix) — يحدد metadata المطلوبة ومتطلبات المضيف للواجهة 1.6، بما فيها Android API 26 ومكتبات وقت التشغيل.
