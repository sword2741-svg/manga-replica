# مراجعة صفحات الفصول في إضافات Keiyoushi

تاريخ المراجعة: 2026-11-15. المرجع المنشور هو فهرس `index.pb` في فرع `repo`، ومصدر الإضافات هو commit `6f345a81459739e35d8fc94c05455464e856f771` على الفرع `main` (2026-11-14). راجعت الفهرس المنشور نفسه، لا أرقام JSON وحدها.

## الحزم ومعرّفات المصادر والإصدارات المنشورة

| الإضافة | الحزمة | source id (ar) | الإصدار المنشور في index.pb وقت المراجعة | المصدر/المضيف |
|---|---|---:|---:|---|
| ProComic | `eu.kanade.tachiyomi.extension.ar.procomic` | `8891921907305143070` | `1.6.10` (`106010`) | `https://procomic.pro` |
| Hijala | `eu.kanade.tachiyomi.extension.ar.hijala` | `917436262447415426` | `1.6.6` (`106006`) | `https://hijala.com` |
| Team X | `eu.kanade.tachiyomi.extension.ar.teamx` | `4110737012647435874` | `1.6.35` (`106035`) | `https://olympustaff.com` |
| Mangalek | `eu.kanade.tachiyomi.extension.ar.mangalek` | `918460697583900080` | `1.6.72` (`106072`) | `https://mangalik.net` |
| Mangalink | `eu.kanade.tachiyomi.extension.ar.mangalink` | `3568795724496898351` | `1.6.63` (`106063`) | `https://link-manga.net` |
| MangaTuk | `eu.kanade.tachiyomi.extension.ar.mangatuk` | `6924751245735287034` | `1.6.1` (`106001`) | `https://mangatuk.com` |

تطابقت هذه القيم مع JSON المرفق عند فحص الفهرس المنشور. كما فُحصت ملفات بناء الوحدات في commit المصدر الحالي؛ أرقام `versionCode` المحلية في بعض ملفات الوحدات (مثل Mangalek وMangalink وHijala) لا تطابق أرقام `versionCode` المركّبة في فهرس التوزيع، لذلك لم أستنتج «أحدث إصدار منشور» من ملف بناء وحدة منفرد. مرجع التوزيع الذي تم فحصه: [الفهرس الرسمي](https://github.com/keiyoushi/extensions/blob/repo/index.pb).

## آليات صفحات الفصل في المصدر الأصلي

- **ProComic:** ينسّق `configureClient()` عميل KeiSource لإضافة محدد المعدل، الكوكي الآمن، ومعترضات إعادة المحاولة والصور المشتركة ومعترض صفحات القارئ. القارئ يولّد عناوين صور افتراضية محلية تُفك دلالتها داخل `pageInterceptor`/جلسة القارئ؛ ليست روابط صور عادية تصلح لعميل HTTP مستقل. لذلك لا يكفي أن يعيد `getPageList` صفحاتًا، ويجب إرسال طلب الصورة إلى `HttpSource.client` الخاص بالإضافة. [Procomic.kt](https://github.com/keiyoushi/extensions-source/blob/6f345a81459739e35d8fc94c05455464e856f771/src/ar/procomic/src/eu/kanade/tachiyomi/extension/ar/procomic/Procomic.kt)
- **Hijala:** يرث استخراج صفحات HTML من MangaThemesia، ثم يجمّع الصفحات في أزواج ويعيد عناوين افتراضية على `127.0.0.1`. المعترض يجلب الصورتين الأصليتين بـ`Fetch.IMAGE` ويعيد تركيب القطعتين إلى صورة JPEG. تجاوز عميل الإضافة يكسر هذا المسار حتى لو نجح استخراج الفصل. [Hijala.kt](https://github.com/keiyoushi/extensions-source/blob/6f345a81459739e35d8fc94c05455464e856f771/src/ar/hijala/src/eu/kanade/tachiyomi/extension/ar/hijala/Hijala.kt)
- **Team X:** يطلب مستند الفصل، ثم يقرأ `canvas[data-src]` أو `img[src]` من `div.image_list` ويحوّل العناوين إلى `Page`. يضبط عميله أيضًا حدًّا لمعدل الطلبات. [TeamX.kt](https://github.com/keiyoushi/extensions-source/blob/6f345a81459739e35d8fc94c05455464e856f771/src/ar/teamx/src/eu/kanade/tachiyomi/extension/ar/teamx/TeamX.kt)
- **Mangalek:** يرث استخراج الصفحات من `Madara` ويضبط الفصول على `ChapterMode.AdminAjax`؛ اختلاف طلب قائمة الفصول لا يغيّر ضرورة استعمال عميل المصدر نفسه للصور. [Mangalek.kt](https://github.com/keiyoushi/extensions-source/blob/6f345a81459739e35d8fc94c05455464e856f771/src/ar/mangalek/src/eu/kanade/tachiyomi/extension/ar/mangalek/Mangalek.kt)
- **Mangalink:** يرث استخراج صفحات الصور من `Madara`، مع `ChapterMode.MangaPage`. يحتفظ العميل الافتراضي بترويسة `Referer` وبكوكيز المصدر. [Mangalink.kt](https://github.com/keiyoushi/extensions-source/blob/6f345a81459739e35d8fc94c05455464e856f771/src/ar/mangalink/src/eu/kanade/tachiyomi/extension/ar/mangalink/Mangalink.kt)
- **MangaTuk:** يستخرج الصفحات مباشرة من JSON endpoint `/api/catalog/chapters/{chapter.url}/pages` باستخدام `Fetch.XHR`، ثم يأخذ `imageUrl` من كل عنصر. الطلبات تمر بعميل المصدر وترويسات KeiSource، لا بطلبات صور Coil العامة. [MangaTuk.kt](https://github.com/keiyoushi/extensions-source/blob/6f345a81459739e35d8fc94c05455464e856f771/src/ar/mangatuk/src/eu/kanade/tachiyomi/extension/ar/mangatuk/MangaTuk.kt)

## التغيير في MangaReplica

كان الجسر يستخرج `Page` من الإضافة ثم يرسل رابط الصورة إلى Coil/عميل تنزيل مستقل. هذا يفقد عميل المصدر، ومحددات معدل الطلب، وCookieJar، و`Referer`، ومعترضات الصور الافتراضية التي تتطلبها ProComic وHijala. أُضيفت `MangaSource.loadPage` كمسار موحد محدود الحجم؛ محوّل Mihon ينفّذها عبر `HttpSource.client` الأصلي، مع ترويسات الصفحة و`Referer` الخاص بالفصل، ويترك CookieJar/المعترضات داخل العميل. ويستخدم القارئ ملف cache محليًا محدود السعة لتمرير الصورة إلى Coil؛ أما تنزيل الفصول فيستخدم المسار نفسه. لا يتغير البحث أو جلب تفاصيل العمل أو قائمة الفصول، ولا تُضمّن APK أو JAR من Keiyoushi في التطبيق.

شيفرة Keiyoushi مرجع سلوكي وتقني فقط؛ لم تُنسخ ملفات الإضافة أو مواردها إلى MangaReplica.

## حدود الاختبار

أُجري `./gradlew testDebugUnitTest assembleDebug` بنجاح في نسخة تحقق مؤقتة على `compileSdk 37`: 36 اختبارًا إجمالًا، 33 ناجحًا، صفر إخفاق، و3 اختبارات تكامل مباشرة متجاوزة؛ اجتاز اختبارا `SourcePageTransportTest` التحقق المحلي من إرسال `Referer` و`Cookie` و`User-Agent` و`Accept` وقراءة صورة من URI ملف. لا يثبت هذا نجاح الفصول الحقيقية أو اعتراض WebView على جهاز Android. لم يتوفر جهاز/محاكي Android متصل، لذلك لم تُختبر فصول حقيقية من المصادر الستة داخل القارئ؛ يظل هذا التحقق النهائي غير منجز ولا يُدّعى نجاحه.
