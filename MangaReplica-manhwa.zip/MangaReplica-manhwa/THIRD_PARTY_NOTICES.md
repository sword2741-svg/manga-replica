# Third-party notices

## Mihon Source API and extension runtime compatibility

MangaReplica incorporates source API types and selected runtime utilities from the user's `manhwa-slime` project, which is built from Mihon. The upstream Mihon project is licensed under Apache License 2.0. The corresponding license text is included at `licenses/Apache-2.0-Mihon.txt`.

Upstream project: https://github.com/mihonapp/mihon
Reference application: https://github.com/anisLemoudaa/manhwa-slime

The copied API includes the `eu.kanade.tachiyomi.source` interfaces and models, source HTTP helpers, cookie handling, and the Rx/coroutines bridge. `OkHttpExtensions.kt`, `Requests.kt`, `JsoupExtensions.kt`, `NetworkHelper.kt`, and the MangaReplica adapter/loader have been adapted to the Android/Kotlin/OkHttp versions and host services used in MangaReplica. The extension loader follows Mihon's package feature, metadata, class-loading, and supported library-version conventions; it is not a verbatim copy of Mihon's full application `ExtensionManager`.

Mihon and Tachiyomi are names of their respective projects and are not affiliated with MangaReplica. Extensions are third-party code. The application requires explicit signing-certificate trust before loading an installed extension.
