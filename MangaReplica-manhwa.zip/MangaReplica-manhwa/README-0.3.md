# MangaReplica 0.3 — UI + API adapter foundation

Android/Kotlin/Jetpack Compose starter based on the screenshots supplied in the conversation.

## Included
- Dark Arabic-first UI and initial navigation screens.
- Local demo catalog.
- Retrofit/Gson adapter with configurable endpoint paths.
- API contract status notes.

## Important
The complete API route names, methods, response schemas, authentication rules,
and rate limits are not verified. The adapter deliberately does not guess them.
Keep route values blank until authorized documentation or controlled read-only
tests confirm the exact contract. Do not embed passwords, session cookies, or
private API keys in the APK.

## Build
Open this folder in Android Studio, allow Gradle sync, then run the `app`
configuration. Internet permission is included for later API integration.
