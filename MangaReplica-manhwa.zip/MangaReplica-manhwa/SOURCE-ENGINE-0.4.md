# MangaReplica 0.4 — source configuration foundation

Based on the source configuration JSON shown by the user at
`/source/main_source_config`.

## Added
- `SourceConfigClient`: retrieves the JSON configuration over HTTPS.
- `MangaSourceConfig`: parses source domain, image host/path, AJAX endpoint,
  and the configured extractor definitions.
- `SourceHtmlExtractor`: applies configured CSS selectors to chapter HTML
  and page HTML using Jsoup.
- OkHttp and Jsoup dependencies.

## Important limitations
This is a configuration loader and HTML extraction foundation, not a complete
working source integration yet. The screenshot identifies AJAX action names,
selectors, and parameter templates, but does not establish the exact request
encoding and full response JSON/HTML shape for every action. Chapter and page
network calls must be wired only after those request/response details are
confirmed. No private IP routing, account cookies, or credentials are embedded.
