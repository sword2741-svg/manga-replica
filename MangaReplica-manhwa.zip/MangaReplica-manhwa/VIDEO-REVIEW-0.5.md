# MangaReplica 0.5 — chapter navigation and reader layout

The supplied screen recording was reviewed. It shows:
- opening the manga detail page,
- entering the chapter list,
- chapter rows with read and download affordances,
- a vertically scrolling chapter reader,
- reader settings and return navigation.

## Changes in this build
- Added a dedicated chapter-list screen.
- Added newest-first / oldest-first ordering.
- Added per-chapter read and download controls (download is a UI affordance only).
- Added a vertical reader layout with page position controls and settings navigation.
- Updated Back behavior: reader -> chapters -> details -> home.
- Added explicit demo placeholders for page images rather than pretending remote pages are connected.

## Still pending
- Fetch real chapter list from the verified source contract.
- Fetch page HTML and resolve image URLs.
- Load images, retries, caching and offline downloads.
- Persist reader preferences and exact reading progress.
- Build and test APK on Android SDK/device.
