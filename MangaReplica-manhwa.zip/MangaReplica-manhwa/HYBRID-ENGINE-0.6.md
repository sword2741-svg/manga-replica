# MangaReplica 0.6 — Hybrid source architecture foundation

## Selected architecture
- Keiyoushi is the initial extension catalog.
- Native providers implement the app-owned `MangaSource` contract.
- Future Mihon-compatible extension support is isolated behind an adapter boundary.
- The reader consumes normalized `SourceManga`, `SourceChapter`, and `SourcePage` models.

## Implemented in this increment
- `ExtensionStoreRepository` fetches the configured `index.pb` over HTTPS.
- It fetches the companion `repo.json` metadata and `index.json` catalog representation.
- It parses extension metadata into `ExtensionEntry` records.
- It records whether the PB response is gzip-compressed and its byte size.
- `MangaSource` defines the native provider contract.
- `NativeSourceRegistry` registers native providers.

## Important compatibility and security boundaries
- The Keiyoushi repository distributes Mihon-compatible extension packages. `index.pb` is a serialized protobuf catalog, not executable source code.
- This increment deliberately does not execute downloaded APKs, load DEX code, or grant extensions app permissions.
- Mihon documentation warns that extensions may have full access to the host app's permissions and data. A safe runtime requires a deliberate trust model, repository signing-key pinning, package signature validation, API-version compatibility checks, and a review of the in-process execution risk.
- Current catalog display uses the companion `index.json` while fetching `index.pb`. The exact protobuf schema/parser must be generated from the matching upstream schema and tested against the live index before claiming native PB decoding. This avoids guessing protobuf field numbers.
- The repository's `repo.json` signing fingerprint is metadata to verify against APK signatures before any installation. It is not yet used to approve installation in this build.

## Next engineering milestones
1. Pin the exact Mihon extension API version and protobuf schema.
2. Generate and test the protobuf index decoder against the live `index.pb`.
3. Implement repository trust and APK certificate verification.
4. Add an explicit user-confirmed installer flow; never silently install or execute packages.
5. Implement the extension adapter only for compatible, trusted API versions.
6. Add one native source adapter and connect real source results to the UI and reader.
