# Changelog

## 0.11.3 — مصادر مدمجة موحّدة

- إضافة سبعة قارئات مواقع مستقلة ومخفية ضمن التطبيق: Olympus/Team-X وMangaLik وMangalink وProComic وMeshManga وLavaScans وHijala.
- توحيد البحث والرائج والأحدث في نتائج مجمعة، مع دمج العناوين المتطابقة وعزل فشل أي موقع عن بقية النتائج.
- تحسين إلغاء طلبات HTTP عند انتهاء المهلة، وتحديد مهلة مستقلة لكل موقع لمنع تعليق البحث بالكامل.
- عند فتح عمل موجود في أكثر من موقع، تُفحص النسخ المتاحة ويُختار أول إصدار يعيد قائمة فصول فعلية.
- إخفاء اسم الموقع من بطاقة تفاصيل العمل؛ لا تعرض واجهة التصفح أسماء قارئات المواقع المدمجة.
- الفصول أو الصور التي تتطلب جلسة أو دفعاً أو تحققاً من الموقع لا يتم تجاوز حمايتها.

## 0.11.2 — توافق extensions والقارئ

- توحيد Kotlin و`kotlinx.serialization` مع نسخ Mihon الحالية (Kotlin 2.4.20 وserialization 1.11.0) لمعالجة `GeneratedSerializer.typeParametersSerializers()`.
- حفظ نماذج manga/chapter وحقول memo التي تنتجها الإضافة، وتمرير الفصول السابقة، وتسلسل طلبات العمل لمنع فقد بيانات multisrc بين التفاصيل والفصول والصفحات.
- فتح الفصول في قارئ MangaReplica بدل إرسال روابط `getChapterUrl` إلى المتصفح، وتمرير رموز اللغة الإقليمية إلى فلتر ar/en.
- إزالة click handler المتداخل على صور القارئ المستمر وإصلاح تبديل الأشرطة بالنقر المزدوج.
- فصل فلاتر الاستكشاف إلى صفوف أفقية قابلة للتمرير لمنع تداخل الأزرار على الشاشات الضيقة.

## 0.11.1 — توافق عميل KeiSource

- طابقت عميل Mihon الافتراضي مع فحوصات Keiyoushi KeiSource: UncaughtExceptionInterceptor وUserAgentInterceptor وCloudflareInterceptor، ومنع IgnoreGzipInterceptor وBrotliInterceptor من قائمة network interceptors.
- أضيف CloudflareInterceptor فعلي يستخدم WebView وCookieManager لمحاولة حل تحديات cf-mitigated، بدل غياب الصنف الذي ترفضه المصادر الحديثة.
- يجري فحص عميل HttpSource وقت تحميل الإضافة لتظهر أخطاء ABI في حالة الإضافة بدل تأخيرها إلى أول بحث.

## 0.6.0 — Hybrid engine foundation
- Replaced the Manga Slayer-specific source direction with Keiyoushi as the initial extension catalog.
- Added extension-store fetch and catalog display.
- Added native source contract and registry.
- Added an explicit security boundary: no downloaded APK execution yet.
- Kept chapter/reader UI as demo until a real source adapter is connected.

## 0.7.0
- Added a real public MangaDex native API adapter for manga discovery, details, chapters, and page URLs.
- Added default native-source registration and registry unit tests.
- Extension APK execution and downloads remain deliberately disabled pending a verified compatibility and signature-trust implementation.

## 0.8.0 — MangaDex live browsing and reader

- Replaced sample browse, search, manga, chapter, and reader data with MangaDex API results.
- Added Coil-backed real covers and page images, source-backed details and chapter lists, vertical and single-page reader modes, and saved/restored reader position.
- Preserved publisher-hosted chapter URLs and route them to the publisher rather than inventing MangaDex image pages.
- Added bounded retry for MangaDex HTTP 429/5xx and opt-in live API/image integration tests.
- Explicitly documented that MangaDex availability varies by title/chapter, that Solo Leveling currently has publisher-hosted chapters only, and that device UI verification was unavailable.

## 0.9.0 — واجهة التصميم والتخزين المحلي

- نقلت واجهة RTL المستندة إلى ملفات التصميم إلى Compose: الرئيسية والبحث والاستكشاف والمكتبة والتحديثات والتفاصيل والقارئ والإعدادات.
- أضيف فك فهرس Keiyoushi Protobuf/GZIP وفق المخطط الرسمي وfallback لـ`index.json` الكامل، مع رابط مستودع قابل للتغيير وحفظه.
- أضيف فحص APK للحزمة وبصمة التوقيع قبل استدعاء مثبت Android؛ لا يوجد runtime لتشغيل إضافات Mihon داخل التطبيق.
- أضيفت قاعدة Room للمكتبة والتقدم والتصنيفات وسجل البحث والتنزيلات، وDataStore للإعدادات، وتنزيل فصول محلية، ونسخ/استعادة JSON لبيانات المستخدم.
- أضيفت خمس لوحات ألوان ديناميكية وإعدادات RTL/Tajawal وقارئ بأنماط صفحات وتمرير.
- يوضح README والحالة أن مزامنة OAuth والجدولة الخلفية وRuntime إضافات Mihon وبعض إعدادات القارئ والتصفية ليست مكتملة.

## 0.9.1 — الأيقونة والتحقق المستمر

- اعتمدت صورة الشعار المرفقة كأيقونة Android legacy وadaptive، مع مقاسات كثافات متعددة وخلفية سوداء متناسقة.
- أضفت GitHub Actions لتشغيل اختبارات الوحدة وبناء APK debug الموقّع وrelease غير الموقّع ورفعها كـArtifacts.
- رفعت versionCode إلى 10 لتمييز هذا الإصدار الأحدث على أجهزة Android.

## 0.10.2 — إصلاح توافق إضافات Mihon/Keiyoushi

- بدأ إصلاح شرط `UncaughtExceptionInterceptor must be present in default client` بإضافة المعترض إلى `NetworkHelper.client`؛ لم يكتمل حينها توافق عميل KeiSource.
- أضيفت `rateLimit` و`rateLimitHost` (واجهة الإضافات تستدعيها ولا تحزمها داخل APK، وغيابها يسبب NoClassDefFoundError).
- تسجيل `Application` في Injekt (الإضافات تستدعي `Injekt.get<Application>()` لقراءة إعداداتها).
- قبول إضافات واجهة 1.5 إلى جانب 1.4 و1.6.
- إضافة مكتبات وقت التشغيل التي يوفرها Mihon للإضافات: serialization-json-okio وserialization-protobuf وokhttp-brotli وokhttp-dnsoverhttps وquickjs.
- السماح بـHTTP غير المشفر (`usesCleartextTraffic`) لأن بعض المصادر وصور الفصول تستخدمه.
- `FederatedSourceRepository` يلتقط الآن أي `Throwable` من مصدر واحد دون إسقاط بقية المصادر.

## 0.11.0 — أحدث الأعمال والملف الشخصي وقائمة الفصول

- شاشة «أحدث الأعمال»: شبكة عمودين من كل المصادر المفعّلة بالتوازي، شريط النوع والترتيب، ورقة تصفية (النوع/المصدر/اللغة/إخفاء المقروء)، شارة «جديد»، قائمة الضغط المطوّل، تحميل صفحة بعد صفحة، سحب للتحديث، هياكل تحميل، وحالتا الفراغ والخطأ، مع عرض آخر نتائج محفوظة بلا إنترنت.
- شاشة «الملف الشخصي» محلية بالكامل: الاسم والصورة والنبذة، بطاقتا الإحصاء، تبويبات المكتبة والإحصائيات (والتعليقات تظهر فقط إن وُجدت بيانات)، وقائمة ⋮. المستوى وVIP والتوثيق مخفية لأنها تحتاج حساباً وخادماً.
- زر الملف الشخصي في أعلى الرئيسية (≥44dp وبوصف لقارئات الشاشة) وبطاقة في أعلى «المزيد».
- قائمة فصول جديدة في صفحة العمل (بحث، ترتيب، تصفية، حالات: عادي/جديد/مقروء/الحالي، تحديد متعدد، زر تنزيل بثلاث حالات، دمج الفصول المكررة مع اختيار النسخة) وقائمة فصول داخل القارئ.
- قاعدة البيانات v2 مع Migration يحفظ بيانات المستخدم: جدول وقت القراءة، تصنيفات الأعمال، وعدد صفحات كل فصل.
- حفظ تقدّم القراءة عند كل تغيير صفحة (وفي وضع التمرير) وعند الخروج من القارئ.
- النسخة الاحتياطية تشمل إحصائيات القراءة والملف الشخصي وتذكّر بعمل نسخة كل أسبوعين.
- تحميل الإضافات عند بدء التطبيق (كان يحدث فقط عند فتح شاشة المصادر)، وتنفيذ طلبات الإضافات على خيط IO.
