# MangaReplica — تقرير تدقيق Mihon Extension Runtime

**التاريخ:** 2026-11-14
**المستودع:** `anisLemoudaa/MangaReplica`
**الفرع:** `Lemoudaa2741`
**النسخة:** `0.11.2` (`versionCode=18`)

## الخلاصة

أُجري التدقيق على runtime الموجود فعليًا ولم يُستبدل المحرك من الصفر. أصلحت دورة اكتشاف APK الإضافة وقراءة metadata، وعزل واجهات المضيف في ClassLoader، وربط مصادر الإضافة بالمستودع، والتوافق مع خدمات Mihon. اجتازت اختبارات Gradle وبناء Debug؛ لكن لم يتوفر جهاز/محاكي ولا APK إضافة حقيقية للاختبار الطرفي، لذلك نجاح البناء لا يثبت أن إضافة خارجية فعلية ستعمل على جهاز.

## ما تغيّر

- `InstalledExtensionRegistry.kt`: اكتشاف حزم الإضافات، قراءة `tachiyomi.extension.class` و`tachiyomix.extensionLib` وبيانات التحذير، فهم قيم إصدار الواجهة العددية/النصية، تمييز المصادر بحسب حزمة الإضافة واللغة والمعرّف، وإنشاء adapters لـ`Source` و`SourceFactory`. يتعامل مع حالات الفشل ويعرض مرحلة الفشل دون تسجيل محتويات الطلبات أو Cookies.
- التوقيع والثقة: تُقرأ بصمة شهادة التوقيع SHA-256؛ لا يُحمّل كود الإضافة الموقّع إلا بعد الموافقة الصريحة وحفظ الثقة بهذه الشهادة. لا يفرض رفضًا اعتباطيًا لعملاء HTTP المخصصين للإضافة. **مهم:** الثقة في شهادة موقّع لا تثبت أن المصدر آمن؛ الإضافة كود قابل للتنفيذ.
- `SharedApiPathClassLoader`: يشارك أصناف Mihon/المضيف وOkHttp وKotlin مع الإضافة لتجنب تحميل نسخ API متعارضة، مع السماح بتحميل أصناف الإضافة ومكتباتها من APK.
- `MihonRuntimeServices.kt` و`JavaScriptEngine.kt`: تسجيل خدمات Injekt لـ`Context` و`Application` عند توفرها و`NetworkHelper` و`Json` و`ProtoBuf` و`XML` و`JavaScriptEngine`. تنفيذ JavaScript عبر QuickJS وإنشاء محرك مستقل لكل تقييم.
- `MainActivity.kt`: إعادة فحص الحزم عند عودة التطبيق إلى الواجهة وإظهار نتيجة/فشل المسح.
- `MangaScreens.kt`: عرض الثقة والتوافق وعدد المصادر ورسائل حالة واضحة بدل الإيحاء بأن الإضافات مدعومة بالكامل.
- لم تُزل المصادر الأصلية أو MangaDex أو `FederatedSourceRepository`.
- اختبارات جديدة في `ExtensionRuntimeMetadataTest.kt` تغطي parsing إصدار API وتجنب تصادم معرّفات المصادر بين الحزم.
- تحديث `README.md` و`docs/extension-sources-status.md` وهذه الوثيقة لتطابق الحالة الحالية بدل الادعاءات القديمة.

## توافق API والإصدارات

تحدد واجهة TachiyomiX 1.6 حد Android API 26 ومتطلبات مكتبات runtime متوافقة [1]. يقبل الكود الحالي واجهات الإضافات 1.4 و1.5 و1.6 فقط، ويرشح المصادر العربية والإنجليزية بما يتفق مع هدف التطبيق. الإصدارات المثبتة في Gradle: AGP 9.5.1، Kotlin 2.4.20، KSP 2.3.13، Gradle Wrapper 9.7.1، Coroutines 1.11.0، kotlinx.serialization 1.11.0، OkHttp 5.5.0، Jsoup 1.23.1، xmlutil 1.0.2، وQuickJS Android 0.9.2. سجل Mihon الرسمي يبيّن خدمات JSON وXML وProtoBuf وNetworkHelper التي تُحقن في التطبيق [2].

تطلب AAR الخاص بـOkHttp 5.5.0 `compileSdk` 37؛ لذلك أصبح `compileSdk=37`، وثُبّتت منصة SDK 37.2 للبناء. بقي `minSdk=26` و`targetSdk=35` دون تغيير: رفع compileSdk مطلوب للتجميع ولا يرفع وحده حد التثبيت أو targetSdk. وثائق Android تفرق بين Platform SDK المستخدم للتجميع وصورة المحاكي اللازمة للتشغيل [3].

جرى اختيار KSP 2.3.13 بعد تعذر حل إصدار KSP 2.4.0 من المستودع خلال التحقق. كما عولج توافق AGP 9 مع Kotlin المدمج واستخدام `kotlin.compilerOptions` [4].

## التحقق والنتائج

- `./gradlew testDebugUnitTest --no-daemon`: **BUILD SUCCESSFUL**؛ 33 اختبارًا ضمن 11 مجموعة، 0 فشل، 0 أخطاء، 3 متخطاة.
- `./gradlew assembleDebug --no-daemon`: **BUILD SUCCESSFUL**.
- `./gradlew app:dependencies --configuration debugRuntimeClasspath`: تم التحقق من الإصدارات المحلولة، بما فيها OkHttp 5.5.0 وJsoup 1.23.1 وCoroutines 1.11.0 وSerialization 1.11.0.
- `git diff --check`: نجح بلا أخطاء تنسيق.
- فحص APK بواسطة `aapt`: الحزمة `com.example.mangareplica`، `versionName=0.11.2`، `versionCode=18`، `compileSdk=37`، `minSdk=26`، `targetSdk=35`.
- ملف APK الناتج: `app/build/outputs/apk/debug/app-debug.apk`، حجمه نحو 29 MiB، SHA-256: `4f52cae2229461d5bce656d626f20452f15edfaa05d364544924e21d516fcc34`.
- تظهر تحذيرات مترجم غير حاجبة، منها deprecations وتحذيرات nullability وطلب opt-in لـSerialization Protobuf. ظهر أيضًا تحذير أن بعض المكتبات الأصلية لا تُجرّد رموزها وتُضمّن كما هي؛ لم يمنع ذلك البناء.

## حدود واختبارات غير منفذة

1. لم يُختبر APK على جهاز أو محاكي، ولم تُثبّت/تُحمّل إضافة Mihon حقيقية داخل التطبيق؛ لا يمكن ادعاء تحقق دورة DEX أو تسجيل مصدر أو طلب شبكي فعلي.
2. لم يتوفر APK إضافة موثوق مصحوب بمصدر بصمة موثّق لإجراء اختبار توقيع وتثبيت end-to-end. لا تثق بإضافة مجهولة؛ بعد موافقة المستخدم ستعمل بصلاحيات التطبيق.
3. لم تُنفذ اختبارات instrumentation لـClassLoader أو خدمات Injekt أو شبكة كل إضافة، ولا اختبار مصادر محمية بـCloudflare.
4. لم يُبنَ إصدار Release ولم يُوقّع بمفتاح توزيع؛ الملف المتاح Debug فقط.
5. التوافق المعلن محصور بواجهات 1.4–1.6 وبالمصادر العربية والإنجليزية؛ واجهات أحدث أو لغات أخرى ستُعرض كغير مدعومة/تُستبعد بحسب المسار.
6. يجب التأكد من وجود منصة API 37 في بيئة البناء المستقبلية؛ الاعتماد الحالي OkHttp 5.5.0 يرفض compilation بأقل من API 37 وفق بيانات AAR التي فشل عندها الاختبار الأول.

## الملفات المسلّمة

- APK: `app/build/outputs/apk/debug/app-debug.apk`
- ZIP للمشروع المصدر: `/home/ubuntu/MangaReplica-source.zip` (يستثني `.git` ومجلدات build وGradle/Kotlin المؤقتة و`local.properties`؛ لا يحتوي APK المبني، لأنه يسلم منفصلًا).
- مرجع التوافق: `docs/runtime-compatibility.md`

## المراجع

[1]: https://github.com/mihonapp/tachiyomix "TachiyomiX repository and extension API"
[2]: https://github.com/mihonapp/mihon/blob/main/app/src/main/java/mihon/app/di/AppBindings.kt "Mihon AppBindings"
[3]: https://developer.android.com/tools/releases/platforms "Android SDK Platform release information"
[4]: https://developer.android.com/build/migrate-to-built-in-kotlin "Android Gradle Plugin built-in Kotlin migration"
