# MangaDex network evidence (2026-11-10)

The following are observations from actual requests, not fixtures. Manga availability may change.

## Successful public API responses observed earlier in the session

- `GET /manga?title=Solo%20Leveling...`: HTTP 200, total 7. Best result ID `32d76d19-8a05-4db0-9fc2-e0b0648fe9d0`; primary title `Na Honjaman Level-Up`, English alternate title `Solo Leveling`.
- Cover URL `https://uploads.mangadex.org/covers/32d76d19-8a05-4db0-9fc2-e0b0648fe9d0/e90bdc47-c8b9-4df7-b2c0-17641b645ee1.jpg.256.jpg`: HTTP 200, `image/jpeg`, 40,292 bytes.
- `GET /manga/32d76d19-8a05-4db0-9fc2-e0b0648fe9d0`: HTTP 200, response body 57,861 bytes; description metadata had 15 locales.
- `GET /manga/{id}/feed`: HTTP 200, 24 records, English observed and no Arabic records in this feed. The inspected chapter records pointed to external publishers.
- `GET /at-home/server/ad5931f0-863e-412d-992c-7eb28ca2806c`: HTTP 200 with `chapter.hash=""`, `data=[]`, `dataSaver=[]`. Therefore no internal page images were presented for that publisher-hosted Solo Leveling chapter.
- For The Eminence in Shadow, MangaDex search/listing returned ID `77bee52c-d2d6-44ad-a33a-1734c1fe696a`; its internal chapter `3c652754-fbf7-4465-be54-f61e50eadc5a` returned an at-home page manifest with 37 page filenames. The actual image bytes were not verified here.

## Opt-in Kotlin live test attempt

Command: `MANGADEX_LIVE_TEST=1 ./gradlew --no-daemon testDebugUnitTest --rerun-tasks`.

Result: 4 tests completed; the registry tests and Solo Leveling live test passed. `liveSearchDetailsChaptersAndRealPageImage` failed before its first source request because OkHttp rejected a mismatched TLS certificate: the presented certificate subject was `CN=radius.alonet.it`, while the requested host was `api.mangadex.org`. The hostname verifier and certificate validation were left intact. A separate `curl` verification also reported the certificate hostname mismatch. No image-byte live test is claimed as passed.
