package eu.kanade.tachiyomi.network.interceptor

import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException

/**
 * Converts unexpected (non-IO) exceptions thrown by later interceptors into [IOException] so that
 * OkHttp reports them as a normal failed call instead of crashing the dispatcher thread.
 *
 * Current Mihon/Keiyoushi extensions verify that an interceptor with exactly this simple name is
 * present in the default client, so the class name must not change.
 */
class UncaughtExceptionInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        try {
            return chain.proceed(chain.request())
        } catch (e: Exception) {
            if (e is IOException) {
                throw e
            } else {
                throw IOException(e)
            }
        }
    }
}
