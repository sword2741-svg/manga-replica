package eu.kanade.tachiyomi.network

import android.content.Context
import app.cash.quickjs.QuickJs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Mihon-compatible JavaScript evaluator backed by QuickJS. A fresh engine is closed for each
 * evaluation because QuickJs instances are not thread-safe and own native resources.
 */
class JavaScriptEngine(@Suppress("UNUSED_PARAMETER") context: Context) {
    @Suppress("UNCHECKED_CAST")
    suspend fun <T> evaluate(script: String): T = withContext(Dispatchers.IO) {
        QuickJs.create().use { engine ->
            engine.evaluate(script) as T
        }
    }
}
