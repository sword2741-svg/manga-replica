package eu.kanade.tachiyomi.network

import okhttp3.OkHttpClient

/** The runtime contract checked by Keiyoushi's KeiSource before it accepts the Mihon client. */
internal object MihonClientContract {
    fun verify(client: OkHttpClient) {
        val interceptors = client.interceptors.map { it.javaClass.simpleName }.toSet()
        check("UncaughtExceptionInterceptor" in interceptors) {
            "UncaughtExceptionInterceptor must be present in default client"
        }
        check("UserAgentInterceptor" in interceptors) {
            "UserAgentInterceptor must be present in default client"
        }
        check("CloudflareInterceptor" in interceptors) {
            "CloudflareInterceptor must be present in default client"
        }
        val networkInterceptors = client.networkInterceptors.map { it.javaClass.simpleName }.toSet()
        check("IgnoreGzipInterceptor" !in networkInterceptors) {
            "IgnoreGzipInterceptor must not be present in default client"
        }
        check("BrotliInterceptor" !in networkInterceptors) {
            "BrotliInterceptor must not be present in default client"
        }
    }
}
