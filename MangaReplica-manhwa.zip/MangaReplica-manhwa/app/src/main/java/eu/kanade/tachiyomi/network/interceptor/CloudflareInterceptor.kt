package eu.kanade.tachiyomi.network.interceptor

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import eu.kanade.tachiyomi.network.AndroidCookieJar
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Mihon-compatible Cloudflare challenge interceptor. It only opens a hidden WebView when
 * Cloudflare explicitly identifies a challenge response; ordinary HTTP failures pass through.
 */
class CloudflareInterceptor(
    private val context: Context,
    private val cookieJar: AndroidCookieJar,
    private val defaultUserAgentProvider: () -> String,
) : Interceptor {
    @SuppressLint("SetJavaScriptEnabled")
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val response = chain.proceed(request)
        val isChallenge = response.header("cf-mitigated") == "challenge" &&
            response.header("Server")?.contains("cloudflare", ignoreCase = true) == true
        if (!isChallenge) return response

        response.close()
        if (Looper.myLooper() == Looper.getMainLooper()) {
            throw IOException("Cloudflare challenge cannot be processed on the main thread")
        }

        val oldClearance = cookieJar.get(request.url).firstOrNull { it.name == "cf_clearance" }?.value
        val completed = CountDownLatch(1)
        val solved = AtomicBoolean(false)
        var webView: WebView? = null

        Handler(Looper.getMainLooper()).post {
            try {
                webView = WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.userAgentString = request.header("User-Agent")
                        ?.takeIf(String::isNotBlank) ?: defaultUserAgentProvider()
                    webViewClient = object : WebViewClient() {
                        private fun checkClearance(url: String?) {
                            if (url.isNullOrBlank()) return
                            val cookies = CookieManager.getInstance().getCookie(url).orEmpty()
                            val clearance = cookies.split(';')
                                .map(String::trim)
                                .firstOrNull { it.startsWith("cf_clearance=") }
                                ?.substringAfter('=')
                            if (!clearance.isNullOrBlank() && clearance != oldClearance) {
                                solved.set(true)
                                completed.countDown()
                            }
                        }

                        override fun onPageFinished(view: WebView, url: String?) {
                            checkClearance(url)
                            if (url?.startsWith(request.url.scheme + "://" + request.url.host) == false) {
                                completed.countDown()
                            }
                        }

                        override fun onReceivedHttpError(
                            view: WebView?,
                            webRequest: WebResourceRequest?,
                            errorResponse: WebResourceResponse?,
                        ) {
                            if (webRequest?.isForMainFrame == true &&
                                errorResponse?.statusCode in 400..499 &&
                                errorResponse?.responseHeaders?.get("cf-mitigated") != "challenge"
                            ) {
                                completed.countDown()
                            }
                        }
                    }
                    loadUrl(request.url.toString(), safeHeaders(request))
                }
            } catch (_: Exception) {
                completed.countDown()
            }
        }

        val finished = completed.await(30, TimeUnit.SECONDS)
        Handler(Looper.getMainLooper()).post {
            webView?.apply {
                stopLoading()
                destroy()
            }
        }
        if (!finished || !solved.get()) {
            throw IOException("Cloudflare challenge was not solved; check that Android System WebView is available")
        }
        return chain.proceed(request)
    }

    private fun safeHeaders(request: Request): Map<String, String> = buildMap {
        val unsafe = setOf(
            "content-length", "host", "trailer", "te", "upgrade", "cookie2",
            "keep-alive", "transfer-encoding", "set-cookie",
        )
        request.headers.toMultimap().forEach { (name, values) ->
            if (!name.startsWith("proxy-", ignoreCase = true) && name.lowercase() !in unsafe) {
                values.firstOrNull()?.let { put(name, it) }
            }
        }
    }
}
