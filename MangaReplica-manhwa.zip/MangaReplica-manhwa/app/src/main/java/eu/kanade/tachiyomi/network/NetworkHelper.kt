package eu.kanade.tachiyomi.network

import android.content.Context
import eu.kanade.tachiyomi.network.interceptor.CloudflareInterceptor
import eu.kanade.tachiyomi.network.interceptor.UncaughtExceptionInterceptor
import eu.kanade.tachiyomi.network.interceptor.UserAgentInterceptor
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit

/** Host network service ABI expected by Mihon/Tachiyomi source extensions. */
class NetworkHelper(private val context: Context) {
    val cookieJar = AndroidCookieJar()
    private val cacheDir: File get() = File(context.cacheDir, "mihon-extension-http")

    /**
     * Default client handed to extensions. Mirrors Mihon's interceptor stack: current extensions
     * KeiSource checks these interceptor class names on the inherited default client. Compression
     * is configured by the extension itself, so Brotli and IgnoreGzip must not be network interceptors here.
     */
    val client: OkHttpClient by lazy {
        cacheDir.mkdirs()
        OkHttpClient.Builder()
            .cookieJar(cookieJar)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .callTimeout(120, TimeUnit.SECONDS)
            .cache(okhttp3.Cache(cacheDir, 5L * 1024 * 1024))
            .addInterceptor(UncaughtExceptionInterceptor())
            .addInterceptor(UserAgentInterceptor(::defaultUserAgentProvider))
            .addInterceptor(CloudflareInterceptor(context, cookieJar, ::defaultUserAgentProvider))
            .build()
            .also(MihonClientContract::verify)
    }

    @Deprecated("The regular client handles Cloudflare in extension-lib 1.5 and later")
    val nonCloudflareClient: OkHttpClient get() = client

    @Deprecated("Regular client is used by extension-lib 1.5 and later")
    val cloudflareClient: OkHttpClient get() = client

    fun defaultUserAgentProvider(): String =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
}
