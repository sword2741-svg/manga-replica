package eu.kanade.tachiyomi.network.interceptor

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import kotlin.time.toDuration
import kotlin.time.toDurationUnit

/**
 * Host-provided rate limiter used by extensions through [rateLimit] / [rateLimitHost].
 * Extensions do not bundle this class, so it must exist in the host or they fail with
 * NoClassDefFoundError / NoSuchMethodError.
 *
 * @param host when not null, only requests to this host are limited.
 */
internal class RateLimitInterceptor(
    private val host: String?,
    private val permits: Int,
    period: Duration,
) : Interceptor {

    private val requestQueue = ArrayList<Long>(permits.coerceAtLeast(1))
    private val rateLimitMillis = period.inWholeMilliseconds

    override fun intercept(chain: Interceptor.Chain): Response {
        // Ignore canceled calls, otherwise they would jam the queue.
        if (chain.call().isCanceled()) throw IOException("Canceled")
        if (host != null && chain.request().url.host != host) {
            return chain.proceed(chain.request())
        }
        if (permits <= 0) return chain.proceed(chain.request())

        synchronized(requestQueue) {
            val now = System.nanoTime() / 1_000_000L
            val waitTime = if (requestQueue.size < permits) {
                0L
            } else {
                val oldestReq = requestQueue[0]
                val newestReq = requestQueue[permits - 1]
                if (newestReq - oldestReq > rateLimitMillis) 0L else oldestReq + rateLimitMillis - now
            }

            if (chain.call().isCanceled()) throw IOException("Canceled")
            if (requestQueue.size == permits) requestQueue.removeAt(0)

            if (waitTime > 0) {
                requestQueue.add(now + waitTime)
                Thread.sleep(waitTime)
            } else {
                requestQueue.add(now)
            }
        }
        return chain.proceed(chain.request())
    }
}

/** Limits every request of this client to [permits] per [period]. */
fun OkHttpClient.Builder.rateLimit(
    permits: Int,
    period: Long = 1,
    unit: TimeUnit = TimeUnit.SECONDS,
): OkHttpClient.Builder =
    addInterceptor(RateLimitInterceptor(null, permits, period.toDuration(unit.toDurationUnit())))

/** Limits every request of this client to [permits] per [period]. */
fun OkHttpClient.Builder.rateLimit(
    permits: Int,
    period: Duration = 1.seconds,
): OkHttpClient.Builder = addInterceptor(RateLimitInterceptor(null, permits, period))
