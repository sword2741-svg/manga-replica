package com.example.mangareplica.data.persistence

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        LibraryMangaEntity::class,
        ReadingProgressEntity::class,
        ChapterDownloadEntity::class,
        SearchHistoryEntity::class,
        MangaCategoryEntity::class,
        ReadingDayStatEntity::class,
    ],
    version = 3,
    exportSchema = false,
)
abstract class MangaDatabase : RoomDatabase() {
    abstract fun libraryDao(): LibraryDao
    abstract fun readingProgressDao(): ReadingProgressDao
    abstract fun chapterDownloadDao(): ChapterDownloadDao
    abstract fun searchHistoryDao(): SearchHistoryDao
    abstract fun mangaCategoryDao(): MangaCategoryDao
    abstract fun readingStatsDao(): ReadingStatsDao
}
