package com.example.mangareplica.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.example.mangareplica.R
import com.example.mangareplica.data.preferences.AppSettings
import com.example.mangareplica.data.preferences.ThemeMode

val Amiri = FontFamily(
    Font(R.font.amiri_regular, FontWeight.Normal),
    Font(R.font.amiri_bold, FontWeight.Bold),
    Font(R.font.amiri_bold, FontWeight.ExtraBold)
)

private val DarkBackground = Color(0xFF0B0D12)
private val DarkSurface = Color(0xFF151821)
private val Border = Color(0xFF232733)
private val TextPrimary = Color(0xFFF4F1EC)
private val TextSecondary = Color(0xFFA8A29A)
private val DefaultAccent = Color(0xFFFF6B4A)

@Composable
fun MangaReplicaTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val background = if (dark && settings.trueBlackAmoled) Color.Black else if (dark) DarkBackground else Color(0xFFFAF9F6)
    val surface = if (dark) DarkSurface else Color(0xFFFFFFFF)
    val primary = Color(settings.accentColorArgb.takeIf { it != 0 } ?: DefaultAccent.value.toInt())
    val onPrimary = Color(0xFF1A0A06)
    val colors = if (dark) {
        darkColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            secondary = Color(0xFFFF8A6E),
            background = background,
            onBackground = TextPrimary,
            surface = surface,
            onSurface = TextPrimary,
            surfaceVariant = Border,
            onSurfaceVariant = TextSecondary,
            outline = Border
        )
    } else {
        lightColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            secondary = Color(0xFFB94E36),
            background = background,
            onBackground = Color(0xFF201A17),
            surface = surface,
            onSurface = Color(0xFF201A17),
            surfaceVariant = Color(0xFFF0ECE7),
            onSurfaceVariant = Color(0xFF625B55),
            outline = Color(0xFFD6D0C9)
        )
    }
    val base = Typography()
    val typography = base.copy(
        displayLarge = base.displayLarge.copy(fontFamily = Amiri, fontWeight = FontWeight.ExtraBold),
        displayMedium = base.displayMedium.copy(fontFamily = Amiri, fontWeight = FontWeight.ExtraBold),
        displaySmall = base.displaySmall.copy(fontFamily = Amiri, fontWeight = FontWeight.Bold),
        headlineLarge = base.headlineLarge.copy(fontFamily = Amiri, fontWeight = FontWeight.Bold),
        headlineMedium = base.headlineMedium.copy(fontFamily = Amiri, fontWeight = FontWeight.Bold),
        headlineSmall = base.headlineSmall.copy(fontFamily = Amiri, fontWeight = FontWeight.Bold),
        titleLarge = base.titleLarge.copy(fontFamily = Amiri, fontWeight = FontWeight.Bold),
        titleMedium = base.titleMedium.copy(fontFamily = Amiri, fontWeight = FontWeight.Bold),
        titleSmall = base.titleSmall.copy(fontFamily = Amiri, fontWeight = FontWeight.Bold),
        bodyLarge = base.bodyLarge.copy(fontFamily = Amiri),
        bodyMedium = base.bodyMedium.copy(fontFamily = Amiri),
        bodySmall = base.bodySmall.copy(fontFamily = Amiri),
        labelLarge = base.labelLarge.copy(fontFamily = Amiri, fontWeight = FontWeight.Bold),
        labelMedium = base.labelMedium.copy(fontFamily = Amiri),
        labelSmall = base.labelSmall.copy(fontFamily = Amiri)
    )
    MaterialTheme(colorScheme = colors, typography = typography, content = content)
}
