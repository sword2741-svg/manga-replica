package com.example.mangareplica.data.persistence

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {
    @Query("SELECT * FROM library_manga ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<LibraryMangaEntity>>

    @Query("SELECT * FROM library_manga WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl LIMIT 1")
    fun observe(sourceId: String, mangaUrl: String): Flow<LibraryMangaEntity?>

    @Query("SELECT * FROM library_manga WHERE isFavorite = 1 ORDER BY updatedAt DESC")
    fun observeFavorites(): Flow<List<LibraryMangaEntity>>

    @Query("SELECT * FROM library_manga WHERE categoryId = :categoryId ORDER BY updatedAt DESC")
    fun observeCategory(categoryId: String): Flow<List<LibraryMangaEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(manga: LibraryMangaEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(manga: List<LibraryMangaEntity>)

    @Query("DELETE FROM library_manga WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl")
    suspend fun delete(sourceId: String, mangaUrl: String)

    @Query("DELETE FROM library_manga")
    suspend fun deleteAll()

    @Transaction
    suspend fun replaceAll(manga: List<LibraryMangaEntity>) {
        deleteAll()
        upsertAll(manga)
    }
}

@Dao
interface ReadingProgressDao {
    @Query("SELECT * FROM reading_progress ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ReadingProgressEntity>>

    @Query("SELECT * FROM reading_progress WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl ORDER BY updatedAt DESC")
    fun observeForManga(sourceId: String, mangaUrl: String): Flow<List<ReadingProgressEntity>>

    @Query("SELECT * FROM reading_progress WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl AND chapterUrl = :chapterUrl LIMIT 1")
    fun observe(sourceId: String, mangaUrl: String, chapterUrl: String): Flow<ReadingProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(progress: ReadingProgressEntity)

    @Query("DELETE FROM reading_progress WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl AND chapterUrl = :chapterUrl")
    suspend fun delete(sourceId: String, mangaUrl: String, chapterUrl: String)

    @Query("DELETE FROM reading_progress WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl")
    suspend fun deleteForManga(sourceId: String, mangaUrl: String)
}

@Dao
interface ChapterDownloadDao {
    @Query("SELECT * FROM chapter_downloads ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ChapterDownloadEntity>>

    @Query("SELECT * FROM chapter_downloads WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl ORDER BY updatedAt DESC")
    fun observeForManga(sourceId: String, mangaUrl: String): Flow<List<ChapterDownloadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(download: ChapterDownloadEntity)

    @Query("DELETE FROM chapter_downloads WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl AND chapterUrl = :chapterUrl")
    suspend fun delete(sourceId: String, mangaUrl: String, chapterUrl: String)

    @Query("DELETE FROM chapter_downloads WHERE sourceId = :sourceId AND mangaUrl = :mangaUrl")
    suspend fun deleteForManga(sourceId: String, mangaUrl: String)
}

@Dao
interface SearchHistoryDao {
    @Query("SELECT * FROM search_history ORDER BY searchedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<SearchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: SearchHistoryEntity)

    @Query("DELETE FROM search_history WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM search_history")
    suspend fun clear()
}

@Dao
interface MangaCategoryDao {
    @Query("SELECT * FROM manga_categories ORDER BY name COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<MangaCategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(category: MangaCategoryEntity)

    @Query("DELETE FROM manga_categories WHERE id = :id")
    suspend fun delete(id: String)
}
