package com.example.mangareplica.data.extensions

import android.app.Application
import android.content.Context
import eu.kanade.tachiyomi.network.JavaScriptEngine
import eu.kanade.tachiyomi.network.NetworkHelper
import kotlinx.serialization.protobuf.ProtoBuf
import kotlinx.serialization.json.Json
import nl.adaptivity.xmlutil.XmlDeclMode
import nl.adaptivity.xmlutil.core.XmlVersion
import nl.adaptivity.xmlutil.serialization.XML
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.InjektScope
import uy.kohesive.injekt.api.TypeReference
import uy.kohesive.injekt.registry.default.DefaultRegistrar
import java.lang.reflect.Type

/** Small host-service bridge for Mihon-compatible extensions. */
internal object MihonRuntimeServices {
    @Volatile private var initialized = false
    @Volatile var networkHelper: NetworkHelper? = null
        private set

    @Synchronized
    fun initialize(context: Context) {
        if (initialized) return
        val appContext = context.applicationContext
        val network = NetworkHelper(appContext)
        networkHelper = network
        val json = Json { ignoreUnknownKeys = true; isLenient = true; coerceInputValues = true }
        val xml = XML.v1 {
            policy {
                ignoreUnknownChildren()
                autoPolymorphic = true
            }
            xmlDeclMode = XmlDeclMode.Charset
            xmlVersion = XmlVersion.XML10
            setIndent(2)
        }
        val registrar = DefaultRegistrar().apply {
            addSingleton(typeRef<Context>(), appContext)
            // Extensions call Injekt.get<Application>() for their SharedPreferences.
            (appContext as? Application)?.let { addSingleton(typeRef<Application>(), it) }
            addSingleton(typeRef<NetworkHelper>(), network)
            addSingleton(typeRef<Json>(), json)
            addSingleton(typeRef<ProtoBuf>(), ProtoBuf)
            addSingleton(typeRef<XML>(), xml)
            addSingleton(typeRef<JavaScriptEngine>(), JavaScriptEngine(appContext))
        }
        Injekt = InjektScope(registrar)
        initialized = true
    }

    private inline fun <reified T : Any> typeRef(): TypeReference<T> = object : TypeReference<T> {
        override val type: Type = T::class.java
    }
}
