package com.example.mangareplica.data.profile

import com.example.mangareplica.data.persistence.LibraryMangaEntity
import com.example.mangareplica.data.persistence.ReadingDayStatEntity
import com.example.mangareplica.data.persistence.ReadingProgressEntity
import java.util.TimeZone

data class DayBar(val day: Long, val seconds: Int)

data class ProfileStats(
    val totalSeconds: Long,
    val chaptersRead: Int,
    /** The last seven days, oldest first, ending today. */
    val weekBars: List<DayBar>,
    val weekSeconds: Int,
    val streakDays: Int,
    /** Most frequent genres of works the user has read, highest first. */
    val topGenres: List<Pair<String, Int>>,
    val libraryCount: Int,
) {
    val hasAnyData: Boolean get() = totalSeconds > 0 || chaptersRead > 0 || libraryCount > 0
}

/** Optional account-backed fields. Always null until a server/account layer exists; the UI hides them. */
data class ProfileAccount(val level: Int?, val isVip: Boolean, val isVerified: Boolean)

data class ProfileComment(
    val sourceId: String,
    val mangaUrl: String,
    val workTitle: String,
    val coverUrl: String?,
    val chapterLabel: String?,
    val text: String,
    val postedAt: Long,
)

object ProfileStatsCalculator {
    private const val MILLIS_PER_DAY = 86_400_000L

    /** Days since 1970-01-01 in the time zone described by [offsetMillis]. */
    fun dayOf(epochMillis: Long, offsetMillis: Int): Long =
        Math.floorDiv(epochMillis + offsetMillis, MILLIS_PER_DAY)

    fun today(now: Long = System.currentTimeMillis()): Long =
        dayOf(now, TimeZone.getDefault().getOffset(now))

    /** 0 = Sunday ... 6 = Saturday. 1970-01-01 was a Thursday. */
    fun dayOfWeek(day: Long): Int = Math.floorMod(day + 4, 7L).toInt()

    fun compute(
        stats: List<ReadingDayStatEntity>,
        progress: List<ReadingProgressEntity>,
        library: List<LibraryMangaEntity>,
        today: Long,
        offsetMillis: Int,
    ): ProfileStats {
        val secondsByDay = HashMap<Long, Int>()
        stats.forEach { secondsByDay[it.day] = (secondsByDay[it.day] ?: 0) + it.seconds.coerceAtLeast(0) }

        val activeDays = HashSet<Long>()
        secondsByDay.forEach { (day, seconds) -> if (seconds > 0) activeDays.add(day) }
        progress.forEach { if (it.updatedAt > 0) activeDays.add(dayOf(it.updatedAt, offsetMillis)) }

        var streak = 0
        var cursor = if (today in activeDays) today else today - 1
        while (cursor in activeDays) {
            streak++
            cursor--
        }

        val bars = (today - 6..today).map { DayBar(it, secondsByDay[it] ?: 0) }

        val readKeys = progress.map { it.sourceId to it.mangaUrl }.toSet()
        val readWorks = library.filter { (it.sourceId to it.mangaUrl) in readKeys }.ifEmpty { library }
        val genreCounts = HashMap<String, Int>()
        readWorks.forEach { work ->
            work.genres.orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                .forEach { genreCounts[it] = (genreCounts[it] ?: 0) + 1 }
        }
        val topGenres = genreCounts.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(5).map { it.key to it.value }

        return ProfileStats(
            totalSeconds = secondsByDay.values.sumOf { it.toLong() },
            chaptersRead = progress.count { it.isComplete },
            weekBars = bars,
            weekSeconds = bars.sumOf { it.seconds },
            streakDays = streak,
            topGenres = topGenres,
            libraryCount = library.size,
        )
    }

    /** "3 س 20 د" / "45 د" / "0 د". */
    fun formatDuration(totalSeconds: Long): String {
        val minutes = (totalSeconds / 60).coerceAtLeast(0)
        val hours = minutes / 60
        val rest = minutes % 60
        return if (hours > 0) "$hours س $rest د" else "$rest د"
    }
}
