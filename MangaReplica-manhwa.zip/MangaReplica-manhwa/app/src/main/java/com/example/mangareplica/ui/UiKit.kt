@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.mangareplica

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.mangareplica.data.feed.NetworkStatus
import java.io.File

internal val AppPanel = Color(0xFF151821)
internal val AppMuted = Color(0xFFA8A29A)
internal val AppCoral: Color
    @Composable get() = MaterialTheme.colorScheme.primary

@Composable
internal fun AppPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        color = if (selected) AppCoral else AppPanel,
        border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Text(
            text,
            Modifier.padding(horizontal = 15.dp, vertical = 9.dp),
            color = if (selected) Color(0xFF1A0A06) else MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            softWrap = false,
        )
    }
}

@Composable
internal fun AppEmptyState(title: String, detail: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(vertical = 40.dp, horizontal = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.AutoStories, null, tint = AppCoral, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(5.dp))
        Text(detail, color = AppMuted, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        if (action != null && onAction != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAction, colors = ButtonDefaults.buttonColors(containerColor = AppCoral)) { Text(action) }
        }
    }
}

/** Circular avatar with a coral ring; shows a person icon when there is no (readable) picture. */
@Composable
internal fun AppAvatar(path: String, size: Dp, modifier: Modifier = Modifier, borderWidth: Dp = 1.5.dp) {
    val file = remember(path) { if (path.isBlank()) null else File(path).takeIf { it.isFile } }
    val ring = AppCoral
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(AppPanel)
            .border(borderWidth, ring, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (file != null) {
            AsyncImage(file, null, Modifier.size(size), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Default.Person, null, tint = AppMuted, modifier = Modifier.size(size * 0.55f))
        }
    }
}

/** Top-bar entry button for the profile: >= 44dp, coral ring, with a screen-reader label. */
@Composable
internal fun AppAvatarButton(path: String, onClick: () -> Unit, size: Dp = 46.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .semantics { contentDescription = "الملف الشخصي" }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        AppAvatar(path, size)
    }
}

@Composable
internal fun AppOfflineBanner(message: String = "أنت غير متصل · تُعرض آخر نتائج محفوظة") {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2A2018)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(Icons.Default.WifiOff, null, tint = AppCoral, modifier = Modifier.size(18.dp))
        Text(message, color = Color(0xFFE9D8CF), style = MaterialTheme.typography.bodySmall)
    }
}

/** Live connectivity flag. Falls back to "online" if the platform refuses to report. */
@Composable
internal fun rememberOnlineState(): State<Boolean> {
    val appContext = LocalContext.current.applicationContext
    val state = remember { mutableStateOf(NetworkStatus.isOnline(appContext)) }
    DisposableEffect(appContext) {
        val manager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { state.value = true }
            override fun onLost(network: Network) { state.value = NetworkStatus.isOnline(appContext) }
            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                state.value = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
        }
        runCatching {
            manager?.registerNetworkCallback(
                NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),
                callback,
            )
        }
        onDispose { runCatching { manager?.unregisterNetworkCallback(callback) } }
    }
    return state
}

internal fun timeAgoArabic(millis: Long?, now: Long = System.currentTimeMillis()): String {
    if (millis == null || millis <= 0L) return ""
    val minutes = ((now - millis) / 60_000L).coerceAtLeast(0)
    return when {
        minutes < 1 -> "الآن"
        minutes < 60 -> "منذ $minutes د"
        minutes < 60 * 24 -> "منذ ${minutes / 60} س"
        minutes < 60 * 24 * 30 -> "منذ ${minutes / (60 * 24)} يوم"
        else -> "منذ ${minutes / (60 * 24 * 30)} شهر"
    }
}
