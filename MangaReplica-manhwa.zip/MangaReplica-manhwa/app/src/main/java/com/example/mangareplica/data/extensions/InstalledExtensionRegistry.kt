package com.example.mangareplica.data.extensions

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import com.example.mangareplica.data.sources.MangaSource
import com.example.mangareplica.data.sources.SourceChapter
import com.example.mangareplica.data.sources.SourceManga
import com.example.mangareplica.data.sources.SourcePage
import dalvik.system.PathClassLoader
import eu.kanade.tachiyomi.network.MihonClientContract
import eu.kanade.tachiyomi.source.CatalogueSource
import eu.kanade.tachiyomi.source.Source
import eu.kanade.tachiyomi.source.SourceFactory
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.ResponseBody
import okhttp3.Request
import java.io.IOException
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Installed Mihon extension package plus the loaded source adapters, if it passed validation. */
data class InstalledExtension(
    val packageName: String,
    val label: String,
    val versionName: String,
    val libVersion: String,
    val signerFingerprint: String,
    val isTrusted: Boolean,
    val sources: List<MangaSource>,
    val state: String,
)

/**
 * Mihon-compatible extension runtime extracted and adapted from the user's manhwa-slime Mihon fork.
 * Only 1.4, 1.5 and 1.6 extension APIs are accepted; unknown or unsigned code is never loaded.
 */
class InstalledExtensionRegistry(context: Context) {
    private val appContext = context.applicationContext
    private val packageManager = appContext.packageManager
    private val trustPrefs = appContext.getSharedPreferences("mihon_extension_trust", Context.MODE_PRIVATE)

    fun all(): List<InstalledExtension> {
        MihonRuntimeServices.initialize(appContext)
        val extensions = installedPackages().asSequence()
            .filter(::isMihonExtension)
            .map(::inspectAndLoad)
            .sortedBy { it.label.lowercase() }
            .toList()
        Log.d(LOG_TAG, "stage=APKDetection extensions=${extensions.size}")
        return extensions
    }

    fun trustAndLoad(packageName: String): List<InstalledExtension> {
        val info = packageInfo(packageName) ?: return all()
        require(isMihonExtension(info)) { "الحزمة المحددة ليست إضافة Mihon" }
        val signer = signerFingerprint(info) ?: throw SecurityException("تعذر قراءة توقيع الإضافة")
        trustPrefs.edit().putBoolean("trusted:$signer", true).apply()
        return all()
    }

    private fun inspectAndLoad(info: PackageInfo): InstalledExtension {
        val appInfo = info.applicationInfo
        val label = metadataName(appInfo?.metaData)
            ?: runCatching { packageManager.getApplicationLabel(appInfo!!).toString().substringAfter("Tachiyomi: ") }
            .getOrDefault(info.packageName)
        val version = info.versionName.orEmpty()
        val signer = signerFingerprint(info).orEmpty()
        val metadata = appInfo?.metaData
        val libVersion = parseExtensionLibVersion(metadata?.get(METADATA_EXTENSION_LIB), version)
        val trusted = signer.isNotBlank() && trustPrefs.getBoolean("trusted:$signer", false)
        val base = InstalledExtension(info.packageName, label, version, libVersion, signer, trusted, emptyList(), "")

        if (signer.isBlank()) return base.copy(state = "بلا توقيع؛ رفض التحميل")
        if (!trusted) return base.copy(state = "يتطلب موافقة موثوقة قبل تحميل كود الإضافة")
        if (libVersion !in SUPPORTED_LIB_VERSIONS) {
            return base.copy(state = "إصدار واجهة غير مدعوم: ${libVersion.ifBlank { "غير معروف" }}")
        }
        if (metadata == null || appInfo?.sourceDir.isNullOrBlank()) {
            return base.copy(state = "بيانات الإضافة ناقصة")
        }

        var stage = "تحميل الفئات"
        return try {
            val classNames = metadata.getString(METADATA_SOURCE_CLASS).orEmpty()
                .split(';').map(String::trim).filter(String::isNotEmpty)
            require(classNames.isNotEmpty()) { "لا توجد فئات مصدر في بيانات APK" }
            val loader = extensionClassLoader(appInfo!!.sourceDir, appContext.classLoader)
            stage = "تهيئة الإضافة وإنشاء المصادر"
            val sources = classNames.flatMap { className ->
                val qualified = if (className.startsWith('.')) info.packageName + className else className
                when (val instance = Class.forName(qualified, false, loader).getDeclaredConstructor().newInstance()) {
                    is Source -> listOf(instance)
                    is SourceFactory -> instance.createSources()
                    else -> error("فئة الإضافة ليست Source أو SourceFactory")
                }
            }
            // Do not reject source-specific/custom clients here. The host's default client is
            // validated when NetworkHelper constructs it; extensions may legitimately override it.
            val nsfw = metadata.getInt(METADATA_NSFW, 0) == 1 || metadata.getInt(METADATA_CONTENT_WARNING, 0) != 0
            val adapters = sources.filterIsInstance<CatalogueSource>()
                .filter { it.lang.baseLanguage() in SUPPORTED_LANGUAGES }
                .distinctBy { "${it.lang.lowercase()}:${it.id}" }
                .map { MihonSourceAdapter(it, nsfw, info.packageName) }
            require(adapters.isNotEmpty()) {
                val languages = sources.map { it.lang }.distinct().sorted().joinToString(", ")
                if (languages.isBlank()) "الإضافة لا تحتوي مصدر فهرسة متوافقًا"
                else "لا توجد مصادر عربية أو إنجليزية في هذه الإضافة (لغاتها: $languages)"
            }
            Log.i(LOG_TAG, "stage=SourceRegistration package=${info.packageName} count=${adapters.size}")
            base.copy(sources = adapters, state = "تم تحميل ${adapters.size} مصدر فعلي")
        } catch (error: Throwable) {
            Log.e(LOG_TAG, "stage=$stage package=${info.packageName} error=${error.javaClass.name}")
            val detail = (error.cause?.message ?: error.message ?: error.javaClass.simpleName)
                .redactSensitiveQueryValues()
            base.copy(state = "فشل $stage (${error.javaClass.simpleName}): $detail")
        }
    }

    private fun installedPackages(): List<PackageInfo> {
        val flags = PACKAGE_FLAGS
        return if (Build.VERSION.SDK_INT >= 33) {
            packageManager.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getInstalledPackages(flags)
        }
    }

    private fun packageInfo(packageName: String): PackageInfo? = runCatching {
        if (Build.VERSION.SDK_INT >= 33) {
            packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(PACKAGE_FLAGS.toLong()))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, PACKAGE_FLAGS)
        }
    }.getOrNull()

    private fun isMihonExtension(info: PackageInfo): Boolean =
        info.reqFeatures.orEmpty().any { it.name == EXTENSION_FEATURE }

    private fun metadataName(metadata: android.os.Bundle?): String? =
        metadata?.getString(METADATA_NAME)?.takeIf(String::isNotBlank)

    private fun signerFingerprint(info: PackageInfo): String? {
        val raw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signing = info.signingInfo ?: return null
            if (signing.hasMultipleSigners()) signing.apkContentsSigners else signing.signingCertificateHistory
        } else {
            @Suppress("DEPRECATION")
            info.signatures
        }
        return raw?.firstOrNull()?.toByteArray()?.let { bytes ->
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        }
    }

    private fun extensionClassLoader(path: String, parent: ClassLoader): ClassLoader =
        SharedApiPathClassLoader(path, parent)

    private companion object {
        const val EXTENSION_FEATURE = "tachiyomi.extension"
        const val METADATA_SOURCE_CLASS = "tachiyomi.extension.class"
        const val METADATA_NAME = "tachiyomix.name"
        const val METADATA_EXTENSION_LIB = "tachiyomix.extensionLib"
        const val METADATA_NSFW = "tachiyomi.extension.nsfw"
        const val METADATA_CONTENT_WARNING = "tachiyomix.contentWarning"
        const val LOG_TAG = "MihonRuntime"
        val SUPPORTED_LIB_VERSIONS = setOf("1.4", "1.5", "1.6")
        val SUPPORTED_LANGUAGES = setOf("ar", "en")
        val PACKAGE_FLAGS = PackageManager.GET_META_DATA or PackageManager.GET_CONFIGURATIONS or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
    }
}

/**
 * Shares the exact host API class identities with the extension. Mihon source APKs can include
 * API bytecode; a plain DelegateLastClassLoader would load a second `Source`/`CatalogueSource`
 * class from the APK, making `instance is Source` false and silently preventing adapters from
 * being registered. Extension implementation and bundled site libraries remain child-first.
 */
private class SharedApiPathClassLoader(path: String, parent: ClassLoader) : PathClassLoader(path, null, parent) {
    override fun loadClass(name: String?, resolve: Boolean): Class<*> {
        requireNotNull(name)
        synchronized(this) {
            findLoadedClass(name)?.let { return it }
            if (SHARED_HOST_CLASS_PREFIXES.any(name::startsWith)) {
                try {
                    return parent.loadClass(name)
                } catch (_: ClassNotFoundException) {
                    // Fall back to extension code for optional host API types not present in this build.
                }
            }
            val extensionClass = runCatching { findClass(name) }.getOrNull()
            val loaded = extensionClass ?: parent.loadClass(name)
            if (resolve) resolveClass(loaded)
            return loaded
        }
    }

    private companion object {
        val SHARED_HOST_CLASS_PREFIXES = listOf(
            "eu.kanade.tachiyomi.source.",
            "eu.kanade.tachiyomi.network.",
            "eu.kanade.tachiyomi.util.",
            "tachiyomi.core.common.",
            "mihon.core.common.",
            "uy.kohesive.injekt.",
            "okhttp3.", "okio.", "rx.",
            "kotlin.", "kotlinx.", "org.jsoup.",
        )
    }
}

private class MihonSourceAdapter(
    private val source: CatalogueSource,
    override val isNsfw: Boolean,
    extensionPackageName: String,
) : MangaSource {
    private val mangaModels = ConcurrentHashMap<String, SManga>()
    private val chapterModels = ConcurrentHashMap<String, SChapter>()
    private val chapterLists = ConcurrentHashMap<String, List<SChapter>>()
    private val chapterMangaUrls = ConcurrentHashMap<String, String>()
    private val mangaLocks = ConcurrentHashMap<String, Mutex>()
    override val id: String = mihonSourceId(extensionPackageName, source.lang, source.id)
    override val name: String get() = source.name
    override val language: String get() = source.lang

    // Extension network code is blocking OkHttp under the hood; never run it on the caller's (often Main) thread.
    override suspend fun popular(page: Int): List<SourceManga> = withContext(Dispatchers.IO) {
        source.getPopularManga(page + 1).mangas.map(::toAppManga)
    }
    override suspend fun latest(page: Int): List<SourceManga> = withContext(Dispatchers.IO) {
        source.getLatestUpdates(page + 1).mangas.map(::toAppManga)
    }
    override suspend fun search(query: String, page: Int): List<SourceManga> = withContext(Dispatchers.IO) {
        source.getSearchManga(page + 1, query, FilterList()).mangas.map(::toAppManga)
    }

    override suspend fun details(manga: SourceManga): SourceManga = withContext(Dispatchers.IO) {
        lockFor(manga.url).withLock {
            val model = mangaModels[manga.url] ?: manga.toMihonManga()
            val updated = source.getMangaUpdate(model, emptyList(), fetchDetails = true, fetchChapters = false).manga
            toAppManga(updated)
        }
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> = withContext(Dispatchers.IO) {
        lockFor(manga.url).withLock {
            val model = mangaModels[manga.url] ?: manga.toMihonManga()
            val oldChapters = chapterLists[manga.url].orEmpty()
            val update = source.getMangaUpdate(model, oldChapters, fetchDetails = false, fetchChapters = true)
            chapterLists[manga.url] = update.chapters
            update.chapters.forEach {
                chapterModels[it.url] = it
                chapterMangaUrls[it.url] = manga.url
            }
            update.chapters.map { chapter ->
                SourceChapter(
                    sourceId = id,
                    url = chapter.url,
                    name = chapter.name,
                    number = chapter.chapter_number.takeIf { it >= 0f },
                    uploadDate = chapter.date_upload.takeIf { it > 0L },
                    language = source.lang,
                    externalUrl = null,
                )
            }
        }
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> = withContext(Dispatchers.IO) {
        lockFor(chapterMangaUrls[chapter.url] ?: chapter.url).withLock {
            val model = chapterModels[chapter.url] ?: SChapter.create().apply {
                url = chapter.url
                name = chapter.name
                chapter_number = chapter.number ?: -1f
                date_upload = chapter.uploadDate ?: 0L
            }
            val httpSource = source as? HttpSource
            val requestHeaders = httpSource?.headers?.toMultimap()
                ?.mapValues { (_, values) -> values.joinToString(",") }.orEmpty()
            val mihonPages = source.getPageList(model)
            val chapterReferer = httpSource?.getChapterUrl(model)
            mihonPages.mapIndexed { index, page ->
                val rawImageUrl = page.imageUrl ?: httpSource?.getImageUrl(page) ?: page.url
                val absoluteImageUrl = if (httpSource != null) runCatching {
                    URL(URL(httpSource.baseUrl), rawImageUrl).toString()
                }.getOrDefault(rawImageUrl) else rawImageUrl
                val headers = requestHeaders.toMutableMap()
                val referer = page.url.takeIf(String::isNotBlank) ?: chapterReferer
                    ?: httpSource?.baseUrl?.trimEnd('/')?.plus("/")
                SourcePage(index, absoluteImageUrl, referer, headers)
            }
        }
    }

    /** Keep page loads inside the extension's OkHttp client, including custom image interceptors. */
    override suspend fun loadPage(page: SourcePage, maxBytes: Long): ByteArray {
        val httpSource = source as? HttpSource ?: return super<MangaSource>.loadPage(page, maxBytes)
        return withContext(Dispatchers.IO) {
            val request = Request.Builder().url(page.imageUrl).get().apply {
                page.headers.forEach { (name, value) -> header(name, value) }
                page.referer?.let { header("Referer", it) }
            }.build()
            httpSource.client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("HTTP ${response.code} عند تحميل صفحة الفصل")
                val body = response.body ?: throw IOException("استجابة صفحة فارغة")
                val bytes = body.readBoundedImage(maxBytes)
                if (bytes.isEmpty()) throw IOException("ملف صفحة فارغ")
                bytes
            }
        }
    }

    private fun lockFor(key: String): Mutex = mangaLocks.getOrPut(key) { Mutex() }

    private fun toAppManga(manga: SManga): SourceManga {
        mangaModels[manga.url] = manga
        return SourceManga(
        sourceId = id,
        url = manga.url,
        title = manga.title,
        coverUrl = manga.thumbnail_url,
        description = manga.description,
        status = when (manga.status) {
            SManga.ONGOING -> "مستمر"
            SManga.COMPLETED, SManga.PUBLISHING_FINISHED -> "مكتمل"
            SManga.LICENSED -> "مرخّص"
            SManga.CANCELLED -> "ملغي"
            SManga.ON_HIATUS -> "متوقف مؤقتًا"
            else -> null
        },
        genres = manga.getGenres().orEmpty(),
        author = listOfNotNull(manga.author, manga.artist).distinct().joinToString("، ").ifBlank { null },
        originalLanguage = source.lang,
        )
    }

    private fun SourceManga.toMihonManga(): SManga = SManga.create().also {
        it.url = url
        it.title = title
        it.thumbnail_url = coverUrl
        it.description = description
        it.author = author
        it.genre = null
        it.status = SManga.UNKNOWN
    }
}

private fun String.baseLanguage(): String = trim().lowercase().substringBefore('-').substringBefore('_')

internal fun parseExtensionLibVersion(raw: Any?, extensionVersion: String): String = when (raw) {
    is String -> raw.trim().takeIf(String::isNotEmpty).orEmpty()
    is Number -> raw.toString().trim().takeIf { it != "0" && it != "0.0" }.orEmpty()
    else -> extensionVersion.substringBeforeLast('.', "").takeIf { it.contains('.') }.orEmpty()
}

internal fun mihonSourceId(extensionPackageName: String, language: String, sourceId: Long): String =
    "mihon:$extensionPackageName:${language.lowercase()}:$sourceId"

private fun String.redactSensitiveQueryValues(): String =
    replace(Regex("(?i)(cookie|authorization|token|password|session|key)=([^&\\s,;]+)"), "$1=[redacted]")
        .replace(Regex("([?&][^=\\s]+)=([^&\\s]+)"), "$1=[redacted]")

private fun ResponseBody.readBoundedImage(maxBytes: Long): ByteArray {
    if (contentLength() > maxBytes) throw IOException("حجم الصفحة يتجاوز الحد الآمن")
    val output = java.io.ByteArrayOutputStream()
    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
    var total = 0L
    byteStream().use { input ->
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > maxBytes) throw IOException("حجم الصفحة يتجاوز الحد الآمن")
            output.write(buffer, 0, count)
        }
    }
    return output.toByteArray()
}
