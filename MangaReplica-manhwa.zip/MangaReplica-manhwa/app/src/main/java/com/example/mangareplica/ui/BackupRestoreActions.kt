package com.example.mangareplica

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.collectAsState
import com.example.mangareplica.data.persistence.ReadingDayStatEntity
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.mangareplica.data.persistence.LibraryMangaEntity
import com.example.mangareplica.data.persistence.MangaCategoryEntity
import com.example.mangareplica.data.persistence.MangaRepository
import com.example.mangareplica.data.persistence.ReadingProgressEntity
import com.example.mangareplica.data.persistence.SearchHistoryEntity
import com.example.mangareplica.data.preferences.AppSettings
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream

@Composable
fun BackupRestoreActions(
    store: MangaRepository,
    library: List<LibraryMangaEntity>,
    progress: List<ReadingProgressEntity>,
    categories: List<MangaCategoryEntity>,
    searchHistory: List<SearchHistoryEntity>,
    settings: AppSettings,
    onUpdateSettings: (AppSettings) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<String?>(null) }
    val readingStats by store.observeReadingStats().collectAsState(initial = emptyList())

    val createBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri == null) {
            status = "أُلغيت عملية إنشاء النسخة."
        } else {
            scope.launch {
                status = runCatching {
                    val bytes = withContext(Dispatchers.Default) {
                        createBackupJson(library, progress, categories, searchHistory, settings, readingStats).toByteArray(Charsets.UTF_8)
                    }
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                            ?: error("تعذر فتح الملف المحدد للكتابة")
                    }
                    onUpdateSettings(settings.copy(lastBackupAt = System.currentTimeMillis()))
                    "تم حفظ النسخة الاحتياطية. ملفات الصور المنزّلة لا تُضمّن داخل JSON."
                }.getOrElse { "تعذر إنشاء النسخة: ${it.message ?: "خطأ غير معروف"}" }
            }
        }
    }

    val restoreBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            status = "أُلغيت عملية الاستعادة."
        } else {
            scope.launch {
                status = runCatching {
                    val jsonText = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { it.readBounded(MAX_BACKUP_BYTES).toString(Charsets.UTF_8) }
                            ?: error("تعذر فتح ملف النسخة")
                    }
                    val parsed = withContext(Dispatchers.Default) { parseBackup(jsonText) }
                    require(parsed.library.isNotEmpty() || parsed.progress.isNotEmpty() || parsed.categories.isNotEmpty()) {
                        "لا توجد بيانات مكتبة أو تقدم أو تصنيفات في الملف"
                    }
                    store.saveManga(parsed.library)
                    parsed.progress.forEach { store.saveProgress(it) }
                    val currentCategoryNames = categories.map { it.name.trim().lowercase() }.toSet()
                    parsed.categories.filter { it.name.trim().lowercase() !in currentCategoryNames }
                        .forEach { store.saveCategory(it) }
                    parsed.searchHistory.forEach { store.recordSearch(it.query, it.searchedAt) }
                    store.mergeReadingStats(parsed.readingStats)
                    parsed.settings?.let { restored ->
                        // Restoring a file must never silently opt the user into adult content.
                        onUpdateSettings(restored.copy(hideAdultContent = true))
                    }
                    "اكتملت الاستعادة والدمج. التنزيلات المحلية غير موجودة في النسخة، وقد تحتاج لإعادة تنزيل الفصول."
                }.getOrElse { "تعذر استعادة النسخة: ${it.message ?: "ملف غير صالح"}" }
            }
        }
    }

    Column(Modifier.fillMaxWidth().padding(top = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("النسخ الاحتياطي والاستعادة")
        Text("يشمل الملف بيانات المكتبة، تقدم القراءة، إحصائيات القراءة، الملف الشخصي، التصنيفات، سجل البحث والإعدادات. لا ينسخ صور الفصول أو ملفات APK.")
        Button(onClick = { createBackup.launch("mangareplica-backup.json") }, modifier = Modifier.fillMaxWidth()) {
            Text("إنشاء نسخة احتياطية")
        }
        OutlinedButton(onClick = { restoreBackup.launch(arrayOf("application/json", "text/*", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) {
            Text("استعادة ودمج نسخة JSON")
        }
        status?.let { Text(it) }
    }
}

private data class BackupData(
    val library: List<LibraryMangaEntity>,
    val progress: List<ReadingProgressEntity>,
    val categories: List<MangaCategoryEntity>,
    val searchHistory: List<SearchHistoryEntity>,
    val settings: AppSettings?,
    val readingStats: List<ReadingDayStatEntity> = emptyList()
)

private fun createBackupJson(
    library: List<LibraryMangaEntity>,
    progress: List<ReadingProgressEntity>,
    categories: List<MangaCategoryEntity>,
    searchHistory: List<SearchHistoryEntity>,
    settings: AppSettings,
    readingStats: List<ReadingDayStatEntity> = emptyList()
): String = JSONObject()
    .put("format", "mangareplica-backup")
    .put("schemaVersion", 1)
    .put("createdAt", System.currentTimeMillis())
    .put("library", JSONArray().apply {
        library.forEach { item -> put(JSONObject()
            .put("sourceId", item.sourceId).put("mangaUrl", item.mangaUrl).put("title", item.title)
            .put("coverUrl", item.coverUrl).put("description", item.description).put("status", item.status)
            .put("isRead", item.isRead).put("isFavorite", item.isFavorite).put("isCompleted", item.isCompleted)
            .put("categoryId", item.categoryId).put("createdAt", item.createdAt).put("updatedAt", item.updatedAt).put("genres", item.genres)) }
    })
    .put("progress", JSONArray().apply {
        progress.forEach { item -> put(JSONObject()
            .put("sourceId", item.sourceId).put("mangaUrl", item.mangaUrl).put("chapterUrl", item.chapterUrl)
            .put("pageIndex", item.pageIndex).put("isComplete", item.isComplete).put("updatedAt", item.updatedAt).put("pageCount", item.pageCount)) }
    })
    .put("categories", JSONArray().apply {
        categories.forEach { item -> put(JSONObject().put("id", item.id).put("name", item.name).put("createdAt", item.createdAt)) }
    })
    .put("searchHistory", JSONArray().apply {
        searchHistory.forEach { item -> put(JSONObject().put("query", item.query).put("searchedAt", item.searchedAt)) }
    })
    .put("readingStats", JSONArray().apply {
        readingStats.forEach { item -> put(JSONObject().put("day", item.day).put("seconds", item.seconds)) }
    })
    .put("settings", JSONObject(Gson().toJson(settings)))
    .toString(2)

private fun parseBackup(value: String): BackupData {
    val root = JSONObject(value)
    require(root.optString("format") == "mangareplica-backup") { "نوع ملف النسخة غير معروف" }
    require(root.optInt("schemaVersion", -1) == 1) { "إصدار ملف النسخة غير مدعوم" }

    val library = root.optJSONArray("library").toObjects { row ->
        val sourceId = row.optString("sourceId").trim()
        val mangaUrl = row.optString("mangaUrl").trim()
        val title = row.optString("title").trim()
        require(sourceId.isNotEmpty() && mangaUrl.isNotEmpty() && title.isNotEmpty()) { "سجل عمل غير مكتمل" }
        LibraryMangaEntity(
            sourceId = sourceId, mangaUrl = mangaUrl, title = title,
            coverUrl = row.optNullableString("coverUrl"), description = row.optNullableString("description"), status = row.optNullableString("status"),
            isRead = row.optBoolean("isRead"), isFavorite = row.optBoolean("isFavorite"), isCompleted = row.optBoolean("isCompleted"),
            categoryId = row.optNullableString("categoryId"), createdAt = row.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = row.optLong("updatedAt", System.currentTimeMillis()),
            genres = row.optNullableString("genres")
        )
    }
    val progress = root.optJSONArray("progress").toObjects { row ->
        val sourceId = row.optString("sourceId").trim(); val mangaUrl = row.optString("mangaUrl").trim(); val chapterUrl = row.optString("chapterUrl").trim()
        require(sourceId.isNotEmpty() && mangaUrl.isNotEmpty() && chapterUrl.isNotEmpty()) { "سجل تقدم غير مكتمل" }
        ReadingProgressEntity(sourceId, mangaUrl, chapterUrl, row.optInt("pageIndex").coerceAtLeast(0), row.optBoolean("isComplete"), row.optLong("updatedAt", System.currentTimeMillis()), row.optInt("pageCount").coerceAtLeast(0))
    }
    val categories = root.optJSONArray("categories").toObjects { row ->
        val id = row.optString("id").trim(); val name = row.optString("name").trim()
        require(id.isNotEmpty() && name.isNotEmpty()) { "تصنيف غير مكتمل" }
        MangaCategoryEntity(id, name, row.optLong("createdAt", System.currentTimeMillis()))
    }
    val searchHistory = root.optJSONArray("searchHistory").toObjects { row ->
        val query = row.optString("query").trim()
        if (query.isEmpty()) null else SearchHistoryEntity(query = query, searchedAt = row.optLong("searchedAt", System.currentTimeMillis()))
    }.filterNotNull()
    val settings = root.optJSONObject("settings")?.let { Gson().fromJson(it.toString(), AppSettings::class.java) }
    val readingStats = root.optJSONArray("readingStats").toObjects { row ->
        val day = row.optLong("day", Long.MIN_VALUE); val seconds = row.optInt("seconds", 0)
        if (day == Long.MIN_VALUE || seconds <= 0) null else ReadingDayStatEntity(day, seconds)
    }
    return BackupData(library, progress, categories, searchHistory, settings, readingStats)
}

private inline fun <T> JSONArray?.toObjects(transform: (JSONObject) -> T?): List<T> {
    if (this == null) return emptyList()
    val values = mutableListOf<T>()
    for (index in 0 until length()) {
        val row = optJSONObject(index) ?: error("عنصر JSON غير صالح في الموضع $index")
        transform(row)?.let(values::add)
    }
    return values
}

private fun JSONObject.optNullableString(name: String): String? = if (isNull(name)) null else optString(name).takeIf(String::isNotBlank)

private fun InputStream.readBounded(limit: Int): ByteArray {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(8 * 1024)
    while (true) {
        val count = read(buffer)
        if (count < 0) break
        require(output.size() + count <= limit) { "ملف النسخة أكبر من الحد المسموح" }
        output.write(buffer, 0, count)
    }
    return output.toByteArray()
}

private const val MAX_BACKUP_BYTES = 20 * 1024 * 1024
