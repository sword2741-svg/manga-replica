package com.example.mangareplica.data.persistence

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** A manga saved in the user's library. The source-local URL is its stable identity. */
@Entity(
    tableName = "library_manga",
    primaryKeys = ["sourceId", "mangaUrl"],
    indices = [Index(value = ["categoryId"]), Index(value = ["isFavorite"]), Index(value = ["isCompleted"]), Index(value = ["updatedAt"])],
)
data class LibraryMangaEntity(
    val sourceId: String,
    val mangaUrl: String,
    val title: String,
    val coverUrl: String? = null,
    val description: String? = null,
    val status: String? = null,
    val isRead: Boolean = false,
    val isFavorite: Boolean = false,
    val isCompleted: Boolean = false,
    val categoryId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    /** Comma-separated genres captured when the work was saved; used for reading statistics. */
    val genres: String? = null,
)

@Entity(
    tableName = "reading_progress",
    primaryKeys = ["sourceId", "mangaUrl", "chapterUrl"],
    indices = [Index(value = ["sourceId", "mangaUrl"]), Index(value = ["updatedAt"])],
)
data class ReadingProgressEntity(
    val sourceId: String,
    val mangaUrl: String,
    val chapterUrl: String,
    val pageIndex: Int,
    val isComplete: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis(),
    /** Number of pages when last read; 0 when unknown. */
    @ColumnInfo(defaultValue = "0") val pageCount: Int = 0,
)

@Entity(
    tableName = "chapter_downloads",
    primaryKeys = ["sourceId", "mangaUrl", "chapterUrl"],
    indices = [Index(value = ["status"]), Index(value = ["sourceId", "mangaUrl"])],
)
data class ChapterDownloadEntity(
    val sourceId: String,
    val mangaUrl: String,
    val chapterUrl: String,
    val mangaTitle: String = "",
    val mangaCoverUrl: String? = null,
    val chapterName: String = "",
    val chapterNumber: Float? = null,
    val localPath: String? = null,
    /** Suggested values: queued, downloading, completed, failed, paused. */
    val status: String = "queued",
    /** Progress in the inclusive range 0..100. */
    val progressPercent: Int = 0,
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "search_history", indices = [Index(value = ["searchedAt"])])
data class SearchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val query: String,
    val searchedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "manga_categories", indices = [Index(value = ["name"], unique = true)])
data class MangaCategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)
