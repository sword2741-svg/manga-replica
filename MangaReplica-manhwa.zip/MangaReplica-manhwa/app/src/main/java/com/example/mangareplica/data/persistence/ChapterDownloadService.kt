package com.example.mangareplica.data.persistence

import android.content.Context
import com.example.mangareplica.data.sources.SourceChapter
import com.example.mangareplica.data.sources.SourceMangaRef
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.security.MessageDigest

class ChapterDownloadService(
    context: Context,
    private val repository: MangaRepository,
) {
    private val appContext = context.applicationContext

    suspend fun download(ref: SourceMangaRef, chapter: SourceChapter): File = withContext(Dispatchers.IO) {
        require(chapter.externalUrl.isNullOrBlank()) { "الفصل يُقرأ لدى ناشر خارجي ولا يوفّر صفحات للتنزيل داخل التطبيق" }
        val record = ChapterDownloadEntity(
            sourceId = ref.source.id,
            mangaUrl = ref.manga.url,
            chapterUrl = chapter.url,
            mangaTitle = ref.manga.title,
            mangaCoverUrl = ref.manga.coverUrl,
            chapterName = chapter.name,
            chapterNumber = chapter.number,
            status = "downloading",
            progressPercent = 0,
        )
        repository.saveDownload(record)
        val targetDir = File(appContext.filesDir, "downloads/${stableId(ref.source.id)}/${stableId(ref.manga.url)}/${stableId(chapter.url)}")
        val stagingDir = File(targetDir.parentFile, targetDir.name + ".part")
        runCatching { stagingDir.deleteRecursively() }
        if (!stagingDir.mkdirs()) throw IOException("تعذر إنشاء مجلد التنزيل")
        try {
            val pages = ref.source.pages(chapter)
            require(pages.isNotEmpty()) { "المصدر لم يُرجع صفحات لهذا الفصل" }
            require(pages.size <= MAX_PAGES) { "عدد صفحات الفصل يتجاوز الحد الآمن" }
            pages.sortedBy { it.index }.forEachIndexed { index, page ->
                require(page.imageUrl.startsWith("https://", true) || page.imageUrl.startsWith("http://", true)) { "رابط صفحة غير صالح" }
                val bytes = ref.source.loadPage(page, MAX_PAGE_BYTES)
                if (bytes.size > MAX_PAGE_BYTES) throw IOException("حجم الصفحة يتجاوز الحد الآمن")
                File(stagingDir, "page-${index.toString().padStart(4, '0')}.img").writeBytes(bytes)
                val percent = ((index + 1) * 100 / pages.size)
                repository.saveDownload(record.copy(localPath = targetDir.absolutePath, progressPercent = percent, updatedAt = System.currentTimeMillis()))
            }
            if (targetDir.exists()) targetDir.deleteRecursively()
            if (!stagingDir.renameTo(targetDir)) throw IOException("تعذر إنهاء حفظ الفصل")
            repository.saveDownload(record.copy(localPath = targetDir.absolutePath, status = "completed", progressPercent = 100, updatedAt = System.currentTimeMillis()))
            targetDir
        } catch (cancelled: CancellationException) {
            stagingDir.deleteRecursively()
            repository.saveDownload(record.copy(status = "paused", progressPercent = 0, updatedAt = System.currentTimeMillis()))
            throw cancelled
        } catch (error: Exception) {
            stagingDir.deleteRecursively()
            repository.saveDownload(record.copy(status = "failed", progressPercent = 0, updatedAt = System.currentTimeMillis()))
            throw error
        }
    }

    companion object {
        private const val MAX_PAGE_BYTES = 25 * 1024 * 1024L
        private const val MAX_PAGES = 2_000
        private fun stableId(value: String): String = MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }.take(24)
    }
}
