@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.mangareplica

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.mangareplica.data.persistence.LibraryMangaEntity
import com.example.mangareplica.data.persistence.ReadingDayStatEntity
import com.example.mangareplica.data.persistence.ReadingProgressEntity
import com.example.mangareplica.data.preferences.AppSettings
import com.example.mangareplica.data.profile.ProfileAccount
import com.example.mangareplica.data.profile.ProfileComment
import com.example.mangareplica.data.profile.ProfileStatsCalculator
import java.text.DateFormat
import java.util.Date
import java.util.TimeZone

private val DAY_NAMES = listOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")
private const val BACKUP_REMINDER_MS = 14L * 24L * 60L * 60L * 1000L

/**
 * Local-first profile. Level, VIP, verification and comments need an account/server, so they are
 * shown only when [account] / [comments] actually carry data; nothing is invented.
 */
@Composable
fun ProfileScreen(
    settings: AppSettings,
    library: List<LibraryMangaEntity>,
    progress: List<ReadingProgressEntity>,
    stats: List<ReadingDayStatEntity>,
    comments: List<ProfileComment>,
    account: ProfileAccount?,
    onBack: () -> Unit,
    onOpenWork: (LibraryMangaEntity) -> Unit,
    onOpenComment: (ProfileComment) -> Unit,
    onSaveProfile: (String, String, Uri?) -> Unit,
    onShare: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenBackup: () -> Unit,
) {
    val coral = AppCoral
    val now = System.currentTimeMillis()
    val offset = TimeZone.getDefault().getOffset(now)
    val computed = remember(stats, progress, library) {
        ProfileStatsCalculator.compute(stats, progress, library, ProfileStatsCalculator.today(now), offset)
    }
    var tab by rememberSaveable { mutableStateOf("library") }
    var menu by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    val displayName = settings.profileName.ifBlank { "قارئ مانهوا" }
    val backupDue = (library.isNotEmpty() || progress.isNotEmpty()) &&
        (settings.lastBackupAt == 0L || now - settings.lastBackupAt > BACKUP_REMINDER_MS)

    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 32.dp)) {
        item(key = "banner") {
            Box(Modifier.fillMaxWidth().height(206.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(150.dp)
                        .clip(RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp))
                        .background(Brush.verticalGradient(listOf(coral, Color(0xFF3A1F1A), Color(0xFF151821)))),
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "المزيد", tint = Color.White) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("تعديل الملف الشخصي") }, onClick = { menu = false; editing = true })
                            DropdownMenuItem(
                                text = { Text("مشاركة الملف") },
                                onClick = {
                                    menu = false
                                    onShare("$displayName على مانهوا: ${computed.chaptersRead} فصلاً مقروءاً · ${ProfileStatsCalculator.formatDuration(computed.totalSeconds)} قراءة")
                                },
                            )
                            DropdownMenuItem(text = { Text("الإعدادات") }, onClick = { menu = false; onOpenSettings() })
                        }
                    }
                }
                AppAvatar(settings.profileAvatarPath, 100.dp, Modifier.align(Alignment.BottomCenter), borderWidth = 3.dp)
            }
        }
        item(key = "identity") {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(displayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (account?.isVerified == true) Icon(Icons.Default.Verified, "حساب موثّق", tint = coral)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    account?.level?.let { level ->
                        Text("المستوى $level", Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0x33FF6B4A)).padding(horizontal = 10.dp, vertical = 3.dp), color = coral, style = MaterialTheme.typography.labelMedium)
                    }
                    if (account?.isVip == true) {
                        Text("VIP", Modifier.clip(RoundedCornerShape(10.dp)).background(coral).padding(horizontal = 10.dp, vertical = 3.dp), color = Color(0xFF1A0A06), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                    if (settings.profileJoinedAt > 0L) {
                        Text("انضم في ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(settings.profileJoinedAt))}", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (settings.profileBio.isNotBlank()) Text(settings.profileBio, color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center)
                else Text("أضف نبذة قصيرة من «تعديل الملف الشخصي».", color = AppMuted, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
            }
        }
        item(key = "stat-cards") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("وقت القراءة", ProfileStatsCalculator.formatDuration(computed.totalSeconds), Modifier.weight(1f))
                StatCard("فصول مقروءة", computed.chaptersRead.toString(), Modifier.weight(1f))
            }
        }
        if (backupDue) {
            item(key = "backup") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF2A2018)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("خذ نسخة احتياطية", fontWeight = FontWeight.Bold)
                        Text(
                            if (settings.lastBackupAt == 0L) "بياناتك محفوظة على هذا الجهاز فقط وتضيع إن حُذف التطبيق."
                            else "مرّ أكثر من أسبوعين على آخر نسخة احتياطية.",
                            color = AppMuted, style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    TextButton(onClick = onOpenBackup) { Text("نسخ الآن", color = coral) }
                }
            }
        }
        item(key = "tabs") {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppPill("المكتبة (${library.size})", tab == "library") { tab = "library" }
                if (comments.isNotEmpty()) AppPill("التعليقات (${comments.size})", tab == "comments") { tab = "comments" }
                AppPill("الإحصائيات", tab == "stats") { tab = "stats" }
            }
        }
        val activeTab = if (tab == "comments" && comments.isEmpty()) "library" else tab
        when (activeTab) {
            "library" -> {
                if (library.isEmpty()) {
                    item(key = "library-empty") { AppEmptyState("مكتبتك فارغة", "أضف الأعمال من صفحاتها لتظهر هنا.") }
                } else {
                    items(library.chunked(3), key = { row -> row.first().sourceId + "|" + row.first().mangaUrl }) { row ->
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { work ->
                                Column(Modifier.weight(1f).clickable { onOpenWork(work) }) {
                                    Box(Modifier.fillMaxWidth().aspectRatio(0.7f).clip(RoundedCornerShape(12.dp)).background(AppPanel)) {
                                        work.coverUrl?.takeIf { it.isNotBlank() }?.let { AsyncImage(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                                    }
                                    Text(work.title, Modifier.padding(top = 4.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            "comments" -> items(comments, key = { it.sourceId + "|" + it.mangaUrl + "|" + it.postedAt }) { comment ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clip(RoundedCornerShape(16.dp)).background(AppPanel)
                        .clickable { onOpenComment(comment) }.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(Modifier.size(48.dp, 66.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF232733))) {
                        comment.coverUrl?.takeIf { it.isNotBlank() }?.let { AsyncImage(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(comment.workTitle, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                            comment.chapterLabel?.let { Text(it, color = coral, style = MaterialTheme.typography.labelSmall) }
                        }
                        Text(comment.text, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Text(timeAgoArabic(comment.postedAt, now), color = AppMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            else -> {
                item(key = "week") {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(AppPanel).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("وقت القراءة هذا الأسبوع", fontWeight = FontWeight.Bold)
                        Text(ProfileStatsCalculator.formatDuration(computed.weekSeconds.toLong()), color = coral, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                        val maxSeconds = computed.weekBars.maxOf { it.seconds }.coerceAtLeast(1)
                        Row(Modifier.fillMaxWidth().height(110.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                            computed.weekBars.forEach { bar ->
                                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                    Box(
                                        Modifier.fillMaxWidth(0.6f)
                                            .fillMaxHeight((bar.seconds.toFloat() / maxSeconds * 0.75f).coerceAtLeast(0.03f))
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (bar.seconds > 0) coral else Color(0xFF232733)),
                                    )
                                    Text(DAY_NAMES[ProfileStatsCalculator.dayOfWeek(bar.day)], color = AppMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                }
                            }
                        }
                    }
                }
                item(key = "numbers") {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard("عدد الفصول", computed.chaptersRead.toString(), Modifier.weight(1f))
                        StatCard("أيام متتالية", computed.streakDays.toString(), Modifier.weight(1f))
                    }
                }
                if (computed.topGenres.isNotEmpty()) {
                    item(key = "genres") {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(AppPanel).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("أكثر التصنيفات قراءةً", fontWeight = FontWeight.Bold)
                            val top = computed.topGenres.first().second.coerceAtLeast(1)
                            computed.topGenres.forEach { (genre, count) ->
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(genre, Modifier.weight(0.35f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                    Box(Modifier.weight(0.65f).height(8.dp).clip(CircleShape).background(Color(0xFF232733))) {
                                        Box(Modifier.fillMaxWidth(count.toFloat() / top).fillMaxHeight().clip(CircleShape).background(coral))
                                    }
                                }
                            }
                        }
                    }
                }
                if (!computed.hasAnyData) {
                    item(key = "stats-empty") { AppEmptyState("لا توجد إحصائيات بعد", "ابدأ القراءة وستظهر أرقامك هنا.") }
                }
            }
        }
    }

    if (editing) {
        var name by remember { mutableStateOf(settings.profileName) }
        var bio by remember { mutableStateOf(settings.profileBio) }
        var picked by remember { mutableStateOf<Uri?>(null) }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) picked = uri }
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text("تعديل الملف الشخصي") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.clickable { launcher.launch("image/*") }, contentAlignment = Alignment.Center) {
                        if (picked != null) {
                            AsyncImage(picked, null, Modifier.size(84.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                        } else {
                            AppAvatar(settings.profileAvatarPath, 84.dp)
                        }
                    }
                    OutlinedButton(onClick = { launcher.launch("image/*") }) { Text("اختيار صورة") }
                    OutlinedTextField(name, { name = it.take(40) }, Modifier.fillMaxWidth(), label = { Text("الاسم") }, singleLine = true)
                    OutlinedTextField(bio, { bio = it.take(160) }, Modifier.fillMaxWidth(), label = { Text("نبذة قصيرة") }, maxLines = 3)
                }
            },
            confirmButton = {
                Button(
                    onClick = { onSaveProfile(name.trim(), bio.trim(), picked); editing = false },
                    colors = ButtonDefaults.buttonColors(containerColor = coral, contentColor = Color(0xFF1A0A06)),
                ) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { editing = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(AppPanel).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = AppCoral)
        Text(label, color = AppMuted, style = MaterialTheme.typography.bodyMedium)
    }
}
