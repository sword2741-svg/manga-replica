package com.example.mangareplica.data.sources

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.URI
import java.util.concurrent.TimeUnit

/** Stable app-level contract shared by native providers and Mihon-compatible adapters. */
interface MangaSource {
    val id: String
    val name: String
    val language: String
    val isNsfw: Boolean get() = false
    /** First-party adapters are always active and are not exposed in source-management UI. */
    val isBuiltIn: Boolean get() = false

    suspend fun popular(page: Int): List<SourceManga>
    suspend fun latest(page: Int): List<SourceManga> = popular(page)
    suspend fun search(query: String, page: Int): List<SourceManga>
    suspend fun details(manga: SourceManga): SourceManga
    suspend fun chapters(manga: SourceManga): List<SourceChapter>
    suspend fun pages(chapter: SourceChapter): List<SourcePage>

    /**
     * Fetches image bytes through the source's own network stack. Extensions may return virtual
     * image URLs handled by their OkHttp interceptors, so callers must not replace this with Coil's
     * independent HTTP client.
     */
    suspend fun loadPage(page: SourcePage, maxBytes: Long = DEFAULT_MAX_PAGE_BYTES): ByteArray = withContext(Dispatchers.IO) {
        val uri = runCatching { URI(page.imageUrl) }.getOrNull()
        if (uri != null && uri.scheme.equals("file", ignoreCase = true)) {
            val file = File(uri)
            if (file.length() > maxBytes) throw IOException("حجم الصفحة يتجاوز الحد الآمن")
            return@withContext file.readBytes()
        }

        val request = Request.Builder().url(page.imageUrl).get().apply {
            header("User-Agent", page.headers["User-Agent"] ?: DEFAULT_SOURCE_PAGE_USER_AGENT)
            header("Accept", page.headers["Accept"] ?: "image/avif,image/webp,image/*,*/*;q=0.8")
            page.headers.forEach { (name, value) -> header(name, value) }
            page.referer?.let { header("Referer", it) }
        }.build()
        pageHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code} عند تحميل صفحة الفصل")
            val body = response.body ?: throw IOException("استجابة صفحة فارغة")
            if (body.contentLength() > maxBytes) throw IOException("حجم الصفحة يتجاوز الحد الآمن")
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            var total = 0L
            body.byteStream().use { input ->
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > maxBytes) throw IOException("حجم الصفحة يتجاوز الحد الآمن")
                    output.write(buffer, 0, count)
                }
            }
            val bytes = output.toByteArray()
            if (bytes.isEmpty()) throw IOException("ملف صفحة فارغ")
            bytes
        }
    }
}

private val pageHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
}

private const val DEFAULT_MAX_PAGE_BYTES = 25L * 1024 * 1024
private const val DEFAULT_SOURCE_PAGE_USER_AGENT = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 Chrome/131.0.0.0 Mobile Safari/537.36"

data class SourceManga(
    val sourceId: String,
    val url: String,
    val title: String,
    val coverUrl: String? = null,
    val description: String? = null,
    val status: String? = null,
    val genres: List<String> = emptyList(),
    val author: String? = null,
    val year: Int? = null,
    val rating: Double? = null,
    val originalLanguage: String? = null
)

data class SourceChapter(
    val sourceId: String,
    val url: String,
    val name: String,
    val number: Float? = null,
    val uploadDate: Long? = null,
    val language: String? = null,
    val externalUrl: String? = null
)

data class SourcePage(
    val index: Int,
    val imageUrl: String,
    val referer: String? = null,
    val headers: Map<String, String> = emptyMap()
)
