package com.example.mangareplica.data.sources

/**
 * One row of a chapter list. Chapters that share the same chapter number (different scanlators,
 * re-uploads, mirrors) are merged into a single entry; [chapters] holds every variant.
 */
data class ChapterEntry(val key: String, val chapters: List<SourceChapter>) {
    val primary: SourceChapter get() = chapters.first()
    val number: Float? get() = primary.number?.takeIf { it >= 0f }
    val hasVariants: Boolean get() = chapters.size > 1
    val latestDate: Long? get() = chapters.mapNotNull { it.uploadDate }.maxOrNull()
}

object ChapterGrouping {
    fun group(chapters: List<SourceChapter>): List<ChapterEntry> {
        val grouped = LinkedHashMap<String, MutableList<SourceChapter>>()
        chapters.forEach { chapter ->
            val number = chapter.number?.takeIf { it >= 0f }
            val key = if (number != null) "n:$number" else "u:${chapter.url}"
            grouped.getOrPut(key) { mutableListOf() }.add(chapter)
        }
        return grouped.map { (key, variants) -> ChapterEntry(key, variants) }
    }

    /**
     * Orders entries newest first or oldest first. Entries are sorted by chapter number when every
     * entry has one; otherwise the source's own order (assumed newest first) is kept.
     */
    fun order(entries: List<ChapterEntry>, newestFirst: Boolean): List<ChapterEntry> {
        val numeric = entries.isNotEmpty() && entries.all { it.number != null }
        val base = if (numeric) entries.sortedByDescending { it.number } else entries
        return if (newestFirst) base else base.reversed()
    }

    fun formatNumber(number: Float?): String = when {
        number == null -> ""
        number % 1f == 0f -> number.toInt().toString()
        else -> number.toString()
    }
}
