package com.example.mangareplica.data.sources

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.text.Normalizer
import java.util.Locale

/** One source-local record inside a title that may exist in several sources. */
data class SourceMangaRef(val source: MangaSource, val manga: SourceManga)

data class MangaGroup(
    val normalizedTitle: String,
    val title: String,
    val sources: List<SourceMangaRef>
) {
    val preferred: SourceMangaRef get() = sources.first()
    val sourceLabels: List<String> get() = sources.map { it.source.name }.distinct()
}

data class SourceFailure(val sourceId: String, val sourceName: String, val message: String)
data class FederatedPage(val groups: List<MangaGroup>, val failures: List<SourceFailure>)

/**
 * Calls the fixed first-party providers concurrently. A slow or failed provider cannot discard
 * successful providers; identical titles are coalesced into a single result group.
 */
class FederatedSourceRepository(
    private val registry: NativeSourceRegistry,
    private val perSourceTimeoutMs: Long = 6_500L,
    private val includeAdultContent: Boolean = false
) {
    suspend fun popular(page: Int, enabledSourceIds: Set<String>? = null): FederatedPage =
        aggregate(page, enabledSourceIds) { source -> source.popular(page) }

    suspend fun latest(page: Int, enabledSourceIds: Set<String>? = null): FederatedPage =
        aggregate(page, enabledSourceIds) { source -> source.latest(page) }

    suspend fun search(
        query: String,
        page: Int,
        enabledSourceIds: Set<String>? = null
    ): FederatedPage {
        if (query.isBlank()) return FederatedPage(emptyList(), emptyList())
        return aggregate(page, enabledSourceIds) { source -> source.search(query.trim(), page) }
    }

    private suspend fun aggregate(
        page: Int,
        enabledSourceIds: Set<String>?,
        request: suspend (MangaSource) -> List<SourceManga>
    ): FederatedPage = withContext(Dispatchers.IO) {
        require(page >= 0) { "Page cannot be negative" }
        val selectedSources = registry.all().filter { source ->
            (source.isBuiltIn || enabledSourceIds == null || source.id in enabledSourceIds) &&
                // This guard is intentionally applied again at the service boundary.
                (includeAdultContent || !source.isNsfw)
        }
        val outcomes = supervisorScope {
            selectedSources.map { source ->
                async {
                    try {
                        val response = withTimeoutOrNull(perSourceTimeoutMs) { request(source) }
                        if (response == null) {
                            source to Result.failure<List<SourceManga>>(IllegalStateException("انتهت مهلة المصدر"))
                        } else source to Result.success(response)
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (error: Throwable) {
                        // Extension code can fail with Exception, LinkageError (missing host class) or
                        // other Errors; none of them may take down the other sources.
                        source to Result.failure(error)
                    }
                }
            }.map { it.await() }
        }

        val failures = outcomes.mapNotNull { (source, result) ->
            result.exceptionOrNull()?.let { error ->
                val root = generateSequence(error) { it.cause }.last()
                val detail = listOfNotNull(root::class.simpleName, root.message).joinToString(": ")
                    .ifBlank { "خطأ غير معروف" }
                SourceFailure(source.id, source.name, detail)
            }
        }
        val refs = outcomes.flatMap { (source, result) ->
            result.getOrNull().orEmpty().map { manga -> SourceMangaRef(source, manga) }
        }
        val groups = LinkedHashMap<String, MutableList<SourceMangaRef>>()
        refs.forEach { ref ->
            val key = normalizeTitle(ref.manga.title)
            if (key.isNotBlank()) groups.getOrPut(key) { mutableListOf() }.add(ref)
        }
        FederatedPage(
            groups = groups.map { (key, variants) -> MangaGroup(key, variants.first().manga.title, variants) },
            failures = failures
        )
    }

    companion object {
        /** Stable, locale-independent key for deduplicating transliteration/diacritic variants. */
        fun normalizeTitle(value: String): String {
            val folded = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFKD)
                .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
                .replace('ى', 'ي')
            return folded.filter { Character.isLetterOrDigit(it) }
        }
    }
}
