package com.example.mangareplica.data.extensions

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

/** Fetches and parses the current Keiyoushi protobuf index, with a full-JSON fallback. */
class ExtensionStoreRepository(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {
    companion object {
        const val DEFAULT_REPOSITORY = "https://github.com/keiyoushi/extensions/raw/repo/index.pb"
        private const val MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024
    }

    suspend fun refresh(repositoryIndexUrl: String = DEFAULT_REPOSITORY): Result<ExtensionCatalog> =
        withContext(Dispatchers.IO) {
            runCatching {
                val indexUrl = repositoryIndexUrl.trim()
                require(indexUrl.startsWith("https://", ignoreCase = true)) { "يجب استخدام HTTPS" }
                require(indexUrl.substringBefore('?').trimEnd('/').endsWith("/index.pb", true)) {
                    "يجب أن ينتهي رابط الفهرس بـ /index.pb"
                }
                val base = indexUrl.substringBefore('?').substringBeforeLast('/')
                val protobufBytes = getBytes(indexUrl)
                require(protobufBytes.isNotEmpty()) { "ملف index.pb فارغ" }

                val repoJson = runCatching { JsonParser.parseString(getText("$base/repo.json")).asJsonObject }.getOrNull()
                val repoMetadata = parseMetadata(repoJson)
                val rawProto = maybeGunzip(protobufBytes)
                val decoded = runCatching { KeiyoushiIndexProto.decode(rawProto) }.getOrNull()

                var entries = decoded?.entries.orEmpty()
                if (entries.isEmpty() && !decoded?.extensionListUrl.isNullOrBlank()) {
                    val listUrl = decoded!!.extensionListUrl!!.trim()
                    require(listUrl.startsWith("https://", ignoreCase = true)) { "رابط قائمة الإضافات البعيدة يجب أن يستخدم HTTPS" }
                    entries = parseExtensionListPayload(getBytes(listUrl))
                }

                var indexFormat = if (isGzip(protobufBytes)) "protobuf+gzip" else "protobuf"
                var warning: String? = null
                if (entries.isEmpty()) {
                    // index.min.json may contain only notices. The full index.json is the catalog fallback.
                    entries = parseEntries(JsonParser.parseString(getText("$base/index.json")))
                    indexFormat = "json-fallback"
                    warning = "تعذّر استخراج إضافات من index.pb؛ عُرضت القائمة من index.json الكامل. لم يُثبّت أو يُشغّل أي APK تلقائيًا."
                }
                require(entries.isNotEmpty()) { "لم يعثر الفهرس على إضافات" }

                val protoMetadata = decoded?.let {
                    ExtensionRepoMetadata(
                        name = it.name,
                        website = it.website,
                        signingKey = it.signingKey
                    )
                }
                val metadata = mergeMetadata(repoMetadata, protoMetadata)
                ExtensionCatalog(
                    repositoryUrl = indexUrl,
                    metadata = metadata,
                    entries = entries,
                    protobufBytes = protobufBytes.size,
                    indexFormat = indexFormat,
                    warning = warning
                )
            }
        }

    private fun parseExtensionListPayload(bytes: ByteArray): List<ExtensionEntry> {
        val payload = maybeGunzip(bytes)
        val first = payload.firstOrNull()?.toInt()?.toChar()
        if (first == '{' || first == '[') {
            return parseEntries(JsonParser.parseString(payload.toString(Charsets.UTF_8)))
        }
        val directList = runCatching { KeiyoushiIndexProto.decodeExtensionList(payload) }.getOrNull()
        if (directList?.any(::isUsableEntry) == true) return directList
        val nested = runCatching { KeiyoushiIndexProto.decode(payload) }.getOrNull() ?: return emptyList()
        if (nested.entries.isNotEmpty()) return nested.entries
        if (nested.extensionListUrl != null) {
            throw IOException("رابط فهرس الإضافات متداخل أكثر من مستوى واحد")
        }
        return emptyList()
    }

    private fun isUsableEntry(entry: ExtensionEntry) =
        entry.name.isNotBlank() && entry.pkg.isNotBlank() && entry.apk.startsWith("https://", true)

    private fun mergeMetadata(json: ExtensionRepoMetadata?, proto: ExtensionRepoMetadata?): ExtensionRepoMetadata? {
        if (json == null && proto == null) return null
        return ExtensionRepoMetadata(
            name = json?.name?.takeIf(String::isNotBlank) ?: proto?.name.orEmpty(),
            website = json?.website?.takeIf(String::isNotBlank) ?: proto?.website.orEmpty(),
            signingKeyFingerprint = json?.signingKeyFingerprint.orEmpty(),
            signingKey = proto?.signingKey?.takeIf(String::isNotBlank) ?: json?.signingKey.orEmpty()
        )
    }

    private fun parseMetadata(root: JsonObject?): ExtensionRepoMetadata? {
        if (root == null) return null
        val meta = root.getAsJsonObject("meta") ?: root
        val contact = meta.getAsJsonObject("contact")
        return ExtensionRepoMetadata(
            name = meta.stringOrNull("name").orEmpty(),
            website = meta.stringOrNull("website") ?: contact?.stringOrNull("website").orEmpty(),
            signingKeyFingerprint = meta.stringOrNull("signingKeyFingerprint").orEmpty(),
            signingKey = meta.stringOrNull("signingKey").orEmpty()
        )
    }

    private fun parseEntries(root: JsonElement): List<ExtensionEntry> {
        val raw = when {
            root.isJsonArray -> root.asJsonArray
            root.isJsonObject -> root.asJsonObject.getAsJsonObject("extensionList")
                ?.getAsJsonArray("extensions")
                ?: root.asJsonObject.getAsJsonArray("extensions")
                ?: return emptyList()
            else -> return emptyList()
        }
        return raw.mapNotNull { value ->
            runCatching {
                val item = value.asJsonObject
                val resources = item.getAsJsonObject("resources")
                val apk = item.stringOrNull("apk") ?: resources?.stringOrNull("apkUrl").orEmpty()
                val warning = item.get("contentWarning") ?: item.get("nsfw")
                val warningCode = warningCode(warning)
                val sources = item.getAsJsonArray("sources")?.mapNotNull { sourceValue ->
                    runCatching {
                        val source = sourceValue.asJsonObject
                        ExtensionSourceEntry(
                            name = source.stringOrNull("name").orEmpty(),
                            lang = source.stringOrNull("language") ?: source.stringOrNull("lang").orEmpty(),
                            id = source.longOrNull("id") ?: 0L,
                            baseUrl = source.stringOrNull("homeUrl") ?: source.stringOrNull("baseUrl").orEmpty()
                        )
                    }.getOrNull()
                }.orEmpty()
                ExtensionEntry(
                    name = item.stringOrNull("name").orEmpty(),
                    pkg = item.stringOrNull("packageName") ?: item.stringOrNull("pkg").orEmpty(),
                    apk = apk,
                    lang = sources.firstOrNull()?.lang
                        ?: item.stringOrNull("lang") ?: item.stringOrNull("language").orEmpty(),
                    code = item.longOrNull("versionCode") ?: item.longOrNull("code") ?: 0L,
                    version = item.stringOrNull("versionName") ?: item.stringOrNull("version").orEmpty(),
                    nsfw = warning,
                    sources = sources,
                    iconUrl = resources?.stringOrNull("iconUrl").orEmpty(),
                    jarUrl = resources?.stringOrNull("jarUrl").orEmpty(),
                    extensionLib = item.stringOrNull("extensionLib").orEmpty(),
                    contentWarning = warningCode
                )
            }.getOrNull()
        }
    }

    private fun warningCode(value: JsonElement?): Int? {
        if (value == null || value.isJsonNull) return null
        if (value.isJsonPrimitive && value.asJsonPrimitive.isNumber) return runCatching { value.asInt }.getOrNull()
        val text = runCatching { value.asString }.getOrNull()?.uppercase().orEmpty()
        return when {
            text.endsWith("_NSFW") -> 3
            text.endsWith("_MIXED") -> 2
            text.endsWith("_SAFE") -> 1
            text.endsWith("_UNSPECIFIED") -> 0
            else -> null
        }
    }

    private fun getBytes(url: String): ByteArray {
        val request = Request.Builder().url(url).header("Accept", "application/octet-stream, application/json").build()
        http.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "HTTP ${response.code} عند جلب $url" }
            val body = response.body ?: throw IOException("استجابة فارغة")
            if (body.contentLength() > MAX_DOWNLOAD_BYTES) throw IOException("حجم ملف الفهرس يتجاوز الحد الآمن")
            val output = ByteArrayOutputStream()
            body.byteStream().use { input ->
                val buffer = ByteArray(16 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (output.size() + count > MAX_DOWNLOAD_BYTES) throw IOException("حجم ملف الفهرس يتجاوز الحد الآمن")
                    output.write(buffer, 0, count)
                }
            }
            return output.toByteArray()
        }
    }

    private fun getText(url: String): String = getBytes(url).toString(Charsets.UTF_8)

    private fun maybeGunzip(bytes: ByteArray): ByteArray {
        if (!isGzip(bytes)) return bytes
        return GZIPInputStream(bytes.inputStream()).use { input ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (out.size() + count > MAX_DOWNLOAD_BYTES) throw IOException("فهرس مضغوط أكبر من الحد الآمن")
                out.write(buffer, 0, count)
            }
            out.toByteArray()
        }
    }

    private fun isGzip(bytes: ByteArray): Boolean =
        bytes.size >= 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()

    private fun JsonObject.stringOrNull(key: String): String? =
        get(key)?.takeUnless { it.isJsonNull || !it.isJsonPrimitive }?.asString

    private fun JsonObject.longOrNull(key: String): Long? =
        get(key)?.takeUnless { it.isJsonNull || !it.isJsonPrimitive }
            ?.let { runCatching { it.asString.toLong() }.getOrNull() }
}
