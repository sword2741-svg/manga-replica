package com.example.mangareplica.data.extensions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Download and preflight a repository APK; Android's package installer still requires user approval. */
class ExtensionApkInstaller(
    private val context: Context,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(90, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {
    data class VerifiedApk(
        val file: File,
        val packageName: String,
        val versionCode: Long,
        val signerSha256: String
    )

    suspend fun downloadAndVerify(entry: ExtensionEntry, expectedSignerFingerprint: String): VerifiedApk =
        withContext(Dispatchers.IO) {
            require(entry.pkg.isNotBlank()) { "بيانات الإضافة لا تحتوي اسم الحزمة" }
            require(entry.apk.startsWith("https://", ignoreCase = true)) { "رابط APK غير آمن؛ يجب أن يستخدم HTTPS" }
            val expected = expectedSignerFingerprint.filter(Char::isLetterOrDigit).lowercase()
            require(expected.matches(Regex("[0-9a-f]{64}"))) { "لا تتوفر بصمة توقيع SHA-256 موثوقة لهذا المستودع؛ أُوقف التثبيت" }

            val dir = File(context.cacheDir, "extensions").apply { mkdirs() }
            val safeName = entry.pkg.replace(Regex("[^A-Za-z0-9_.-]"), "_")
            val partial = File(dir, "$safeName.apk.part")
            val target = File(dir, "$safeName-${entry.code}.apk")
            try {
                val request = Request.Builder().url(entry.apk).header("Accept", "application/vnd.android.package-archive").build()
                http.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("HTTP ${response.code} عند تنزيل الإضافة")
                    val body = response.body ?: throw IOException("ملف APK فارغ")
                    if (body.contentLength() > MAX_APK_BYTES) throw IOException("حجم APK يتجاوز الحد الآمن")
                    body.byteStream().use { input ->
                        partial.outputStream().buffered().use { output ->
                            val buffer = ByteArray(64 * 1024)
                            var total = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                total += count
                                if (total > MAX_APK_BYTES) throw IOException("حجم APK يتجاوز الحد الآمن")
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                }
                val zipHeaderValid = partial.inputStream().use { input ->
                    val magic = ByteArray(4)
                    input.read(magic) == magic.size && magic.contentEquals(APK_ZIP_MAGIC)
                }
                if (partial.length() < 4 || !zipHeaderValid) {
                    throw IOException("الملف الذي نُزّل ليس أرشيف APK صالحًا")
                }
                if (!partial.renameTo(target)) throw IOException("تعذر حفظ ملف APK")
                val packageInfo = getArchivePackageInfo(target) ?: throw IOException("تعذر قراءة بيان APK")
                if (packageInfo.packageName != entry.pkg) {
                    throw SecurityException("اسم الحزمة داخل APK لا يطابق سجل المستودع")
                }
                val signer = signerFingerprint(packageInfo)
                if (!MessageDigest.isEqual(expected.toByteArray(), signer.toByteArray())) {
                    throw SecurityException("بصمة توقيع APK لا تطابق بصمة المستودع الموثوق؛ أُوقف التثبيت")
                }
                val versionCode = PackageInfoCompat.getLongVersionCode(packageInfo)
                if (entry.code > 0 && versionCode < entry.code) {
                    throw SecurityException("إصدار APK أقدم من الإصدار المعلن في الفهرس")
                }
                VerifiedApk(target, packageInfo.packageName, versionCode, signer)
            } catch (error: Throwable) {
                partial.delete()
                target.delete()
                throw error
            }
        }

    /** Opens Android settings if the user must permit installs from this app. */
    fun openInstallPermissionSettings(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()) return false
        val intent = Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
            .setData(Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    /** Launches the system UI; the user reviews and confirms or cancels the installation there. */
    fun launchSystemInstaller(apk: VerifiedApk) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk.file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, APK_MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private fun getArchivePackageInfo(file: File): PackageInfo? {
        val flags = PackageManager.GET_SIGNING_CERTIFICATES
        return if (Build.VERSION.SDK_INT >= 33) {
            context.packageManager.getPackageArchiveInfo(file.absolutePath, PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageArchiveInfo(file.absolutePath, flags)
        }
    }

    private fun signerFingerprint(info: PackageInfo): String {
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.signingInfo?.apkContentsSigners?.map { it.toByteArray() }.orEmpty()
        } else {
            @Suppress("DEPRECATION")
            info.signatures?.map { it.toByteArray() }.orEmpty()
        }
        if (signatures.isEmpty()) throw SecurityException("APK غير موقّع")
        // All current Keiyoushi extensions in a repository are expected to share its signer.
        return signatures.map { bytes -> MessageDigest.getInstance("SHA-256").digest(bytes).toHex() }.sorted().first()
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }

    private companion object {
        const val MAX_APK_BYTES = 200L * 1024 * 1024
        const val APK_MIME = "application/vnd.android.package-archive"
        val APK_ZIP_MAGIC = byteArrayOf(0x50, 0x4b, 0x03, 0x04)
    }
}
