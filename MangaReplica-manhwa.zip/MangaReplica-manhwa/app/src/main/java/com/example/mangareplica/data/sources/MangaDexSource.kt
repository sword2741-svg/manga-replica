package com.example.mangareplica.data.sources

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

/** MangaDex adapter using its documented public API; it never authenticates. */
class MangaDexSource(
    private val includeAdultContent: Boolean = false,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
) : MangaSource {
    override val id = "mangadex"
    override val name = "MangaDex"
    override val language = "multi"

    override suspend fun popular(page: Int): List<SourceManga> = withContext(Dispatchers.IO) {
        require(page >= 0)
        val url = api("/manga")
            .addQueryParameter("limit", PAGE_SIZE.toString())
            .addQueryParameter("offset", safeOffset(page).toString())
            .addQueryParameter("includes[]", "cover_art")
            .addQueryParameter("contentRating[]", "safe")
            .addQueryParameter("contentRating[]", "suggestive")
            .apply { if (includeAdultContent) addQueryParameter("contentRating[]", "erotica").addQueryParameter("contentRating[]", "pornographic") }
            .addQueryParameter("order[followedCount]", "desc")
            .build()
        parseMangaList(get(url))
    }

    override suspend fun latest(page: Int): List<SourceManga> = withContext(Dispatchers.IO) {
        require(page >= 0)
        val url = api("/manga")
            .addQueryParameter("limit", PAGE_SIZE.toString())
            .addQueryParameter("offset", safeOffset(page).toString())
            .addQueryParameter("includes[]", "cover_art")
            .addQueryParameter("contentRating[]", "safe")
            .addQueryParameter("contentRating[]", "suggestive")
            .apply { if (includeAdultContent) addQueryParameter("contentRating[]", "erotica").addQueryParameter("contentRating[]", "pornographic") }
            .addQueryParameter("order[updatedAt]", "desc")
            .build()
        parseMangaList(get(url))
    }

    override suspend fun search(query: String, page: Int): List<SourceManga> = withContext(Dispatchers.IO) {
        require(page >= 0)
        if (query.isBlank()) return@withContext emptyList()
        val url = api("/manga")
            .addQueryParameter("title", query.trim())
            .addQueryParameter("limit", PAGE_SIZE.toString())
            .addQueryParameter("offset", safeOffset(page).toString())
            .addQueryParameter("includes[]", "cover_art")
            .addQueryParameter("contentRating[]", "safe")
            .addQueryParameter("contentRating[]", "suggestive")
            .apply { if (includeAdultContent) addQueryParameter("contentRating[]", "erotica").addQueryParameter("contentRating[]", "pornographic") }
            .addQueryParameter("order[relevance]", "desc")
            .build()
        parseMangaList(get(url), query.trim())
    }

    override suspend fun details(manga: SourceManga): SourceManga = withContext(Dispatchers.IO) {
        val id = mangaId(manga)
        val response = get(api("/manga/$id").addQueryParameter("includes[]", "cover_art").build())
        parseManga(response.getAsJsonObject("data"), manga.title)
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> = withContext(Dispatchers.IO) {
        val mangaId = mangaId(manga)
        val results = mutableListOf<SourceChapter>()
        var offset = 0
        var total = Int.MAX_VALUE
        while (offset < total && results.size < MAX_CHAPTERS) {
            val url = api("/manga/$mangaId/feed")
                .addQueryParameter("limit", CHAPTER_PAGE_SIZE.toString())
                .addQueryParameter("offset", offset.toString())
                .addQueryParameter("translatedLanguage[]", "en")
                .addQueryParameter("translatedLanguage[]", "ar")
                .addQueryParameter("order[chapter]", "asc")
                .addQueryParameter("includes[]", "scanlation_group")
                .addQueryParameter("contentRating[]", "safe")
                .addQueryParameter("contentRating[]", "suggestive")
                .apply { if (includeAdultContent) addQueryParameter("contentRating[]", "erotica").addQueryParameter("contentRating[]", "pornographic") }
                .build()
            val response = get(url)
            total = response.intOrNull("total") ?: 0
            val rows = response.getAsJsonArray("data") ?: break
            if (rows.size() == 0) break
            rows.forEach { element ->
                if (!element.isJsonObject) return@forEach
                val item = element.asJsonObject
                val attributes = item.getAsJsonObject("attributes") ?: return@forEach
                val chapterId = item.stringOrNull("id") ?: return@forEach
                val number = attributes.stringOrNull("chapter")?.toFloatOrNull()
                val title = attributes.stringOrNull("title")
                val chapterLabel = buildString {
                    append("Chapter ")
                    append(number?.let(::formatNumber) ?: "—")
                    if (!title.isNullOrBlank()) append(" · $title")
                }
                results += SourceChapter(
                    sourceId = id,
                    url = chapterId,
                    name = chapterLabel,
                    number = number,
                    uploadDate = parseDate(attributes.stringOrNull("publishAt")),
                    language = attributes.stringOrNull("translatedLanguage"),
                    externalUrl = attributes.stringOrNull("externalUrl")
                )
            }
            offset += rows.size()
            if (rows.size() < CHAPTER_PAGE_SIZE) break
        }
        results.sortedWith(compareBy<SourceChapter> { it.number ?: Float.MAX_VALUE }.thenBy { it.uploadDate ?: Long.MAX_VALUE })
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> = withContext(Dispatchers.IO) {
        require(chapter.sourceId == id) { "Chapter belongs to another source" }
        val chapterId = chapter.url.trim().substringAfterLast('/').substringBefore('?')
        require(UUID_PATTERN.matches(chapterId)) { "Invalid MangaDex chapter id" }
        val response = get(api("/at-home/server/$chapterId").build())
        val base = response.stringOrNull("baseUrl") ?: throw IOException("MangaDex returned no image server")
        val chapterInfo = response.getAsJsonObject("chapter") ?: throw IOException("MangaDex returned no page data")
        val hash = chapterInfo.stringOrNull("hash") ?: throw IOException("MangaDex returned no page hash")
        val saver = chapterInfo.getAsJsonArray("dataSaver")?.takeIf { it.size() > 0 }
        val originals = chapterInfo.getAsJsonArray("data")?.takeIf { it.size() > 0 }
        val filenames = saver ?: originals ?: throw IOException("MangaDex returned no pages for this chapter")
        require(filenames.size() <= MAX_PAGES) { "Chapter exceeds the page safety limit" }
        val quality = if (saver != null) "data-saver" else "data"
        filenames.mapIndexed { index, file ->
            val filename = file.asString
            require(filename.isNotBlank() && !filename.contains('/') && !filename.contains("..")) { "Invalid page filename" }
            SourcePage(index, "$base/$quality/$hash/$filename")
        }
    }

    private fun parseMangaList(root: JsonObject, query: String? = null): List<SourceManga> =
        root.getAsJsonArray("data")?.mapNotNull { element ->
            if (!element.isJsonObject) null else runCatching { parseManga(element.asJsonObject, query) }.getOrNull()
        } ?: emptyList()

    private fun parseManga(item: JsonObject, query: String? = null): SourceManga {
        val attributes = item.getAsJsonObject("attributes") ?: JsonObject()
        val titles = attributes.getAsJsonObject("title")
        val titleValues = titles?.entrySet()?.mapNotNull { (key, value) ->
            if (value.isJsonPrimitive) key to value.asString else null
        }.orEmpty()
        val alternativeTitles = attributes.getAsJsonArray("altTitles").orEmpty().flatMap { element ->
            if (!element.isJsonObject) emptyList() else element.asJsonObject.entrySet().mapNotNull { (key, value) ->
                if (value.isJsonPrimitive) key to value.asString else null
            }
        }
        val title = titleValues.firstOrNull { it.first == "en" }?.second
            ?: alternativeTitles.firstOrNull { it.first == "en" && query != null && it.second.contains(query, true) }?.second
            ?: alternativeTitles.firstOrNull { it.first == "en" }?.second
            ?: titleValues.firstOrNull()?.second
            ?: alternativeTitles.firstOrNull()?.second
            ?: "Untitled"
        val descriptions = attributes.getAsJsonObject("description")
        val description = descriptions?.stringOrNull("en")
            ?: descriptions?.entrySet()?.firstOrNull { it.value.isJsonPrimitive }?.value?.asString
        val mangaId = item.stringOrNull("id") ?: throw IOException("MangaDex returned a manga without an id")
        val coverFile = item.getAsJsonArray("relationships")?.mapNotNull { relationElement ->
            if (!relationElement.isJsonObject) return@mapNotNull null
            val relation = relationElement.asJsonObject
            if (relation.stringOrNull("type") == "cover_art") {
                relation.getAsJsonObject("attributes")?.stringOrNull("fileName")
            } else null
        }?.firstOrNull()
        val cover = coverFile?.let { "https://uploads.mangadex.org/covers/$mangaId/$it.256.jpg" }
        val genres = attributes.getAsJsonArray("tags")?.mapNotNull { tagElement ->
            runCatching { tagElement.asJsonObject.getAsJsonObject("attributes")?.getAsJsonObject("name")?.stringOrNull("en") }.getOrNull()
        }?.distinct().orEmpty()
        val author = item.getAsJsonArray("relationships")?.mapNotNull { relationElement ->
            runCatching {
                val relation = relationElement.asJsonObject
                if (relation.stringOrNull("type") == "author" || relation.stringOrNull("type") == "artist") {
                    relation.getAsJsonObject("attributes")?.stringOrNull("name")
                } else null
            }.getOrNull()
        }?.firstOrNull()
        return SourceManga(
            sourceId = id,
            url = mangaId,
            title = title,
            coverUrl = cover,
            description = description,
            status = attributes.stringOrNull("status"),
            genres = genres,
            author = author,
            year = attributes.intOrNull("year"),
            originalLanguage = attributes.stringOrNull("originalLanguage")
        )
    }

    private fun get(url: HttpUrl): JsonObject {
        var lastError: IOException? = null
        repeat(MAX_ATTEMPTS) { attempt ->
            val request = Request.Builder().url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "application/json")
                .build()
            try {
                http.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val text = response.body?.string() ?: throw IOException("MangaDex returned an empty response")
                        val json = JsonParser.parseString(text)
                        if (!json.isJsonObject) throw IOException("Unexpected MangaDex response")
                        return json.asJsonObject
                    }
                    val error = IOException("MangaDex HTTP ${response.code}")
                    if ((response.code == 429 || response.code >= 500) && attempt < MAX_ATTEMPTS - 1) {
                        lastError = error
                        val retryAfter = response.header("Retry-After")?.toLongOrNull()?.coerceIn(1, 8)
                        Thread.sleep((retryAfter ?: (attempt + 1L)).coerceAtMost(8) * 1000L)
                    } else throw error
                }
            } catch (error: IOException) {
                if (attempt == MAX_ATTEMPTS - 1) throw error
                lastError = error
                Thread.sleep((attempt + 1L) * 400L)
            }
        }
        throw lastError ?: IOException("MangaDex request failed")
    }

    private fun api(path: String) = "$API_BASE$path".toHttpUrl().newBuilder()
    private fun safeOffset(page: Int) = page.coerceAtMost(MAX_PAGE) * PAGE_SIZE

    private fun mangaId(manga: SourceManga): String {
        require(manga.sourceId == id) { "Manga belongs to another source" }
        val value = manga.url.trim().substringAfterLast('/').substringBefore('?')
        require(UUID_PATTERN.matches(value)) { "Invalid MangaDex manga id" }
        return value
    }

    private fun JsonObject.stringOrNull(key: String): String? =
        get(key)?.takeUnless { it.isJsonNull || !it.isJsonPrimitive }?.asString

    private fun JsonObject.intOrNull(key: String): Int? =
        get(key)?.takeUnless { it.isJsonNull || !it.isJsonPrimitive }?.let { runCatching { it.asInt }.getOrNull() }

    private fun JsonArray?.orEmpty(): List<com.google.gson.JsonElement> = this?.map { it }.orEmpty()

    private fun parseDate(value: String?): Long? = value?.let {
        runCatching {
            java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.ROOT).parse(it)?.time
                ?: java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.ROOT).parse(it)?.time
        }.getOrNull()
    }

    private fun formatNumber(number: Float) = if (number % 1f == 0f) number.toInt().toString() else number.toString()

    private companion object {
        const val API_BASE = "https://api.mangadex.org"
        const val PAGE_SIZE = 20
        const val CHAPTER_PAGE_SIZE = 500
        const val MAX_CHAPTERS = 5_000
        const val MAX_PAGE = 10_000
        const val MAX_PAGES = 2_000
        const val MAX_ATTEMPTS = 3
        const val USER_AGENT = "MangaReplica/0.8 (Android; public API client)"
        val UUID_PATTERN = Regex("(?i)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
    }
}
