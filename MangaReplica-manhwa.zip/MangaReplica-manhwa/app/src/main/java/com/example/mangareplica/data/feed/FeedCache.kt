package com.example.mangareplica.data.feed

import android.content.Context
import com.example.mangareplica.data.sources.MangaGroup
import com.example.mangareplica.data.sources.NativeSourceRegistry
import com.example.mangareplica.data.sources.FederatedSourceRepository
import com.example.mangareplica.data.sources.SourceChapter
import com.example.mangareplica.data.sources.SourceManga
import com.example.mangareplica.data.sources.SourceMangaRef
import com.google.gson.Gson
import java.io.File
import java.security.MessageDigest

/** Tiny JSON file cache so Home, Latest and work pages can show their last results offline. */
class FeedCache(private val dir: File) {
    constructor(context: Context) : this(File(context.applicationContext.filesDir, "feed-cache"))

    private val gson = Gson()

    fun write(key: String, value: Any) {
        runCatching {
            dir.mkdirs()
            File(dir, fileName(key)).writeText(gson.toJson(value))
        }
    }

    fun <T> read(key: String, type: Class<T>): T? = runCatching {
        val file = File(dir, fileName(key))
        if (!file.exists()) null else gson.fromJson(file.readText(), type)
    }.getOrNull()

    private fun fileName(key: String): String =
        MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }.take(32) + ".json"
}

data class CachedWork(
    val sourceId: String = "",
    val url: String = "",
    val title: String = "",
    val coverUrl: String? = null,
    val description: String? = null,
    val status: String? = null,
    val chapterName: String? = null,
    val chapterUrl: String? = null,
    val chapterNumber: Float? = null,
    val publishedAt: Long? = null,
    val type: String? = null,
)

data class CachedFeed(val savedAt: Long = 0L, val works: List<CachedWork> = emptyList())

data class CachedHome(val savedAt: Long = 0L, val popular: List<CachedWork> = emptyList(), val latest: List<CachedWork> = emptyList())

data class CachedDetail(val manga: SourceManga? = null, val chapters: List<SourceChapter> = emptyList(), val savedAt: Long = 0L)

fun MangaGroup.toCachedWorks(): List<CachedWork> = sources.map { ref ->
    CachedWork(
        sourceId = ref.source.id, url = ref.manga.url, title = ref.manga.title, coverUrl = ref.manga.coverUrl,
        description = ref.manga.description, status = ref.manga.status,
    )
}

/** Rebuilds groups from cached works; works whose source is no longer installed are skipped. */
fun List<CachedWork>.toGroups(registry: NativeSourceRegistry): List<MangaGroup> {
    val byTitle = LinkedHashMap<String, MutableList<SourceMangaRef>>()
    forEach { work ->
        val source = registry.find(work.sourceId) ?: return@forEach
        val key = FederatedSourceRepository.normalizeTitle(work.title)
        if (key.isBlank()) return@forEach
        val manga = SourceManga(
            sourceId = work.sourceId, url = work.url, title = work.title, coverUrl = work.coverUrl,
            description = work.description, status = work.status,
        )
        byTitle.getOrPut(key) { mutableListOf() }.add(SourceMangaRef(source, manga))
    }
    return byTitle.map { (key, refs) -> MangaGroup(key, refs.first().manga.title, refs) }
}

object HomeCache {
    private const val KEY = "home-v1"

    fun save(cache: FeedCache, popular: List<MangaGroup>, latest: List<MangaGroup>) {
        if (popular.isEmpty() && latest.isEmpty()) return
        cache.write(
            KEY,
            CachedHome(
                System.currentTimeMillis(),
                popular.flatMap { it.toCachedWorks() },
                latest.flatMap { it.toCachedWorks() },
            ),
        )
    }

    fun load(cache: FeedCache, registry: NativeSourceRegistry): Pair<List<MangaGroup>, List<MangaGroup>>? {
        val saved = cache.read(KEY, CachedHome::class.java) ?: return null
        val popular = saved.popular.toGroups(registry)
        val latest = saved.latest.toGroups(registry)
        return if (popular.isEmpty() && latest.isEmpty()) null else popular to latest
    }
}
