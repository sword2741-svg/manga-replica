package com.example.mangareplica.data.extensions

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.charset.StandardCharsets

/**
 * Minimal, bounded decoder for Keiyoushi's published index.proto (proto3).
 * Unknown fields are skipped so compatible schema additions do not break catalog refresh.
 */
internal object KeiyoushiIndexProto {
    data class Index(
        val name: String = "",
        val badgeLabel: String = "",
        val signingKey: String = "",
        val website: String = "",
        val discord: String = "",
        val extensionListUrl: String? = null,
        val entries: List<ExtensionEntry> = emptyList()
    )

    fun decode(bytes: ByteArray): Index {
        if (bytes.isEmpty() || bytes.size > MAX_INDEX_BYTES) throw IOException("حجم index.pb غير صالح")
        val reader = Reader(bytes)
        var name = ""
        var badge = ""
        var key = ""
        var website = ""
        var discord = ""
        var listUrl: String? = null
        val entries = mutableListOf<ExtensionEntry>()
        while (reader.hasRemaining()) {
            val tag = reader.readVarint().toInt()
            if (tag == 0) throw IOException("وسم Protobuf غير صالح")
            val field = tag ushr 3
            when {
                field == 1 && tag and 7 == WIRE_LENGTH -> name = reader.readString()
                field == 2 && tag and 7 == WIRE_LENGTH -> badge = reader.readString()
                field == 3 && tag and 7 == WIRE_LENGTH -> key = reader.readString()
                field == 4 && tag and 7 == WIRE_LENGTH -> {
                    val contact = readContact(reader.readBytes())
                    website = contact.first
                    discord = contact.second
                }
                field == 101 && tag and 7 == WIRE_LENGTH -> {
                    listUrl = null
                    entries += readExtensionList(reader.readBytes())
                    if (entries.size > MAX_EXTENSIONS) throw IOException("فهرس يتجاوز الحد الآمن للإضافات")
                }
                field == 102 && tag and 7 == WIRE_LENGTH -> {
                    listUrl = reader.readString()
                    entries.clear()
                }
                else -> reader.skip(tag and 7)
            }
        }
        return Index(name, badge, key, website, discord, listUrl, entries)
    }

    fun decodeExtensionList(bytes: ByteArray): List<ExtensionEntry> {
        if (bytes.isEmpty() || bytes.size > MAX_INDEX_BYTES) throw IOException("حجم قائمة Protobuf غير صالح")
        return readExtensionList(bytes).also {
            if (it.size > MAX_EXTENSIONS) throw IOException("فهرس يتجاوز الحد الآمن للإضافات")
        }
    }

    private fun readContact(bytes: ByteArray): Pair<String, String> {
        val r = Reader(bytes); var website = ""; var discord = ""
        while (r.hasRemaining()) {
            val tag = r.readVarint().toInt()
            when ((tag ushr 3) to (tag and 7)) {
                1 to WIRE_LENGTH -> website = r.readString()
                2 to WIRE_LENGTH -> discord = r.readString()
                else -> r.skip(tag and 7)
            }
        }
        return website to discord
    }

    private fun readExtensionList(bytes: ByteArray): List<ExtensionEntry> {
        val r = Reader(bytes); val result = mutableListOf<ExtensionEntry>()
        while (r.hasRemaining()) {
            val tag = r.readVarint().toInt()
            if ((tag ushr 3) == 1 && (tag and 7) == WIRE_LENGTH) {
                result += readExtension(r.readBytes())
                if (result.size > MAX_EXTENSIONS) throw IOException("فهرس يتجاوز الحد الآمن للإضافات")
            } else r.skip(tag and 7)
        }
        return result
    }

    private fun readExtension(bytes: ByteArray): ExtensionEntry {
        val r = Reader(bytes)
        var name = ""; var pkg = ""; var apk = ""; var icon = ""; var jar = ""
        var lib = ""; var versionCode = 0L; var versionName = ""; var warning = 0
        val sources = mutableListOf<ExtensionSourceEntry>()
        while (r.hasRemaining()) {
            val tag = r.readVarint().toInt(); val field = tag ushr 3; val wire = tag and 7
            when {
                field == 1 && wire == WIRE_LENGTH -> name = r.readString()
                field == 2 && wire == WIRE_LENGTH -> pkg = r.readString()
                field == 3 && wire == WIRE_LENGTH -> {
                    val resources = readResources(r.readBytes())
                    apk = resources.first; icon = resources.second; jar = resources.third
                }
                field == 4 && wire == WIRE_LENGTH -> lib = r.readString()
                field == 5 && wire == WIRE_VARINT -> versionCode = r.readVarint()
                field == 6 && wire == WIRE_LENGTH -> versionName = r.readString()
                field == 7 && wire == WIRE_VARINT -> warning = r.readVarint().toInt()
                field == 8 && wire == WIRE_LENGTH -> {
                    sources += readSource(r.readBytes())
                    if (sources.size > MAX_SOURCES_PER_EXTENSION) throw IOException("إضافة تحتوي عدد مصادر غير آمن")
                }
                else -> r.skip(wire)
            }
        }
        return ExtensionEntry(
            name = name,
            pkg = pkg,
            apk = apk,
            lang = sources.firstOrNull()?.lang.orEmpty(),
            code = versionCode,
            version = versionName,
            nsfw = com.google.gson.JsonParser.parseString(warning.toString()),
            sources = sources,
            iconUrl = icon,
            jarUrl = jar,
            extensionLib = lib,
            contentWarning = warning
        )
    }

    private fun readResources(bytes: ByteArray): Triple<String, String, String> {
        val r = Reader(bytes); var apk = ""; var icon = ""; var jar = ""
        while (r.hasRemaining()) {
            val tag = r.readVarint().toInt(); val field = tag ushr 3; val wire = tag and 7
            when {
                field == 1 && wire == WIRE_LENGTH -> apk = r.readString()
                field == 2 && wire == WIRE_LENGTH -> icon = r.readString()
                field == 501 && wire == WIRE_LENGTH -> jar = r.readString()
                else -> r.skip(wire)
            }
        }
        return Triple(apk, icon, jar)
    }

    private fun readSource(bytes: ByteArray): ExtensionSourceEntry {
        val r = Reader(bytes); var id = 0L; var name = ""; var language = ""; var home = ""
        while (r.hasRemaining()) {
            val tag = r.readVarint().toInt(); val field = tag ushr 3; val wire = tag and 7
            when {
                field == 1 && wire == WIRE_VARINT -> id = r.readVarint()
                field == 2 && wire == WIRE_LENGTH -> name = r.readString()
                field == 3 && wire == WIRE_LENGTH -> language = r.readString()
                field == 4 && wire == WIRE_LENGTH -> home = r.readString()
                else -> r.skip(wire)
            }
        }
        return ExtensionSourceEntry(name = name, lang = language, id = id, baseUrl = home)
    }

    private class Reader(private val bytes: ByteArray) {
        private var position = 0
        fun hasRemaining() = position < bytes.size

        fun readVarint(): Long {
            var result = 0L
            var shift = 0
            while (shift < 64) {
                if (position >= bytes.size) throw IOException("انتهى index.pb داخل قيمة Protobuf")
                val value = bytes[position++].toInt() and 0xff
                result = result or ((value and 0x7f).toLong() shl shift)
                if (value and 0x80 == 0) return result
                shift += 7
            }
            throw IOException("قيمة Protobuf varint أطول من الحد")
        }

        fun readBytes(): ByteArray {
            val length = readVarint()
            if (length < 0 || length > MAX_MESSAGE_BYTES || length > bytes.size - position) {
                throw IOException("طول حقل Protobuf خارج الحدود")
            }
            val end = position + length.toInt()
            val value = bytes.copyOfRange(position, end)
            position = end
            return value
        }

        fun readString(): String = String(readBytes(), StandardCharsets.UTF_8)

        fun skip(wire: Int) {
            when (wire) {
                WIRE_VARINT -> readVarint()
                WIRE_64BIT -> advance(8)
                WIRE_LENGTH -> {
                    val length = readVarint()
                    if (length < 0 || length > bytes.size - position) throw IOException("حقل Protobuf تالف")
                    advance(length.toInt())
                }
                WIRE_32BIT -> advance(4)
                else -> throw IOException("نوع wire غير مدعوم في Protobuf: $wire")
            }
        }

        private fun advance(count: Int) {
            if (count < 0 || count > bytes.size - position) throw IOException("حقل Protobuf خارج حدود الملف")
            position += count
        }
    }

    private const val WIRE_VARINT = 0
    private const val WIRE_64BIT = 1
    private const val WIRE_LENGTH = 2
    private const val WIRE_32BIT = 5
    private const val MAX_INDEX_BYTES = 100 * 1024 * 1024
    private const val MAX_MESSAGE_BYTES = 64 * 1024 * 1024
    private const val MAX_EXTENSIONS = 20_000
    private const val MAX_SOURCES_PER_EXTENSION = 500
}
