package com.example.mangareplica.data.persistence

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

/**
 * Active reading time for one local calendar day. [day] is the number of days since 1970-01-01
 * in the device time zone (see ProfileStatsCalculator.dayOf).
 */
@Entity(tableName = "reading_day_stats")
data class ReadingDayStatEntity(
    @PrimaryKey val day: Long,
    val seconds: Int,
)

@Dao
interface ReadingStatsDao {
    @Query("SELECT * FROM reading_day_stats ORDER BY day DESC")
    fun observeAll(): Flow<List<ReadingDayStatEntity>>

    @Query("SELECT * FROM reading_day_stats")
    suspend fun getAll(): List<ReadingDayStatEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(entry: ReadingDayStatEntity)

    @Query("UPDATE reading_day_stats SET seconds = seconds + :seconds WHERE day = :day")
    suspend fun addSeconds(day: Long, seconds: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<ReadingDayStatEntity>)

    @Transaction
    suspend fun add(day: Long, seconds: Int) {
        insertIfAbsent(ReadingDayStatEntity(day, 0))
        addSeconds(day, seconds)
    }
}

/** v1 -> v2: reading statistics, library genres and per-chapter page counts. Keeps all user data. */
val MIGRATION_1_2: Migration = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `reading_day_stats` (`day` INTEGER NOT NULL, `seconds` INTEGER NOT NULL, PRIMARY KEY(`day`))")
        db.execSQL("ALTER TABLE `library_manga` ADD COLUMN `genres` TEXT")
        db.execSQL("ALTER TABLE `reading_progress` ADD COLUMN `pageCount` INTEGER NOT NULL DEFAULT 0")
    }
}

/** v2 -> v3: retain work/chapter labels when a downloaded work is removed from the library. */
val MIGRATION_2_3: Migration = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `chapter_downloads` ADD COLUMN `mangaTitle` TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE `chapter_downloads` ADD COLUMN `mangaCoverUrl` TEXT")
        db.execSQL("ALTER TABLE `chapter_downloads` ADD COLUMN `chapterName` TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE `chapter_downloads` ADD COLUMN `chapterNumber` REAL")
    }
}
