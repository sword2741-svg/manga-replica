@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.mangareplica

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.platform.LocalContext
import java.io.File
import androidx.compose.ui.unit.*
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.mangareplica.data.extensions.*
import com.example.mangareplica.data.persistence.*
import com.example.mangareplica.data.preferences.*
import com.example.mangareplica.data.sources.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

private val Coral: Color
    @Composable get() = MaterialTheme.colorScheme.primary
private val Panel = Color(0xFF151821)
private val Muted = Color(0xFFA8A29A)
private val LocalShowBadges = compositionLocalOf { false }
private val LocalAccent = compositionLocalOf { Color(0xFFFF6B4A) }

@Composable private fun ScreenColumn(scrollToken: Int? = null, content: @Composable ColumnScope.() -> Unit) {
    val verticalState = rememberScrollState()
    LaunchedEffect(scrollToken) { if (scrollToken != null) verticalState.scrollTo(0) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(bottom = 84.dp).verticalScroll(verticalState).padding(horizontal = 16.dp), content = content)
}
@Composable private fun Header(title: String, action: (() -> Unit)? = null, label: String = "رجوع") {
    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (action != null) TextButton(onClick = action) { Text(label, color = Coral) }
    }
}
@Composable private fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(24.dp), color = if (selected) Coral else Panel, border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
        Text(text, Modifier.padding(horizontal = 15.dp, vertical = 9.dp), color = if (selected) Color(0xFF1A0A06) else MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelLarge, maxLines = 1, softWrap = false)
    }
}
@Composable private fun EmptyState(title: String, detail: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.AutoStories, null, tint = Coral, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(5.dp))
        Text(detail, color = Muted, style = MaterialTheme.typography.bodyMedium)
        if (action != null && onAction != null) { Spacer(Modifier.height(16.dp)); Button(onClick = onAction, colors = ButtonDefaults.buttonColors(containerColor = Coral)) { Text(action) } }
    }
}
@Composable private fun StateMessage(loading: Boolean, error: String?, empty: Boolean, onRetry: (() -> Unit)? = null) {
    when { loading -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Coral) }
        error != null -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("تعذر إكمال الطلب", color = Coral); Text(error, color = Muted); if (onRetry != null) TextButton(onClick = onRetry) { Text("إعادة المحاولة") } }
        empty -> EmptyState("لا توجد نتائج بعد", "تحقق من الاتصال ثم حاول تحديث النتائج مرة أخرى.", "استكشاف", onRetry)
    }
}
@Composable private fun MangaTile(group: MangaGroup, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLong)) {
        Box(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)).background(Panel)) {
            if (!group.preferred.manga.coverUrl.isNullOrBlank()) AsyncImage(group.preferred.manga.coverUrl, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (LocalShowBadges.current) Text(group.preferred.source.name, Modifier.align(Alignment.TopEnd).padding(6.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xCC11131A)).padding(horizontal=6.dp, vertical=3.dp), color=Color.White, style=MaterialTheme.typography.labelSmall, maxLines=1)
        }
        Text(group.title, Modifier.padding(top=5.dp), maxLines=1, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.bodyMedium)
    }
}
@Composable private fun MangaGrid(groups: List<MangaGroup>, onOpen: (MangaGroup)->Unit) {
    if (groups.isEmpty()) EmptyState("لا توجد أعمال لعرضها", "تظهر الأعمال عند توفر نتائج من مواقع القراءة.")
    else LazyVerticalGrid(columns=GridCells.Fixed(3), modifier=Modifier.fillMaxWidth().heightIn(max=2600.dp), contentPadding=PaddingValues(bottom=12.dp), horizontalArrangement=Arrangement.spacedBy(12.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) { items(groups, key={it.normalizedTitle}) { MangaTile(it,{onOpen(it)}) } }
}
@Composable private fun SectionTitle(title:String, action:(()->Unit)?=null, actionLabel:String="عرض الكل") { Row(Modifier.fillMaxWidth().padding(vertical=10.dp), horizontalArrangement=Arrangement.SpaceBetween) { Text(title, style=MaterialTheme.typography.titleLarge); if(action!=null) TextButton(onClick=action) { Text(actionLabel, color=Coral) } } }

@Composable fun HomeScreen(popular:List<MangaGroup>,latest:List<MangaGroup>,continueItems:List<LibraryMangaEntity>,sources:List<MangaSource>,sourceFilter:String,settings:AppSettings,loading:Boolean,error:String?,scrollToken:Int,onSearch:()->Unit,onDownloads:()->Unit,onSourceFilter:(String)->Unit,onRefresh:()->Unit,onOpenGroup:(MangaGroup)->Unit,onOpenContinue:(LibraryMangaEntity)->Unit,onAddToLibrary:(MangaGroup)->Unit,onExploreGenre:(String)->Unit,onShowAll:()->Unit,onOpenExtensions:()->Unit,onOpenProfile:()->Unit,onOpenLatest:()->Unit,offline:Boolean) {
    CompositionLocalProvider(LocalShowBadges provides false) { ScreenColumn(scrollToken) {
        Row(Modifier.fillMaxWidth().padding(top=15.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) { Row(verticalAlignment=Alignment.CenterVertically) { AppAvatarButton(settings.profileAvatarPath,onOpenProfile); Spacer(Modifier.width(10.dp)); Text("مانهوا",color=Coral,style=MaterialTheme.typography.headlineMedium) }; Row { IconButton(onClick=onDownloads){Icon(Icons.Default.Download,null)}; IconButton(onClick=onSearch){Icon(Icons.Default.Search,null)} } }
        if(offline) AppOfflineBanner()
        Spacer(Modifier.height(14.dp)); if(settings.showBanners) Card(shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Panel), modifier=Modifier.fillMaxWidth().height(210.dp)) { Box(Modifier.fillMaxSize().clickable { popular.firstOrNull()?.let(onOpenGroup) }) { popular.firstOrNull()?.preferred?.manga?.coverUrl?.let { AsyncImage(it,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop,alpha=.35f) }; Column(Modifier.align(Alignment.BottomEnd).padding(18.dp), horizontalAlignment=Alignment.End) { Text(popular.firstOrNull()?.title ?: "اكتشف عالم المانهوا", style=MaterialTheme.typography.headlineSmall, maxLines=2); Text("قصص جديدة من مواقع القراءة", color=Muted); Row { Button(onClick=onShowAll,colors=ButtonDefaults.buttonColors(containerColor=Coral)){Text("استكشف الآن")} } } } }
        SectionTitle("متابعة القراءة")
        if (!settings.showContinueReading || continueItems.isEmpty()) EmptyState("لا توجد قراءة للمتابعة", "ابدأ قراءة عمل وسيظهر تقدمك هنا.", "استكشف الأعمال", onShowAll) else Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(12.dp)) { continueItems.forEach { item -> Column(Modifier.width(112.dp).clickable { onOpenContinue(item) }) { Box(Modifier.fillMaxWidth().height(135.dp).clip(RoundedCornerShape(12.dp)).background(Panel)) { item.coverUrl?.let { AsyncImage(it,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop) } }; Text(item.title,maxLines=1,overflow=TextOverflow.Ellipsis) } } }
        if(settings.showTrending) SectionTitle("الأكثر رواجًا", onShowAll)
        if (settings.showTrending && loading && popular.isEmpty()) StateMessage(true,null,false) else if(settings.showTrending && error!=null && popular.isEmpty()) StateMessage(false,error,false,onRefresh) else if(settings.showTrending) Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(12.dp)){popular.take(12).forEach{MangaTile(it,{onOpenGroup(it)})};if(popular.isEmpty()) StateMessage(false,null,true,onRefresh)}
        if(settings.showNew) SectionTitle("آخر التحديثات", onOpenLatest, "أحدث الأعمال")
        if (settings.showNew && latest.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(12.dp)){latest.take(12).forEach{MangaTile(it,{onOpenGroup(it)})}} else if(settings.showNew) StateMessage(loading,error,true,onRefresh)
    }
} }
@Composable private fun FilterSheet(options:List<Pair<String,String>>,selected:String,onSelect:(String)->Unit,onDismiss:()->Unit) { ModalBottomSheet(onDismissRequest=onDismiss) { Column(Modifier.fillMaxWidth().padding(20.dp)) { Text("تصفية حسب المصدر",style=MaterialTheme.typography.titleLarge); options.forEach { (n,id)-> Row(Modifier.fillMaxWidth().clickable{onSelect(id)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(id==selected,{onSelect(id)}); Text(n)} } } } }

@Composable fun SearchScreen(query:String,onQueryChange:(String)->Unit,result:FederatedPage,sources:List<MangaSource>,sourceId:String,onSourceChange:(String)->Unit,history:List<SearchHistoryEntity>,loading:Boolean,error:String?,onOpen:(MangaGroup)->Unit,onHistorySelect:(String)->Unit,onDeleteHistory:(SearchHistoryEntity)->Unit,onClearHistory:()->Unit,onMore:()->Unit,onBack:()->Unit,onOpenExtensions:()->Unit) {
    ScreenColumn { Header("البحث",onBack); Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(12.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Search,null,tint=Coral); Spacer(Modifier.width(8.dp)); BasicTextField(query,onQueryChange,Modifier.weight(1f),singleLine=true,textStyle=MaterialTheme.typography.bodyLarge.copy(color=MaterialTheme.colorScheme.onSurface),keyboardOptions=KeyboardOptions(imeAction=ImeAction.Search),decorationBox={inner->Box { if(query.isEmpty()) Text("ابحث عن عنوان أو مؤلف",color=Muted); inner() }}); if(query.isNotEmpty()) IconButton(onClick={onQueryChange("")}){Icon(Icons.Default.Close,null)} }
        if(query.isBlank()){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("عمليات البحث الأخيرة",style=MaterialTheme.typography.titleLarge);if(history.isNotEmpty())TextButton(onClick=onClearHistory){Text("مسح",color=Coral)}};if(history.isEmpty())EmptyState("لا يوجد سجل بحث", "ستظهر عمليات البحث هنا بعد استخدامها.") else history.forEach { h -> ListItem(headlineContent={Text(h.query)}, modifier=Modifier.clickable{onHistorySelect(h.query)}, trailingContent={IconButton(onClick={onDeleteHistory(h)}){Icon(Icons.Default.Close,null)}}) } }
        else {
            if (result.groups.isNotEmpty()) MangaGrid(result.groups, onOpen)
            StateMessage(loading, error, result.groups.isEmpty() && !loading && error == null, onMore)
            if (result.groups.isNotEmpty()) OutlinedButton(onClick=onMore, Modifier.fillMaxWidth(), enabled = !loading) {
                Text(if (loading) "جارٍ التحميل…" else "تحميل المزيد")
            }
        }
    }
}
@Composable fun ExploreScreen(result:FederatedPage,loading:Boolean,sort:String,onSort:(String)->Unit,genre:String,onGenre:(String)->Unit,onOpen:(MangaGroup)->Unit,onMore:()->Unit,scrollToken:Int,onOpenExtensions:()->Unit) {
    ScreenColumn(scrollToken) {
        Header("استكشاف")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Pill("الأكثر رواجًا",sort=="popular"){onSort("popular")}
            Pill("الأحدث",sort=="latest"){onSort("latest")}
        }
        Row(Modifier.fillMaxWidth().padding(top=8.dp).horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("الكل","Action","Romance","Drama","Fantasy","Comedy").forEach { g ->
                Pill(if(g=="الكل")"كل التصنيفات" else g,genre==g||genre.isBlank()&&g=="الكل") { onGenre(if(g=="الكل")"" else g) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top=8.dp).horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("الكل","جارية","مكتملة","متوقفة").forEach { status ->
                Pill(status,genre=="status:$status"||status=="الكل"&&genre.isBlank()){onGenre(if(status=="الكل")"" else "status:$status")}
            }
        }
        if(genre.startsWith("status:")) Text("حالة العمل: ${genre.substringAfter(":")}",color=Coral)
        if (result.groups.isEmpty()) {
            val failure = result.failures.firstOrNull()
            StateMessage(
                loading,
                failure?.let { "تعذّر الاتصال ببعض مواقع القراءة. تحقق من الاتصال ثم أعد المحاولة." },
                empty = !loading && failure == null,
                onRetry = onMore,
            )
        } else {
            MangaGrid(result.groups, onOpen)
            OutlinedButton(onClick = onMore, Modifier.fillMaxWidth(), enabled = !loading) {
                Text(if (loading) "جارٍ التحميل…" else "تحميل المزيد")
            }
        }
    }
}
@Composable fun LibraryScreen(items:List<LibraryMangaEntity>,progress:List<ReadingProgressEntity>,downloads:List<ChapterDownloadEntity>,categories:List<MangaCategoryEntity>,onOpen:(LibraryMangaEntity)->Unit,onRemove:(LibraryMangaEntity)->Unit,onToggleFavorite:(LibraryMangaEntity)->Unit,onMarkRead:(LibraryMangaEntity)->Unit,onOpenDownloads:()->Unit,scrollToken:Int) {
    var tab by remember { mutableStateOf("قيد القراءة") }; var search by remember{mutableStateOf("")}; var filter by remember{mutableStateOf("الكل")}; var menu by remember{mutableStateOf<LibraryMangaEntity?>(null)}
    val filtered=items.filter{(filter=="الكل" || it.categoryId==filter || (filter=="المفضلة"&&it.isFavorite) || (filter=="مكتملة"&&it.isCompleted) || (filter=="قيد القراءة"&&!it.isRead)) && it.title.contains(search,true)}
    ScreenColumn(scrollToken) { Header("المكتبة",onOpenDownloads,"التنزيلات"); Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("قيد القراءة","المفضلة","مكتملة","التنزيلات").forEach{Pill(it,tab==it){tab=it}}}
        if(tab=="التنزيلات"){if(downloads.isEmpty()) EmptyState("لا توجد تنزيلات","ستظهر التنزيلات التي بدأتها هنا.") else downloads.forEach{ListItem(headlineContent={Text(it.chapterUrl.substringAfterLast('/'))}, supportingContent={Text("${it.status} · ${it.progressPercent}%")})}}
        else { OutlinedTextField(search,{search=it},Modifier.fillMaxWidth().padding(top=10.dp),placeholder={Text("ابحث في المكتبة")},singleLine=true); Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){Pill("الكل",filter=="الكل"){filter="الكل"};Pill("قيد القراءة",filter=="قيد القراءة"){filter="قيد القراءة"};Pill("المفضلة",filter=="المفضلة"){filter="المفضلة"};Pill("مكتملة",filter=="مكتملة"){filter="مكتملة"};categories.forEach{Pill(it.name,filter==it.id){filter=it.id}} }
            if(filtered.isEmpty()) EmptyState("مكتبتك فارغة", "أضف الأعمال من تفاصيلها لتظهر هنا.", "استكشاف",{}) else LazyVerticalGrid(columns=GridCells.Fixed(3),modifier=Modifier.fillMaxWidth().heightIn(max=2400.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){items(filtered){item-> Box { Column(Modifier.fillMaxWidth().combinedClickable(onClick={onOpen(item)},onLongClick={menu=item})){Box(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)).background(Panel)){item.coverUrl?.let{AsyncImage(it,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)};if(item.isFavorite)Icon(Icons.Default.Favorite,null,Modifier.align(Alignment.BottomStart).padding(6.dp),tint=Coral)};Text(item.title,maxLines=1,overflow=TextOverflow.Ellipsis) }; DropdownMenu(menu==item,{menu=null}){DropdownMenuItem(text={Text("المفضلة")},onClick={menu=null;onToggleFavorite(item)});DropdownMenuItem(text={Text("تمييز كمقروء")},onClick={menu=null;onMarkRead(item)});DropdownMenuItem(text={Text("إزالة")},onClick={menu=null;onRemove(item)})} } } }
        }
    }
}
private data class DownloadedWork(
    val sourceId: String,
    val mangaUrl: String,
    val manga: SourceManga,
    val source: MangaSource?,
    val records: List<ChapterDownloadEntity>,
    val chapters: List<SourceChapter>,
    val latestAt: Long,
)

@Composable fun DownloadsScreen(
    downloads:List<ChapterDownloadEntity>,
    library:List<LibraryMangaEntity>,
    registry:NativeSourceRegistry,
    onOpen:(SourceMangaRef?,SourceManga,List<SourceChapter>)->Unit,
    onDeleteAll:(String,String)->Unit,
) {
    val available = remember(downloads) { downloads.filter { record ->
        record.status == "completed" && !record.localPath.isNullOrBlank() && runCatching {
            File(record.localPath!!).let { it.isDirectory && it.listFiles()?.any { file -> file.isFile } == true }
        }.getOrDefault(false)
    } }
    val works = remember(available, library, registry) {
        available.groupBy { it.sourceId to it.mangaUrl }.map { (key, unsorted) ->
            val records = unsorted.sortedWith(compareByDescending<ChapterDownloadEntity> { it.chapterNumber ?: -1f }.thenByDescending { it.updatedAt })
            val first = records.first()
            val saved = library.firstOrNull { it.sourceId == key.first && it.mangaUrl == key.second }
            val manga = SourceManga(
                sourceId = key.first,
                url = key.second,
                title = saved?.title?.ifBlank { null } ?: first.mangaTitle.ifBlank { "عمل محمّل" },
                coverUrl = saved?.coverUrl ?: first.mangaCoverUrl,
                description = saved?.description,
                status = saved?.status,
            )
            val chapters = records.map { record ->
                SourceChapter(
                    sourceId = record.sourceId,
                    url = record.chapterUrl,
                    name = record.chapterName.ifBlank { record.chapterUrl.substringAfterLast('/').ifBlank { "فصل محمّل" } },
                    number = record.chapterNumber,
                )
            }
            DownloadedWork(key.first, key.second, manga, registry.find(key.first), records, chapters, records.maxOfOrNull { it.updatedAt } ?: 0L)
        }
    }
    var newestFirst by remember { mutableStateOf(true) }
    val sortedWorks = remember(works, newestFirst) {
        if (newestFirst) works.sortedByDescending { it.latestAt } else works.sortedBy { it.manga.title.lowercase() }
    }
    val storageBytes by produceState(0L, available) {
        value = withContext(Dispatchers.IO) {
            available.sumOf { record ->
                runCatching { File(record.localPath!!).walkTopDown().filter(File::isFile).sumOf(File::length) }.getOrDefault(0L)
            }
        }
    }
    val storageLabel = when {
        storageBytes >= 1024L * 1024 * 1024 -> "%.1f GB".format(storageBytes / (1024.0 * 1024 * 1024))
        storageBytes >= 1024L * 1024 -> "%.0f MB".format(storageBytes / (1024.0 * 1024))
        else -> "${storageBytes / 1024} KB"
    }

    ScreenColumn {
        Header("التحميلات")
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
            Icon(Icons.Default.Storage, null, tint=Coral)
            Column(Modifier.weight(1f).padding(horizontal=10.dp)) {
                Text("التخزين المستخدم", style=MaterialTheme.typography.titleSmall)
                Text("${works.size} أعمال · ${available.size} فصول", color=Muted, style=MaterialTheme.typography.bodySmall)
            }
            Text(storageLabel, color=Coral, fontWeight=FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().padding(vertical=10.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Pill("آخر الإضافات", newestFirst) { newestFirst=true }
            Pill("أبجدي", !newestFirst) { newestFirst=false }
        }
        if (sortedWorks.isEmpty()) {
            EmptyState("لا توجد تنزيلات مكتملة", "نزّل فصولًا من صفحة العمل لتظهر الأعمال هنا.")
        } else {
            LazyVerticalGrid(
                columns=GridCells.Fixed(3),
                modifier=Modifier.fillMaxWidth().heightIn(max=2600.dp),
                horizontalArrangement=Arrangement.spacedBy(12.dp),
                verticalArrangement=Arrangement.spacedBy(14.dp),
            ) {
                items(sortedWorks, key={ "${it.sourceId}:${it.mangaUrl}" }) { work ->
                    var menu by remember { mutableStateOf(false) }
                    Column(Modifier.fillMaxWidth()) {
                        Box(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)).background(Panel)) {
                            if (!work.manga.coverUrl.isNullOrBlank()) {
                                AsyncImage(work.manga.coverUrl, null, Modifier.fillMaxSize().clickable {
                                    onOpen(work.source?.let { SourceMangaRef(it, work.manga) }, work.manga, work.chapters)
                                }, contentScale=ContentScale.Crop)
                            }
                            if (work.manga.coverUrl.isNullOrBlank()) {
                                Box(Modifier.fillMaxSize().clickable { onOpen(work.source?.let { SourceMangaRef(it, work.manga) }, work.manga, work.chapters) }, contentAlignment=Alignment.Center) {
                                    Icon(Icons.Default.AutoStories, null, tint=Muted, modifier=Modifier.size(38.dp))
                                }
                            }
                            IconButton(onClick={menu=true}, modifier=Modifier.align(Alignment.TopEnd)) {
                                Icon(Icons.Default.MoreVert, "خيارات التنزيل", tint=Color.White)
                            }
                            DropdownMenu(expanded=menu, onDismissRequest={menu=false}) {
                                DropdownMenuItem(text={Text("حذف تنزيلات العمل")}, onClick={menu=false;onDeleteAll(work.sourceId,work.mangaUrl)})
                            }
                        }
                        Text(work.manga.title, Modifier.fillMaxWidth().clickable {
                            onOpen(work.source?.let { SourceMangaRef(it, work.manga) }, work.manga, work.chapters)
                        }.padding(top=5.dp), maxLines=1, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.bodyMedium)
                        Text("${work.records.size} فصل", color=Muted, style=MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
@Composable internal fun MoreScreen(settings:AppSettings,onSetting:(AppScreen)->Unit,onExtensions:()->Unit,onIncognito:(Boolean)->Unit,onDownloadOnly:(Boolean)->Unit,onAbout:()->Unit,onOpenProfile:()->Unit) {
    ScreenColumn { Header("المزيد"); ProfileEntryCard(settings.profileName,settings.profileAvatarPath,onOpenProfile); SettingSwitch("التصفح المتخفي","لا تحفظ سجل البحث أو تقدم القراءة",settings.incognitoMode,onIncognito); SettingSwitch("التنزيل فقط","إيقاف الطلبات الشبكية",settings.downloadOnly,onDownloadOnly); listOf("المظهر" to AppScreen.APPEARANCE,"إعدادات المكتبة" to AppScreen.LIBRARY_SETTINGS,"التتبّع" to AppScreen.TRACKING,"الأمان والخصوصية" to AppScreen.PRIVACY,"متقدم" to AppScreen.ADVANCED).forEach{(label,destination)-> ListItem(headlineContent={Text(label)},trailingContent={Icon(Icons.Default.ChevronLeft,null)},modifier=Modifier.clickable{onSetting(destination)}) }; ListItem(headlineContent={Text("حول التطبيق")},modifier=Modifier.clickable(onClick=onAbout)) }
}
@Composable private fun SettingSwitch(title:String,subtitle:String,checked:Boolean,onChange:(Boolean)->Unit){ListItem(headlineContent={Text(title)},supportingContent={Text(subtitle)},trailingContent={Switch(checked,onChange,colors=SwitchDefaults.colors(checkedThumbColor=Coral))})}

private val readerPageCacheMutex = Mutex()
private val readerPageLocks = ConcurrentHashMap<String, Mutex>()
private const val MAX_READER_PAGE_CACHE_BYTES = 512L * 1024 * 1024

private suspend fun cachedReaderPageUri(context: android.content.Context, source: MangaSource, page: SourcePage): String =
    withContext(Dispatchers.IO) {
        if (page.imageUrl.startsWith("file:", ignoreCase=true)) return@withContext page.imageUrl
        val directory = File(context.cacheDir, "reader-pages").apply { mkdirs() }
        val key = MessageDigest.getInstance("SHA-256")
            .digest("${source.id}\n${page.imageUrl}\n${page.referer.orEmpty()}".toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        val target = File(directory, "$key.img")
        readerPageLocks.getOrPut(key) { Mutex() }.withLock {
            if (!target.isFile || target.length() == 0L) {
                val bytes = source.loadPage(page)
                val staging = File(directory, "$key.part")
                staging.writeBytes(bytes)
                if (target.exists()) target.delete()
                if (!staging.renameTo(target)) {
                    staging.delete()
                    throw java.io.IOException("تعذر حفظ صفحة القارئ مؤقتًا")
                }
            }
        }
        target.setLastModified(System.currentTimeMillis())
        readerPageCacheMutex.withLock {
            val files = directory.listFiles()?.filter { it.isFile && it.extension != "part" }.orEmpty()
            var total = files.sumOf { it.length() }
            for (file in files.sortedBy { it.lastModified() }) {
                if (total <= MAX_READER_PAGE_CACHE_BYTES) break
                val fileBytes = file.length()
                if (file != target && file.delete()) total -= fileBytes
            }
        }
        target.toURI().toString()
    }

@Composable private fun SourcePageImage(
    source: MangaSource?,
    page: SourcePage,
    modifier: Modifier,
    contentScale: ContentScale,
) {
    val context = LocalContext.current
    var localUri by remember(source?.id, page) { mutableStateOf<String?>(null) }
    var failed by remember(source?.id, page) { mutableStateOf(false) }
    LaunchedEffect(source?.id, page) {
        localUri = null
        failed = false
        val activeSource = source ?: run { failed = true; return@LaunchedEffect }
        runCatching { cachedReaderPageUri(context, activeSource, page) }
            .onSuccess { localUri = it }
            .onFailure { failed = true }
    }
    if (localUri != null) {
        val request = remember(localUri) { ImageRequest.Builder(context).data(localUri).build() }
        AsyncImage(request, null, modifier, contentScale=contentScale)
    } else {
        Box(modifier.fillMaxWidth().height(220.dp), contentAlignment=Alignment.Center) {
            if (failed) Text("تعذر تحميل الصفحة", color=Muted) else CircularProgressIndicator(color=Coral)
        }
    }
}

@Composable fun ReaderScreen(ref:SourceMangaRef?,chapter:SourceChapter?,chapters:List<SourceChapter>,settings:AppSettings,progress:List<ReadingProgressEntity>,downloads:List<ChapterDownloadEntity>,repository:MangaRepository,onBack:()->Unit,onSettings:()->Unit,onChapterChange:(SourceChapter)->Unit,onProgress:(SourceChapter,Int,Boolean,Int)->Unit,onOpenSettings:()->Unit,onUpdateSettings:(AppSettings)->Unit,activeDownloads:Set<String>,online:Boolean,onDownloadChapter:(SourceChapter)->Unit,onCancelDownload:(SourceChapter)->Unit,onDeleteDownload:(SourceChapter)->Unit) {
    val context=LocalContext.current
    var pages by remember(chapter){mutableStateOf<List<SourcePage>>(emptyList())}; var continuousSegments by remember(chapter){mutableStateOf<List<Pair<SourceChapter,List<SourcePage>>>>(emptyList())}; var loading by remember(chapter){mutableStateOf(chapter!=null)}; var error by remember(chapter){mutableStateOf<String?>(null)}; var nextError by remember(chapter){mutableStateOf<String?>(null)}; var nextLoading by remember(chapter){mutableStateOf(false)}; var page by remember(chapter){mutableIntStateOf(0)}; var controls by remember{mutableStateOf(true)}; var showReaderSettings by remember{mutableStateOf(false)}
    val saved = remember(ref,chapter,downloads) { downloads.firstOrNull { it.sourceId==ref?.source?.id && it.mangaUrl==ref?.manga?.url && it.chapterUrl==chapter?.url && it.status=="completed" && !it.localPath.isNullOrBlank() } }
    LaunchedEffect(ref,chapter,saved,settings.downloadOnly){if(ref!=null&&chapter!=null){loading=true;error=null;runCatching { if(saved!=null){ val dir=File(saved.localPath!!); val files=if(dir.isDirectory) dir.listFiles()?.filter{it.isFile}?.sortedBy{it.name}.orEmpty() else emptyList(); require(files.isNotEmpty()){"ملفات الفصل المحلي غير متاحة"}; files.mapIndexed{idx,file->SourcePage(idx,file.toURI().toString())} } else { require(!settings.downloadOnly){"وضع التنزيل فقط مفعّل ولا يوجد تنزيل مكتمل لهذا الفصل"}; ref.source.pages(chapter) } }.onSuccess{loaded->pages=loaded;continuousSegments=listOf(chapter to loaded);page=(progress.lastOrNull{p->p.sourceId==ref.source.id&&p.mangaUrl==ref.manga.url&&p.chapterUrl==chapter.url}?.pageIndex?:0).coerceIn(0,(loaded.size-1).coerceAtLeast(0))}.onFailure{pages=emptyList();continuousSegments=emptyList();error=it.message};loading=false}}
    var showChapters by remember{mutableStateOf(false)}
    val scrollState=rememberScrollState()
    val readerScope = rememberCoroutineScope()
    fun reportProgress(p:Int,complete:Boolean){ if(chapter!=null) onProgress(chapter,p,complete,pages.size) }
    fun seekPage(target:Int){
        if(pages.isEmpty()) return
        page=target.coerceIn(0,pages.lastIndex)
        if(settings.readerMode!=ReaderMode.PAGED && pages.size>1){
            readerScope.launch {
                withFrameNanos { }
                val max=scrollState.maxValue
                if(max>0) scrollState.animateScrollTo(((page.toFloat()/pages.lastIndex)*max).toInt().coerceIn(0,max))
            }
        }
        reportProgress(page,page>=pages.lastIndex)
    }
    fun move(delta:Int){if(pages.isNotEmpty()) seekPage(page+delta)}
    val latestPage=rememberUpdatedState(page); val latestPages=rememberUpdatedState(pages)
    val latestControls=rememberUpdatedState(controls)
    val chapterEntries = remember(chapters) { ChapterGrouping.order(ChapterGrouping.group(chapters), false) }
    val nextChapter = remember(chapter, chapterEntries) {
        val index = chapterEntries.indexOfFirst { entry -> entry.chapters.any { it.url == chapter?.url } }
        chapterEntries.getOrNull(index + 1)?.primary
    }
    val latestNextChapter = rememberUpdatedState(nextChapter)
    val latestChapterChange = rememberUpdatedState(onChapterChange)
    val atChapterEnd = remember(pages, page, scrollState.value, scrollState.maxValue, settings.readerMode) {
        pages.isNotEmpty() && (if(settings.readerMode==ReaderMode.PAGED) page>=pages.lastIndex
            else scrollState.maxValue==0 || scrollState.value >= (scrollState.maxValue-24).coerceAtLeast(0))
    }
    val latestAtChapterEnd = rememberUpdatedState(atChapterEnd)
    val orderedChapters = remember(chapters) { ChapterGrouping.order(ChapterGrouping.group(chapters), false).flatMap { it.chapters } }
    fun nextAfter(last: SourceChapter?): SourceChapter? {
        val index = orderedChapters.indexOfFirst { it.url == last?.url }
        return orderedChapters.getOrNull(index + 1)
    }
    fun requestNextSegment() {
        if (settings.readerMode == ReaderMode.PAGED || nextLoading || continuousSegments.isEmpty() || ref == null) return
        val next = nextAfter(continuousSegments.last().first) ?: return
        nextLoading = true; nextError = null
        readerScope.launch {
            runCatching { ref.source.pages(next) }.onSuccess { loaded ->
                if (loaded.isNotEmpty() && continuousSegments.none { it.first.url == next.url }) continuousSegments = continuousSegments + (next to loaded.distinctBy { it.imageUrl })
                else if (loaded.isEmpty()) nextError = "لم يُرجع الفصل التالي صفحات متاحة"
            }.onFailure { nextError = it.message ?: "تعذر تحميل الفصل التالي" }
            nextLoading = false
        }
    }
    val continuousPageCount = continuousSegments.sumOf { it.second.size }
    DisposableEffect(chapter){ onDispose{ val c=chapter; val all=latestPages.value; if(c!=null&&all.isNotEmpty()) onProgress(c,latestPage.value,latestPage.value>=all.lastIndex,all.size) } }
    LaunchedEffect(chapter,pages.size,settings.readerMode){
        if(settings.readerMode!=ReaderMode.PAGED&&pages.isNotEmpty()){
            withFrameNanos { }
            val max=scrollState.maxValue
            if(max>0) scrollState.scrollTo(((page.toFloat()/pages.lastIndex)*max).toInt().coerceIn(0,max))
            snapshotFlow{scrollState.value to scrollState.maxValue}.collect{(offset,total)->
                if(total>0){
                    val totalPages=if(settings.readerMode==ReaderMode.PAGED) pages.size else continuousPageCount
                    val global=((offset.toFloat()/total)*(totalPages-1).coerceAtLeast(0)).roundToInt().coerceIn(0,(totalPages-1).coerceAtLeast(0))
                    if(global!=page){
                        page=global
                        var remaining=global
                        var visibleChapter: SourceChapter?=null
                        var visiblePages: List<SourcePage>?=null
                        for ((segmentChapter,segmentPages) in continuousSegments) {
                            if (remaining < segmentPages.size) { visibleChapter=segmentChapter; visiblePages=segmentPages; break }
                            remaining -= segmentPages.size
                        }
                        if (visibleChapter != null && visiblePages != null) {
                            val local=remaining.coerceIn(0,(visiblePages!!.size-1).coerceAtLeast(0))
                            onProgress(visibleChapter!!,local,local>=visiblePages!!.lastIndex,visiblePages!!.size)
                        } else reportProgress(global,global>=pages.lastIndex)
                    }
                    if(total-offset<1400) requestNextSegment()
                }
            }
        }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF0B0D12))
        .pointerInput(settings.readerDirection,settings.touchZonesEnabled,settings.readerMode){detectTapGestures(onDoubleTap={controls=!latestControls.value},onTap={offset->val width=size.width.toFloat();when{!settings.touchZonesEnabled->Unit;offset.x>width*.7f->move(if(settings.readerDirection==ReaderDirection.RIGHT_TO_LEFT)-1 else 1);offset.x<width*.3f->move(if(settings.readerDirection==ReaderDirection.RIGHT_TO_LEFT)1 else -1);else->Unit}})}
        .pointerInput(chapter?.url,pages.size){awaitEachGesture{val down=awaitFirstDown(requireUnconsumed=false,pass=PointerEventPass.Initial);var end=down.position;do{val event=awaitPointerEvent(PointerEventPass.Final);val change=event.changes.firstOrNull{it.id==down.id}?:break;end=change.position}while(event.changes.any{it.id==down.id&&it.pressed});if(down.position.y-end.y>80f&&latestAtChapterEnd.value){latestNextChapter.value?.let{latestChapterChange.value(it)}}}}) {
        if(loading) CircularProgressIndicator(Modifier.align(Alignment.Center),color=Coral) else if(error!=null||pages.isEmpty()) Column(Modifier.align(Alignment.Center).padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(if(error!=null)"تعذر عرض الفصل" else "لا توجد صفحات متاحة",color=Color.White);error?.let{Text(it,color=Muted)}} else {
            if(settings.readerMode==ReaderMode.PAGED){val p=pages.getOrNull(page);p?.let{SourcePageImage(ref?.source,it,Modifier.fillMaxWidth().align(Alignment.Center),contentScale=when(settings.imageScale){ImageScale.FIT_WIDTH->ContentScale.FillWidth;ImageScale.ORIGINAL_SIZE->ContentScale.None;else->ContentScale.Fit})}}
            else Column(Modifier.fillMaxSize().verticalScroll(scrollState),verticalArrangement=Arrangement.spacedBy(if(settings.readerMode==ReaderMode.WEBTOON)0.dp else 8.dp)){
                continuousSegments.forEachIndexed { segmentIndex, (segmentChapter, segmentPages) ->
                    if(segmentIndex>0) Row(Modifier.fillMaxWidth().padding(vertical=16.dp),horizontalArrangement=Arrangement.Center){Text("— ${segmentChapter.name} —",color=Coral,style=MaterialTheme.typography.titleMedium)}
                    segmentPages.forEach { p -> SourcePageImage(ref?.source,p,Modifier.fillMaxWidth(),contentScale=ContentScale.FillWidth) }
                }
                if(nextLoading) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally).padding(20.dp),color=Coral)
                else if(nextError!=null) Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){Text(nextError!!,color=Muted);TextButton(onClick={requestNextSegment()}){Text("إعادة المحاولة",color=Coral)}}
                else if(nextAfter(continuousSegments.lastOrNull()?.first)==null) Text("انتهت الفصول المتاحة لهذا العمل",Modifier.fillMaxWidth().padding(20.dp),color=Muted,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
        if(controls){Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().background(Color(0xCC0B0D12)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null,tint=Color.White)};Text(chapter?.name?:"القارئ",Modifier.weight(1f),color=Color.White,maxLines=1);IconButton(onClick={showChapters=true}){Icon(Icons.Default.FormatListBulleted,"قائمة الفصول",tint=Color.White)};IconButton(onClick={showReaderSettings=true}){Icon(Icons.Default.Settings,null,tint=Color.White)}}
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xCC0B0D12)).padding(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){IconButton(onClick={move(-1)}){Icon(Icons.Default.ChevronLeft,null,tint=Color.White)};Text(if(error!=null)"تعذر تحميل الصفحات" else if(pages.isEmpty())"لا توجد صفحات" else if(settings.readerMode==ReaderMode.PAGED)"${page+1} / ${pages.size}" else "${continuousPageCount} صفحة محملة",color=Color.White);IconButton(onClick={move(1)}){Icon(Icons.Default.ChevronRight,null,tint=Color.White)}};Slider(value=if(pages.isEmpty())0f else page.toFloat(),onValueChange={page=it.roundToInt().coerceIn(0,pages.lastIndex.coerceAtLeast(0))},valueRange=0f..pages.lastIndex.coerceAtLeast(0).toFloat(),onValueChangeFinished={seekPage(page)},colors=SliderDefaults.colors(thumbColor=Coral,activeTrackColor=Coral));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Pill("اتجاه ${if(settings.readerDirection==ReaderDirection.RIGHT_TO_LEFT)"RTL" else "LTR"}",true){onUpdateSettings(settings.copy(readerDirection=if(settings.readerDirection==ReaderDirection.RIGHT_TO_LEFT)ReaderDirection.LEFT_TO_RIGHT else ReaderDirection.RIGHT_TO_LEFT))};Pill("إعدادات القراءة",false){showReaderSettings=true}}}}
    }
    if(showChapters) ReaderChapterSheet(ref=ref,chapters=chapters,current=chapter,progress=progress,downloads=downloads,activeDownloads=activeDownloads,online=online,
        onSelect={target->showChapters=false;if(target.url!=chapter?.url){if(pages.isNotEmpty())reportProgress(page,page>=pages.lastIndex);onChapterChange(target)}},
        onDownload=onDownloadChapter,onCancel=onCancelDownload,onDelete=onDeleteDownload,onDismiss={showChapters=false})
    if(showReaderSettings) ModalBottomSheet(onDismissRequest={showReaderSettings=false}){Column(Modifier.fillMaxWidth().padding(20.dp)){Text("إعدادات القراءة",style=MaterialTheme.typography.titleLarge);listOf(ReaderMode.PAGED to "صفحات",ReaderMode.CONTINUOUS to "مستمر",ReaderMode.WEBTOON to "ويب تون").forEach{(mode,label)->Pill(label,settings.readerMode==mode){onUpdateSettings(settings.copy(readerMode=mode))}};SettingSwitch("ملء الشاشة","",settings.fullscreen){onUpdateSettings(settings.copy(fullscreen=it))};SettingSwitch("إبقاء الشاشة مضاءة","",settings.keepScreenOn){onUpdateSettings(settings.copy(keepScreenOn=it))};SettingSwitch("قص الهوامش","",settings.cropPages){onUpdateSettings(settings.copy(cropPages=it))};Text("سطوع القراءة");Slider(settings.readerBrightness,{onUpdateSettings(settings.copy(readerBrightness=it))});Text("حجم الصورة");ImageScale.values().forEach{scale->Pill(scale.name,settings.imageScale==scale){onUpdateSettings(settings.copy(imageScale=scale))}}}}
}

@Composable fun ExtensionsScreen(
    catalog: ExtensionCatalog?,
    installedExtensions: List<InstalledExtension>,
    sources: List<MangaSource>,
    loading: Boolean,
    error: String?,
    installMessage: String?,
    settings: AppSettings,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onRefreshInstalled: () -> Unit,
    onTrustInstalled: (String) -> Unit,
    onRepositoryChange: (String) -> Unit,
    onFilterAdult: (Boolean) -> Unit,
    onSourceToggle: (String, Boolean) -> Unit,
    onInstalledPackageDetails: (String) -> Unit,
    onInstall: (ExtensionEntry) -> Unit,
) {
    var tab by remember { mutableStateOf("داخل التطبيق") }
    var installConfirm by remember { mutableStateOf<ExtensionEntry?>(null) }
    var activationInfo by remember { mutableStateOf<InstalledExtension?>(null) }
    var adultConfirm by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("ar") }
    var search by remember { mutableStateOf("") }
    var repositoryUrl by remember(settings.extensionRepositoryIndexUrl) { mutableStateOf(settings.extensionRepositoryIndexUrl) }

    ScreenColumn {
        Header("المصادر والإضافات", onBack)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("داخل التطبيق", "مثبتة على الهاتف", "متاحة", "تحديثات").forEach { label ->
                Pill(label, tab == label) { tab = label; if (label == "مثبتة على الهاتف") onRefreshInstalled() }
            }
        }

        when (tab) {
            "داخل التطبيق" -> {
                Text("المصادر المتاحة · العربية والإنجليزية", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (sources.isEmpty()) {
                    EmptyState("لا توجد مصادر مدمجة", "لم يتم إعداد مصدر ضمن التطبيق.")
                } else {
                    sources.forEach { source ->
                        val enabled = settings.isSourceEnabled(source.id)
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(source.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (source.id.startsWith("mihon:")) "إضافة Mihon · ${source.language.ifBlank { "لغة غير محددة" }}" else "مصدر مدمج",
                                    color = Muted,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                            TextButton(onClick = { onSourceToggle(source.id, true) }, enabled = !enabled) { Text("تفعيل") }
                            TextButton(onClick = { onSourceToggle(source.id, false) }, enabled = enabled) { Text("تعطيل") }
                        }
                    }
                }
                Text("تظهر هنا مصادر MangaDex ومصادر Mihon المثبتة التي لغتها العربية أو الإنجليزية فقط.", Modifier.padding(vertical = 8.dp), color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            "مثبتة على الهاتف" -> {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("إضافات مثبتة على الجهاز", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = onRefreshInstalled) { Text("تحديث القائمة") }
                }
                if (installedExtensions.isEmpty()) {
                    EmptyState("لم يتم العثور على إضافات", "اسحب تحديث القائمة بعد تثبيت إضافة متوافقة.")
                } else {
                    installedExtensions.forEach { extension ->
                        ListItem(
                            headlineContent = { Text(extension.label, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                            supportingContent = {
                                Text(
                                    buildString {
                                        append("الإصدار ${extension.versionName.ifBlank { "غير معروف" }} · واجهة ${extension.libVersion.ifBlank { "غير معروفة" }}")
                                        append("\nالثقة: ${if (extension.isTrusted) "موافق عليها" else "تتطلب موافقة"}")
                                        append(" · المصادر المنشأة: ${extension.sources.size}")
                                        append("\n${extension.state}")
                                        if (extension.sources.isNotEmpty()) append("\nالمصادر: ${extension.sources.joinToString("، ") { it.name }}")
                                    },
                                    maxLines = 6,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            trailingContent = {
                                TextButton(onClick = { activationInfo = extension }) {
                                    Text(if (extension.sources.isNotEmpty()) "محمّلة" else if (extension.isTrusted) "إعادة المحاولة" else "مراجعة")
                                }
                            },
                        )
                    }
                }
                Text(
                    "تُحمّل الإضافات بعد الموافقة على توقيعها. فعّل أو عطّل كل مصدر على حدة من تبويب «داخل التطبيق».",
                    Modifier.padding(vertical = 8.dp), color = Muted, style = MaterialTheme.typography.bodySmall,
                )
            }
            "تحديثات" -> EmptyState(
                "تحديثات الإضافات غير مدعومة بعد",
                "يمكن تشغيل الإضافات المثبتة والمتوافقة. فحص تحديثات الإضافات وتنزيلها تلقائيًا غير متاح بعد.",
                "عرض الإضافات المثبتة", { tab = "مثبتة على الهاتف" },
            )
            else -> {
                OutlinedTextField(repositoryUrl, { repositoryUrl = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("رابط مستودع index.pb") })
                Button(onClick = { onRepositoryChange(repositoryUrl.trim()) }, enabled = repositoryUrl.startsWith("https://"), modifier = Modifier.fillMaxWidth()) {
                    Text("إضافة المستودع وتحديث الفهرس")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("إخفاء المحتوى الناضج", Modifier.weight(1f))
                    Switch(settings.hideAdultContent, { if (it) onFilterAdult(true) else adultConfirm = true }, colors = SwitchDefaults.colors(checkedThumbColor = Coral))
                }
                OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), placeholder = { Text("ابحث عن إضافة") }, singleLine = true)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("العربية", language == "ar") { language = "ar" }
                    Pill("كل اللغات", language == "الكل") { language = "الكل" }
                }
                Text("بعد تثبيت APK، افتح «مثبتة على الهاتف» ثم وافق على توقيعه لتحميل مصادره.", Modifier.padding(top = 4.dp), color = Muted, style = MaterialTheme.typography.bodySmall)
                installMessage?.let { Text(it, Modifier.padding(8.dp), color = Coral) }
                if (loading && catalog == null) StateMessage(true, null, false)
                else if (error != null && catalog == null) StateMessage(false, error, false, onRefresh)
                else {
                    val entries = catalog?.entries.orEmpty().filter {
                        it.name.contains(search, true) &&
                            (language == "الكل" || it.hasArabicSource) &&
                            (!settings.hideAdultContent || !it.isNsfw)
                    }
                    Text(catalog?.let { "${it.metadata?.name ?: "المستودع"} · ${it.indexFormat}" } ?: "المستودع", color = Muted)
                    if (entries.isEmpty()) EmptyState("لا توجد إضافات مطابقة", "لم يعرض المستودع إضافات بهذه التصفية.", "تحديث", onRefresh)
                    else entries.forEach { entry ->
                        val languageLabel = when {
                            entry.hasArabicSource && entry.languages.size > 1 -> "مصدر عربي ضمن حزمة متعددة اللغات"
                            entry.hasArabicSource -> "مصدر باللغة العربية"
                            else -> "حزمة متعددة اللغات"
                        }
                        ListItem(
                            headlineContent = { Text(entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                            supportingContent = {
                                Text(
                                    if (entry.version.isBlank()) languageLabel else "$languageLabel · الإصدار ${entry.version}",
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            trailingContent = { TextButton(onClick = { installConfirm = entry }) { Text("تثبيت") } },
                        )
                    }
                }
            }
        }
    }

    installConfirm?.let { entry ->
        AlertDialog(
            onDismissRequest = { installConfirm = null },
            title = { Text("تثبيت إضافة") },
            text = { Text("سيتم التحقق من ملف APK وفتح مُثبّت Android. بعد التثبيت، ستظهر الإضافة في تبويب «مثبتة على الهاتف» ويمكن تحميلها بعد مراجعة التوقيع.") },
            confirmButton = { TextButton(onClick = { installConfirm = null; onInstall(entry) }) { Text("متابعة") } },
            dismissButton = { TextButton(onClick = { installConfirm = null }) { Text("إلغاء") } },
        )
    }
    activationInfo?.let { extension ->
        AlertDialog(
            onDismissRequest = { activationInfo = null },
            title = { Text(if (extension.sources.isNotEmpty()) "مصادر الإضافة جاهزة" else "مراجعة الإضافة") },
            text = {
                Text(
                    "${extension.label}\nالحالة: ${extension.state}\nواجهة Mihon: ${extension.libVersion.ifBlank { "غير معروفة" }}\nبصمة التوقيع SHA-256: ${extension.signerFingerprint}\n\nالموافقة تسمح بتشغيل كود APK هذا داخل MangaReplica. لا توافق إلا إذا كنت تثق بمصدر الإضافة.",
                )
            },
            confirmButton = {
                TextButton(onClick = { activationInfo = null; onTrustInstalled(extension.packageName) }) {
                    Text(if (extension.isTrusted) "إعادة التحميل" else "أثق بهذا التوقيع وأحمّل")
                }
            },
            dismissButton = { TextButton(onClick = { activationInfo = null }) { Text("حسنًا") } },
        )
    }
    if (adultConfirm) AlertDialog(
        onDismissRequest = { adultConfirm = false },
        title = { Text("تأكيد عرض المحتوى البالغ") },
        text = { Text("هل تريد إظهار المحتوى المصنّف للبالغين؟") },
        confirmButton = { TextButton(onClick = { adultConfirm = false; onFilterAdult(false) }) { Text("أوافق") } },
        dismissButton = { TextButton(onClick = { adultConfirm = false }) { Text("إبقاء الحجب") } },
    )
}
@Composable fun AppearanceScreen(settings:AppSettings,onBack:()->Unit,onUpdate:(AppSettings)->Unit,onAdultConfirm:()->Unit) {
    ScreenColumn { Header("المظهر",onBack);Text("السمة",style=MaterialTheme.typography.titleLarge);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ThemeMode.values().forEach{mode->Pill(when(mode){ThemeMode.SYSTEM->"النظام";ThemeMode.LIGHT->"فاتح";ThemeMode.DARK->"داكن"},settings.themeMode==mode){onUpdate(settings.copy(themeMode=mode))}}}; SettingSwitch("أسود AMOLED","خلفية سوداء حقيقية في الوضع الداكن",settings.trueBlackAmoled){onUpdate(settings.copy(trueBlackAmoled=it))};SectionTitle("اللون الأساسي");Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){listOf(0xFFFF6B4A,0xFFFF8A65,0xFFB06CFF,0xFF4DB6AC,0xFF4D87F5).forEach{raw->val color=Color(raw);Surface(Modifier.size(44.dp).clickable{onUpdate(settings.copy(accentColorArgb=raw.toInt()))},shape=RoundedCornerShape(50),color=color,border=if(settings.accentColorArgb==raw.toInt())BorderStroke(3.dp,MaterialTheme.colorScheme.onSurface)else null){}}};SettingSwitch("إظهار الأعمال الرائجة","قسم الرائج في الصفحة الرئيسية",settings.showTrending){onUpdate(settings.copy(showTrending=it))};SettingSwitch("إظهار آخر التحديثات","قسم التحديثات في الصفحة الرئيسية",settings.showUpdates){onUpdate(settings.copy(showUpdates=it))};SettingSwitch("إخفاء المحتوى الناضج","الخيار الآمن افتراضيًا",settings.hideAdultContent){if(it)onUpdate(settings.copy(hideAdultContent=true))else onAdultConfirm()} }
}
@Composable fun LibrarySettingsScreen(settings:AppSettings,store:MangaRepository,library:List<LibraryMangaEntity>,progress:List<ReadingProgressEntity>,downloads:List<ChapterDownloadEntity>,categories:List<MangaCategoryEntity>,searchHistory:List<SearchHistoryEntity>,onBack:()->Unit,onUpdate:(AppSettings)->Unit) {
    val scope= rememberCoroutineScope(); var category by remember{mutableStateOf("")}; var newCategory by remember{mutableStateOf("")}; ScreenColumn { Header("إعدادات المكتبة",onBack);SettingSwitch("تحديث عبر Wi-Fi فقط","تجنب استهلاك بيانات الهاتف",settings.wifiOnlyUpdates){onUpdate(settings.copy(wifiOnlyUpdates=it))};SettingSwitch("التنزيل عبر Wi-Fi فقط","",settings.wifiOnlyDownloads){onUpdate(settings.copy(wifiOnlyDownloads=it))};SettingSwitch("حذف الفصل بعد قراءته","",settings.deleteChapterAfterRead){onUpdate(settings.copy(deleteChapterAfterRead=it))};Text("مجلد التنزيلات",style=MaterialTheme.typography.titleLarge);Text(settings.downloadFolder.ifBlank{"المجلد الافتراضي للتطبيق"},color=Muted);Text("التصنيفات",style=MaterialTheme.typography.titleLarge,modifier=Modifier.padding(top=16.dp));Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(newCategory,{newCategory=it},Modifier.weight(1f),placeholder={Text("اسم التصنيف")},singleLine=true);TextButton(onClick={if(newCategory.isNotBlank()){scope.launch{store.saveCategory(MangaCategoryEntity(java.util.UUID.randomUUID().toString(),newCategory.trim()))};newCategory=""}}){Text("إضافة",color=Coral)}};categories.forEach{ListItem(headlineContent={Text(it.name)},trailingContent={IconButton(onClick={scope.launch{store.removeCategory(it.id)}}){Icon(Icons.Default.Delete,null)}})};BackupRestoreActions(store,library,progress,categories,searchHistory,settings,onUpdate);SectionTitle("إحصاءات المكتبة");Text("الأعمال: ${library.size} · تقدم القراءة: ${progress.size} · التنزيلات: ${downloads.size}",color=Muted) }
}
@Composable fun StaticSettingsScreen(title:String,description:String,onBack:()->Unit) { ScreenColumn { Header(title,onBack);EmptyState(title,description) } }
@Composable fun AboutScreen(onBack:()->Unit) { ScreenColumn { Header("حول التطبيق",onBack);Text("مانهوا",color=Coral,style=MaterialTheme.typography.displaySmall);Text("قارئ مانغا بواجهة عربية ومصادر قابلة للتوسّع.",color=Muted);Spacer(Modifier.height(12.dp));Text("الإصدار 0.9.1");Text("المصادر المدمجة وإدارة المكتبة تعمل ضمن التطبيق. لا يتم ادعاء تحميل runtime إضافي.",Modifier.padding(top=12.dp),color=Muted) } }

@Composable internal fun FloatingBottomNavigation(selected:AppScreen,onSelect:(AppScreen)->Unit,modifier:Modifier=Modifier) {
    val tabs=listOf(Triple("الرئيسية","HOME",Icons.Default.Home),Triple("استكشاف","EXPLORE",Icons.Default.Explore),Triple("المكتبة","LIBRARY",Icons.Default.Bookmark),Triple("التحميلات","DOWNLOADS",Icons.Default.Download),Triple("المزيد","MORE",Icons.Default.MoreHoriz))
    NavigationBar(modifier=modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=10.dp).clip(RoundedCornerShape(24.dp)),containerColor=Panel){tabs.forEach{(label,id,icon)->val active=selected.name==id;NavigationBarItem(selected=active,onClick={runCatching{onSelect(AppScreen.valueOf(id))}},icon={Icon(icon,label)},label={Text(label,maxLines=1)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Coral,selectedTextColor=Coral,indicatorColor=Color(0x223F2520),unselectedIconColor=Muted,unselectedTextColor=Muted))}}
}

@Composable private fun ProfileEntryCard(name:String, avatarPath:String, onClick:()->Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom=12.dp).clip(RoundedCornerShape(18.dp)).background(Panel).clickable(role=androidx.compose.ui.semantics.Role.Button,onClick=onClick).padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
        AppAvatar(avatarPath, 52.dp)
        Column(Modifier.weight(1f).padding(horizontal=12.dp)) {
            Text(name.ifBlank{"قارئ مانهوا"}, style=MaterialTheme.typography.titleMedium, maxLines=1, overflow=TextOverflow.Ellipsis)
            Text("الملف الشخصي والإحصائيات", color=Muted, style=MaterialTheme.typography.bodySmall)
        }
        Icon(Icons.Default.ChevronLeft, null, tint=Muted)
    }
}
