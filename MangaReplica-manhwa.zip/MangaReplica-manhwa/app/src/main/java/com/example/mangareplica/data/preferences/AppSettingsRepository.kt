package com.example.mangareplica.data.preferences

import android.content.Context
import androidx.datastore.core.CorruptionException
import androidx.datastore.core.DataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.appSettingsStore: DataStore<Preferences> by preferencesDataStore(
    name = "app_settings",
    corruptionHandler = ReplaceFileCorruptionHandler { exception ->
        // A corrupt preferences file is replaced with an empty file; AppSettings defaults
        // are then applied by the mapping below. Keep the failure visible to diagnostics.
        if (exception !is CorruptionException) throw exception
        emptyPreferences()
    },
)

/** Preferences-backed, atomic settings access. Construct with [from] or inject a DataStore. */
class AppSettingsRepository(private val dataStore: DataStore<Preferences>) {
    constructor(context: Context) : this(context.appSettingsStore)

    /** Emits defaults for absent/corrupt values. I/O failures are not silently swallowed. */
    val settings: Flow<AppSettings> = dataStore.data
        .catch { cause ->
            if (cause is IOException) emit(emptyPreferences()) else throw cause
        }
        .map { preferences -> preferences.toSettings() }

    /** Alias useful at call sites that prefer an explicit flow name. */
    val settingsFlow: Flow<AppSettings> get() = settings

    /** Atomically read-modify-write all settings; DataStore serializes concurrent updates. */
    suspend fun update(transform: (AppSettings) -> AppSettings) {
        dataStore.edit { prefs ->
            val next = transform(prefs.toSettings())
            prefs[Keys.themeMode] = next.themeMode.name
            prefs[Keys.trueBlackAmoled] = next.trueBlackAmoled
            prefs[Keys.accentColorArgb] = next.accentColorArgb
            prefs[Keys.homeSourceFilter] = next.homeSourceFilter
            prefs[Keys.enabledSourceIds] = next.enabledSourceIds
            prefs[Keys.extensionRepositoryIndexUrl] = next.extensionRepositoryIndexUrl
            prefs[Keys.showBanners] = next.showBanners
            prefs[Keys.showContinueReading] = next.showContinueReading
            prefs[Keys.showTrending] = next.showTrending
            prefs[Keys.showUpdates] = next.showUpdates
            prefs[Keys.showNew] = next.showNew
            prefs[Keys.showSourceBadges] = next.showSourceBadges
            prefs[Keys.hideAdultContent] = next.hideAdultContent
            prefs[Keys.wifiOnlyUpdates] = next.wifiOnlyUpdates
            prefs[Keys.wifiOnlyDownloads] = next.wifiOnlyDownloads
            prefs[Keys.deleteChapterAfterRead] = next.deleteChapterAfterRead
            prefs[Keys.downloadFolder] = next.downloadFolder
            prefs[Keys.readerMode] = next.readerMode.name
            prefs[Keys.readerDirection] = next.readerDirection.name
            prefs[Keys.fullscreen] = next.fullscreen
            prefs[Keys.cropPages] = next.cropPages
            prefs[Keys.keepScreenOn] = next.keepScreenOn
            prefs[Keys.volumeKeysNavigation] = next.volumeKeysNavigation
            prefs[Keys.touchZonesEnabled] = next.touchZonesEnabled
            prefs[Keys.imageScale] = next.imageScale.name
            prefs[Keys.grayscaleFilter] = next.grayscaleFilter
            prefs[Keys.readerBrightness] = next.readerBrightness.coerceIn(0f, 1f)
            prefs[Keys.incognitoMode] = next.incognitoMode
            prefs[Keys.downloadOnly] = next.downloadOnly
            prefs[Keys.backupFrequency] = next.backupFrequency.name
            prefs[Keys.profileName] = next.profileName
            prefs[Keys.profileBio] = next.profileBio
            prefs[Keys.profileAvatarPath] = next.profileAvatarPath
            prefs[Keys.profileJoinedAt] = next.profileJoinedAt
            prefs[Keys.latestTypeFilter] = next.latestTypeFilter
            prefs[Keys.lastBackupAt] = next.lastBackupAt
        }
    }

    suspend fun setThemeMode(value: ThemeMode) = update { it.copy(themeMode = value) }
    suspend fun setTrueBlackAmoled(value: Boolean) = update { it.copy(trueBlackAmoled = value) }
    suspend fun setAccentColorArgb(value: Int) = update { it.copy(accentColorArgb = value) }
    suspend fun setAccentColorHex(value: String) {
        val normalized = value.trim().removePrefix("#")
        require(normalized.matches(Regex("(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{8})"))) {
            "Accent color must be RRGGBB or AARRGGBB hex"
        }
        val argb = (if (normalized.length == 6) "FF$normalized" else normalized).toLong(16).toInt()
        setAccentColorArgb(argb)
    }
    suspend fun setHomeSourceFilter(value: String) = update {
        it.copy(homeSourceFilter = value.trim().ifEmpty { "all" })
    }
    suspend fun setSourceEnabled(sourceId: String, enabled: Boolean, allSourceIds: Set<String>) = update { current ->
        val currentIds = if ("*" in current.enabledSourceIds) allSourceIds else current.enabledSourceIds
        val next = if (enabled) currentIds + sourceId else currentIds - sourceId
        current.copy(enabledSourceIds = next)
    }
    suspend fun setShowBanners(value: Boolean) = update { it.copy(showBanners = value) }
    suspend fun setShowContinueReading(value: Boolean) = update { it.copy(showContinueReading = value) }
    suspend fun setShowTrending(value: Boolean) = update { it.copy(showTrending = value) }
    suspend fun setShowUpdates(value: Boolean) = update { it.copy(showUpdates = value) }
    suspend fun setShowNew(value: Boolean) = update { it.copy(showNew = value) }
    suspend fun setShowSourceBadges(value: Boolean) = update { it.copy(showSourceBadges = value) }
    suspend fun setHideAdultContent(value: Boolean) = update { it.copy(hideAdultContent = value) }
    suspend fun setWifiOnlyUpdates(value: Boolean) = update { it.copy(wifiOnlyUpdates = value) }
    suspend fun setWifiOnlyDownloads(value: Boolean) = update { it.copy(wifiOnlyDownloads = value) }
    suspend fun setDeleteChapterAfterRead(value: Boolean) = update { it.copy(deleteChapterAfterRead = value) }
    suspend fun setDownloadFolder(value: String) = update { it.copy(downloadFolder = value.trim()) }
    suspend fun setReaderMode(value: ReaderMode) = update { it.copy(readerMode = value) }
    suspend fun setReaderDirection(value: ReaderDirection) = update { it.copy(readerDirection = value) }
    suspend fun setFullscreen(value: Boolean) = update { it.copy(fullscreen = value) }
    suspend fun setCropPages(value: Boolean) = update { it.copy(cropPages = value) }
    suspend fun setKeepScreenOn(value: Boolean) = update { it.copy(keepScreenOn = value) }
    suspend fun setVolumeKeysNavigation(value: Boolean) = update { it.copy(volumeKeysNavigation = value) }
    suspend fun setTouchZonesEnabled(value: Boolean) = update { it.copy(touchZonesEnabled = value) }
    suspend fun setImageScale(value: ImageScale) = update { it.copy(imageScale = value) }
    suspend fun setGrayscaleFilter(value: Boolean) = update { it.copy(grayscaleFilter = value) }
    suspend fun setReaderBrightness(value: Float) = update { it.copy(readerBrightness = value.coerceIn(0f, 1f)) }
    suspend fun setIncognitoMode(value: Boolean) = update { it.copy(incognitoMode = value) }
    suspend fun setDownloadOnly(value: Boolean) = update { it.copy(downloadOnly = value) }
    suspend fun setBackupFrequency(value: BackupFrequency) = update { it.copy(backupFrequency = value) }

    private fun Preferences.toSettings() = AppSettings(
        themeMode = enumValue(this[Keys.themeMode], ThemeMode.SYSTEM),
        trueBlackAmoled = this[Keys.trueBlackAmoled] ?: false,
        accentColorArgb = this[Keys.accentColorArgb] ?: 0xFFFF6B4A.toInt(),
        homeSourceFilter = this[Keys.homeSourceFilter] ?: "all",
        enabledSourceIds = this[Keys.enabledSourceIds] ?: setOf("*"),
        extensionRepositoryIndexUrl = this[Keys.extensionRepositoryIndexUrl] ?: "https://github.com/keiyoushi/extensions/raw/repo/index.pb",
        showBanners = this[Keys.showBanners] ?: true,
        showContinueReading = this[Keys.showContinueReading] ?: true,
        showTrending = this[Keys.showTrending] ?: true,
        showUpdates = this[Keys.showUpdates] ?: true,
        showNew = this[Keys.showNew] ?: true,
        showSourceBadges = this[Keys.showSourceBadges] ?: true,
        hideAdultContent = this[Keys.hideAdultContent] ?: true,
        wifiOnlyUpdates = this[Keys.wifiOnlyUpdates] ?: true,
        wifiOnlyDownloads = this[Keys.wifiOnlyDownloads] ?: true,
        deleteChapterAfterRead = this[Keys.deleteChapterAfterRead] ?: false,
        downloadFolder = this[Keys.downloadFolder] ?: "",
        readerMode = enumValue(this[Keys.readerMode], ReaderMode.PAGED),
        readerDirection = enumValue(this[Keys.readerDirection], ReaderDirection.RIGHT_TO_LEFT),
        fullscreen = this[Keys.fullscreen] ?: true,
        cropPages = this[Keys.cropPages] ?: false,
        keepScreenOn = this[Keys.keepScreenOn] ?: true,
        volumeKeysNavigation = this[Keys.volumeKeysNavigation] ?: false,
        touchZonesEnabled = this[Keys.touchZonesEnabled] ?: true,
        imageScale = enumValue(this[Keys.imageScale], ImageScale.FIT_SCREEN),
        grayscaleFilter = this[Keys.grayscaleFilter] ?: false,
        readerBrightness = (this[Keys.readerBrightness] ?: 1f).coerceIn(0f, 1f),
        incognitoMode = this[Keys.incognitoMode] ?: false,
        downloadOnly = this[Keys.downloadOnly] ?: false,
        backupFrequency = enumValue(this[Keys.backupFrequency], BackupFrequency.WEEKLY),
        profileName = this[Keys.profileName] ?: "",
        profileBio = this[Keys.profileBio] ?: "",
        profileAvatarPath = this[Keys.profileAvatarPath] ?: "",
        profileJoinedAt = this[Keys.profileJoinedAt] ?: 0L,
        latestTypeFilter = this[Keys.latestTypeFilter] ?: "all",
        lastBackupAt = this[Keys.lastBackupAt] ?: 0L,
    )

    private inline fun <reified T : Enum<T>> enumValue(value: String?, default: T): T =
        value?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: default

    private object Keys {
        val themeMode = stringPreferencesKey("theme_mode")
        val trueBlackAmoled = booleanPreferencesKey("true_black_amoled")
        val accentColorArgb = intPreferencesKey("accent_color_argb")
        val homeSourceFilter = stringPreferencesKey("home_source_filter")
        val enabledSourceIds = stringSetPreferencesKey("enabled_source_ids")
        val extensionRepositoryIndexUrl = stringPreferencesKey("extension_repository_index_url")
        val showBanners = booleanPreferencesKey("show_banners")
        val showContinueReading = booleanPreferencesKey("show_continue_reading")
        val showTrending = booleanPreferencesKey("show_trending")
        val showUpdates = booleanPreferencesKey("show_updates")
        val showNew = booleanPreferencesKey("show_new")
        val showSourceBadges = booleanPreferencesKey("show_source_badges")
        val hideAdultContent = booleanPreferencesKey("hide_adult_content")
        val wifiOnlyUpdates = booleanPreferencesKey("wifi_only_updates")
        val wifiOnlyDownloads = booleanPreferencesKey("wifi_only_downloads")
        val deleteChapterAfterRead = booleanPreferencesKey("delete_chapter_after_read")
        val downloadFolder = stringPreferencesKey("download_folder")
        val readerMode = stringPreferencesKey("reader_mode")
        val readerDirection = stringPreferencesKey("reader_direction")
        val fullscreen = booleanPreferencesKey("fullscreen")
        val cropPages = booleanPreferencesKey("crop_pages")
        val keepScreenOn = booleanPreferencesKey("keep_screen_on")
        val volumeKeysNavigation = booleanPreferencesKey("volume_keys_navigation")
        val touchZonesEnabled = booleanPreferencesKey("touch_zones_enabled")
        val imageScale = stringPreferencesKey("image_scale")
        val grayscaleFilter = booleanPreferencesKey("grayscale_filter")
        val readerBrightness = floatPreferencesKey("reader_brightness")
        val incognitoMode = booleanPreferencesKey("incognito_mode")
        val downloadOnly = booleanPreferencesKey("download_only")
        val backupFrequency = stringPreferencesKey("backup_frequency")
        val profileName = stringPreferencesKey("profile_name")
        val profileBio = stringPreferencesKey("profile_bio")
        val profileAvatarPath = stringPreferencesKey("profile_avatar_path")
        val profileJoinedAt = longPreferencesKey("profile_joined_at")
        val latestTypeFilter = stringPreferencesKey("latest_type_filter")
        val lastBackupAt = longPreferencesKey("last_backup_at")
    }
}
