package com.example.mangareplica.data.sources

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.io.IOException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import android.util.Log
import kotlin.coroutines.resume

/**
 * First-party website adapters. Each provider owns its URL scheme and parsing rules; shared code
 * is limited to HTTP safety, URL normalization and common metadata extraction.
 */
private val websiteHttp by lazy {
    OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .writeTimeout(6, TimeUnit.SECONDS)
        .callTimeout(6, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
}

/** Cancels the underlying HTTP call when its coroutine is cancelled or times out. */
private suspend fun executeWebsiteRequest(request: Request): Response =
    kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
        val call = websiteHttp.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, error: IOException) {
                if (continuation.isActive) continuation.resumeWith(Result.failure(error))
            }

            override fun onResponse(call: Call, response: Response) {
                if (continuation.isActive) continuation.resume(response) else response.close()
            }
        })
    }

abstract class WebsiteScraper(
    final override val id: String,
    final override val name: String,
    final override val language: String,
    protected val baseUrl: String,
) : MangaSource {
    final override val isBuiltIn: Boolean = true

    protected suspend fun document(url: String, referer: String = baseUrl): Document = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
            .header("Accept-Language", "ar,en-US;q=0.8,en;q=0.6")
            .header("Referer", referer)
            .get()
            .build()
        executeWebsiteRequest(request).use { response ->
            if (!response.isSuccessful) {
                Log.w("MangaSource", "source=$id stage=document url=$url http=${response.code}")
                throw IOException("HTTP ${response.code}")
            }
            val html = response.body?.string().orEmpty()
            if (html.isBlank()) {
                Log.w("MangaSource", "source=$id stage=document url=$url error=empty_response")
                throw IOException("استجابة فارغة من الموقع")
            }
            Jsoup.parse(html, response.request.url.toString())
        }
    }

    protected suspend fun ajaxDocument(url: String, fields: List<Pair<String, String>>, referer: String): Document = withContext(Dispatchers.IO) {
        val body = FormBody.Builder().apply { fields.forEach { (key, value) -> add(key, value) } }.build()
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "text/html, */*; q=0.01")
            .header("X-Requested-With", "XMLHttpRequest")
            .header("Origin", baseUrl.trimEnd('/'))
            .header("Referer", referer)
            .post(body)
            .build()
        executeWebsiteRequest(request).use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            val html = response.body?.string().orEmpty()
            if (html.isBlank()) throw IOException("استجابة فصول فارغة")
            Jsoup.parse(html, referer)
        }
    }

    protected fun absolute(doc: Document, raw: String?): String? {
        val value = raw?.trim().orEmpty()
        if (value.isBlank() || value.startsWith("data:") || value == "#") return null
        return runCatching { URL(URL(doc.location()), value).toString() }.getOrNull()
    }

    protected fun imageUrl(doc: Document, element: Element?): String? {
        if (element == null) return null
        val raw = sequenceOf("data-src", "data-lazy-src", "data-original", "data-lzl-src", "data-manga-src", "data-image", "src")
            .map { element.attr(it) }
            .firstOrNull { it.isNotBlank() && !it.startsWith("data:image") }
            ?: element.attr("srcset").split(',').asSequence().lastOrNull()?.trim()?.substringBefore(' ')
                ?.takeIf(String::isNotBlank)
        return absolute(doc, raw)
    }

    protected fun card(doc: Document, element: Element, fallbackSelector: String = "h3, h2, .tt, .post-title, .manga-title, .title"): SourceManga? {
        val link = if (element.tagName().equals("a", ignoreCase = true) && element.hasAttr("href")) {
            element
        } else {
            element.selectFirst("a[href]")
        } ?: return null
        val href = absolute(doc, link.attr("href")) ?: return null
        if (!href.startsWith(baseUrl, ignoreCase = true)) return null
        val title = sequenceOf(
            link.attr("title"),
            element.selectFirst(fallbackSelector)?.text().orEmpty(),
            element.selectFirst(".tt, .title, h3, h2")?.text().orEmpty(),
            link.text(),
        ).map(String::trim).firstOrNull { it.isNotBlank() } ?: return null
        return SourceManga(id, href, title, imageUrl(doc, element.selectFirst("img")))
    }

    protected fun text(doc: Document, selectors: List<String>): String? = selectors.asSequence()
        .mapNotNull { selector -> doc.selectFirst(selector)?.text()?.trim()?.takeIf(String::isNotBlank) }
        .firstOrNull()

    protected fun parseChapter(doc: Document, row: Element, chapterLink: Element? = row.selectFirst("a[href]")): SourceChapter? {
        val link = chapterLink ?: return null
        val href = absolute(doc, link.attr("href")) ?: return null
        val label = (row.selectFirst(".chapter-title, .ch-num, .chapter-name, .epl-num")?.text()
            ?: link.text()).trim().ifBlank { "فصل" }
        val num = Regex("(?i)(?:chapter|الفصل|ch\\.?|episode)?\\s*([0-9]+(?:\\.[0-9]+)?)")
            .find(label)?.groupValues?.getOrNull(1)?.toFloatOrNull()
        val dateText = row.selectFirst("time, .chapter-release-date, .ch-date, .date, .epl-date")?.let {
            it.attr("datetime").ifBlank { it.text() }
        }
        return SourceChapter(id, href, label, num, parseDate(dateText), "ar")
    }

    protected fun parseImages(doc: Document, selectors: List<String>): List<SourcePage> {
        val selected = linkedSetOf<Element>()
        selectors.forEach { selector -> selected += doc.select(selector) }
        // Reader pages may also be exposed in a noscript fallback. Keep the scope narrow so
        // covers, avatars, and adverts are never mistaken for chapter pages.
        doc.select(".chapter-pages noscript, .reading-content noscript, #readerarea noscript, .reader noscript")
            .flatMap { Jsoup.parse(it.html()).select("img") }
            .forEach { selected.add(it) }
        val urls = selected.mapNotNull { element ->
            if (element.tagName().equals("canvas", true)) {
                absolute(doc, element.attr("data-src").ifBlank { element.attr("data-image").ifBlank { element.attr("src") } })
            } else imageUrl(doc, element)
        }.distinct()
        return urls.mapIndexed { index, url ->
            SourcePage(
                index = index,
                imageUrl = url,
                referer = doc.location(),
                headers = mapOf("User-Agent" to WebsiteScraper.USER_AGENT, "Accept" to "image/avif,image/webp,image/*,*/*;q=0.8"),
            )
        }
    }

    protected fun parseDate(value: String?): Long? {
        val raw = value?.trim()?.takeIf(String::isNotBlank) ?: return null
        raw.toLongOrNull()?.let { return if (it < 10_000_000_000L) it * 1000 else it }
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy/MM/dd",
            "MMMM d, yyyy", "MMMM dd, yyyy", "MMM d, yyyy",
        )
        return patterns.firstNotNullOfOrNull { pattern ->
            runCatching {
                SimpleDateFormat(pattern, Locale.US).parse(raw)?.time
                    ?: SimpleDateFormat(pattern, Locale.forLanguageTag("ar")).parse(raw)?.time
            }.getOrNull()
        }
    }

    protected fun pagePath(path: String, page: Int): String {
        val normalized = path.trimEnd('/')
        return if (page <= 0) "$baseUrl$normalized/" else "$baseUrl$normalized/page/${page + 1}/"
    }

    protected fun requireOwner(manga: SourceManga) {
        require(manga.sourceId == id) { "العمل لا يتبع هذا القارئ" }
    }

    protected fun requireOwner(chapter: SourceChapter) {
        require(chapter.sourceId == id) { "الفصل لا يتبع هذا القارئ" }
    }

    companion object {
        const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    }
}

/** Team-X / Olympus: the site's search and chapter cards have dedicated endpoints/selectors. */
class TeamXSource : WebsiteScraper("site:teamx", "مصدر مدمج 1", "ar", "https://olympustaff.com") {
    override suspend fun popular(page: Int): List<SourceManga> {
        val suffix = if (page <= 0) "" else "?page=${page + 1}"
        val doc = document("$baseUrl/series/$suffix")
        return doc.select("div.listupd div.bsx, .listupd .bsx, .box .uta").mapNotNull { card(doc, it, "h3, .tt") }
    }

    override suspend fun latest(page: Int): List<SourceManga> {
        val suffix = if (page <= 0) "" else "?page=${page + 1}"
        val doc = document("$baseUrl/$suffix")
        return doc.select("div.last-chapter div.box, .box .uta").mapNotNull { card(doc, it, "div.info h3, h3") }
    }

    override suspend fun search(query: String, page: Int): List<SourceManga> {
        if (page > 0) return emptyList()
        val url = "$baseUrl/search".toHttpUrl().newBuilder().addQueryParameter("keyword", query).build()
        val doc = document(url.toString())
        return doc.select("div.tx-grid a.tx-card, .tx-grid .tx-card").mapNotNull { card(doc, it, "h3") }
    }

    override suspend fun details(manga: SourceManga): SourceManga {
        requireOwner(manga)
        val doc = document(manga.url)
        val title = text(doc, listOf("div.author-info-title h1", "h1")) ?: manga.title
        val status = text(doc, listOf(".full-list-info > small:first-child:contains(الحالة) + small"))
        val author = text(doc, listOf(".full-list-info > small:first-child:contains(الرسام) + small"))
        val genres = doc.select(".review-author-info a, .full-list-info a[href*='genre']").map { it.text().trim() }.filter(String::isNotBlank).distinct()
        return manga.copy(
            title = title,
            coverUrl = imageUrl(doc, doc.selectFirst(".text-right img, img.shadow-sm")) ?: manga.coverUrl,
            description = text(doc, listOf(".review-content p", ".review-content")),
            status = status,
            author = author,
            genres = genres,
        )
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> {
        requireOwner(manga)
        val first = document(manga.url)
        val result = linkedMapOf<String, SourceChapter>()
        fun collect(doc: Document) {
            doc.select("div.chapter-card").forEach { row ->
                if (row.selectFirst("span.locked, .locked") != null) return@forEach
                val chapter = parseChapter(doc, row, row.selectFirst("a.chapter-link[href], a[href*='/series/']")) ?: return@forEach
                result[chapter.url] = chapter.copy(
                    name = row.selectFirst(".chapter-info .chapter-title")?.text()?.trim()?.ifBlank { null } ?: chapter.name,
                    number = row.attr("data-number").toFloatOrNull() ?: chapter.number,
                    uploadDate = row.attr("data-date").toLongOrNull()?.let { if (it < 10_000_000_000L) it * 1000 else it } ?: chapter.uploadDate,
                )
            }
        }
        collect(first)
        val lastPage = first.select("ul.pagination a.page-link").mapNotNull { Regex("[?&]page=(\\d+)").find(it.attr("href"))?.groupValues?.getOrNull(1)?.toIntOrNull() }.maxOrNull() ?: 1
        for (p in 2..lastPage.coerceAtMost(30)) collect(document(manga.url.toHttpUrl().newBuilder().setQueryParameter("page", p.toString()).build().toString()))
        return result.values.sortedWith(compareByDescending<SourceChapter> { it.number ?: -1f }.thenByDescending { it.uploadDate ?: 0L })
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> {
        requireOwner(chapter)
        val doc = document(chapter.url)
        return parseImages(doc, listOf(".image_list canvas[data-src], .image_list img[src], .image_list img[data-src]", ".reading-content img"))
            .ifEmpty { throw IOException("لم يعثر القارئ على صور هذا الفصل") }
    }
}

/** Madara-based MangaLek. Chapters are fetched from the site's manga_get_chapters AJAX endpoint. */
class MangaLekSource : WebsiteScraper("site:mangalek", "مصدر مدمج 2", "ar", "https://mangalik.net") {
    override suspend fun popular(page: Int): List<SourceManga> = madaraList(page, "popular", "")
    override suspend fun latest(page: Int): List<SourceManga> = madaraList(page, "latest", "")
    override suspend fun search(query: String, page: Int): List<SourceManga> = madaraList(page, "search", query)

    private suspend fun madaraList(page: Int, mode: String, query: String): List<SourceManga> {
        val fields = mutableListOf(
            "action" to "madara_load_more", "page" to page.toString(),
            "template" to "madara-core/content/content-archive", "vars[paged]" to "1",
            "vars[template]" to "archive", "vars[posts_per_page]" to "25",
            "vars[post_type]" to "wp-manga", "vars[post_status]" to "publish",
            "vars[manga_archives_item_layout]" to "big_thumbnail",
        )
        when (mode) {
            "popular" -> fields += listOf("vars[orderby]" to "meta_value_num", "vars[meta_key]" to "_wp_manga_views", "vars[order]" to "DESC")
            "latest" -> fields += listOf("vars[orderby]" to "meta_value_num", "vars[meta_key]" to "_latest_update", "vars[order]" to "DESC")
            else -> if (query.isNotBlank()) fields += "vars[s]" to query
        }
        val doc = ajaxDocument("$baseUrl/wp-admin/admin-ajax.php", fields, "$baseUrl/manga/")
        return doc.select("div.page-item-detail, .manga__item, .c-tabs-item__content").mapNotNull { row ->
            val link = row.selectFirst(".post-title a[href], a[href]") ?: return@mapNotNull null
            val href = absolute(doc, link.attr("href")) ?: return@mapNotNull null
            val title = link.text().trim().ifBlank { link.attr("title") }
            if (title.isBlank()) return@mapNotNull null
            SourceManga(id, href, title, imageUrl(doc, row.selectFirst("img")))
        }
    }

    override suspend fun details(manga: SourceManga): SourceManga {
        requireOwner(manga)
        val doc = document(manga.url)
        return manga.copy(
            title = text(doc, listOf("div.post-title h3", "div.post-title h1", "#manga-title > h1", "h1")) ?: manga.title,
            coverUrl = imageUrl(doc, doc.selectFirst("div.summary_image img, .summary_image img")) ?: manga.coverUrl,
            description = text(doc, listOf("div.description-summary div.summary__content", "div.summary_content .post-content_item", ".summary__content")),
            status = text(doc, listOf(".post-content_item:contains(Status) .summary-content", ".summary-content")),
            author = text(doc, listOf("div.author-content a", "div.manga-authors a")),
            genres = doc.select("div.genres-content a, div.tags-content a").map { it.text().trim() }.filter(String::isNotBlank).distinct(),
        )
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> {
        requireOwner(manga)
        val details = document(manga.url)
        val id = details.selectFirst("[id^=manga-chapters-holder]")?.attr("data-id")
            ?: details.selectFirst("input.rating-post-id")?.attr("value")
            ?: details.selectFirst("a[data-post]")?.attr("data-post")
            ?: throw IOException("لم يستطع القارئ تحديد معرّف قائمة الفصول")
        val fragment = ajaxDocument(
            "$baseUrl/wp-admin/admin-ajax.php",
            listOf("action" to "manga_get_chapters", "manga" to id),
            manga.url,
        )
        return fragment.select("li.wp-manga-chapter, .wp-manga-chapter").mapNotNull { row ->
            if (row.hasClass("locked") || row.selectFirst(".locked, .chapter-locked") != null) return@mapNotNull null
            parseChapter(fragment, row, row.selectFirst("a[href]"))
        }.distinctBy { it.url }.sortedWith(compareByDescending<SourceChapter> { it.number ?: -1f }.thenByDescending { it.uploadDate ?: 0L })
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> {
        requireOwner(chapter)
        val doc = document(chapter.url)
        return parseImages(doc, listOf(".reading-content .page-break img, .reading-content img", "li.blocks-gallery-item img"))
            .ifEmpty { throw IOException("لا توجد صور متاحة لهذا الفصل") }
    }
}

/** Separate catalogue for the Mangalink section hosted under mangalik.net/mangalink/. */
class MangalinkSectionSource : WebsiteScraper("site:mangalink-section", "مصدر مدمج 3", "ar", "https://mangalik.net") {
    override suspend fun popular(page: Int): List<SourceManga> = listSection(page, "")
    override suspend fun latest(page: Int): List<SourceManga> = listSection(page, "")
    override suspend fun search(query: String, page: Int): List<SourceManga> = listSection(page, query)

    private suspend fun listSection(page: Int, query: String): List<SourceManga> {
        val url = "$baseUrl/mangalink/".toHttpUrl().newBuilder().apply {
            if (page > 0) addPathSegments("page/${page + 1}")
            if (query.isNotBlank()) addQueryParameter("s", query)
        }.build()
        val doc = document(url.toString())
        return doc.select(".listupd .bsx, .listupd .bs, .bsx, .page-item-detail, .manga__item").mapNotNull { card(doc, it, ".tt, h3, .post-title") }
    }

    override suspend fun details(manga: SourceManga): SourceManga {
        requireOwner(manga)
        val doc = document(manga.url)
        return manga.copy(
            title = text(doc, listOf("h1.entry-title", ".post-title h1", "h1")) ?: manga.title,
            coverUrl = imageUrl(doc, doc.selectFirst(".summary_image img, .thumb img, .seriestucont img")) ?: manga.coverUrl,
            description = text(doc, listOf(".description-summary", ".entry-content", ".desc")),
            status = text(doc, listOf(".summary-content:contains(مستمر)", ".summary-content")),
            genres = doc.select(".genres-content a, .mgen a, .seriestugenre a").map { it.text().trim() }.filter(String::isNotBlank).distinct(),
        )
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> {
        requireOwner(manga)
        val doc = document(manga.url)
        return doc.select("#chapterlist li, li.wp-manga-chapter, .eplister li, .chapter-list li, .chapters-list li, .chapter-item").mapNotNull { row ->
            if (row.hasClass("locked") || row.selectFirst(".locked") != null) return@mapNotNull null
            parseChapter(doc, row)
        }.distinctBy { it.url }.sortedWith(compareByDescending<SourceChapter> { it.number ?: -1f }.thenByDescending { it.uploadDate ?: 0L })
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> {
        requireOwner(chapter)
        val doc = document(chapter.url)
        val text = doc.text().lowercase()
        if (text.contains("your request was blocked") || text.contains("access denied") || text.contains("cloudflare")) {
            throw IOException("رفض الموقع الطلب قبل إتاحة صفحات الفصل؛ أعد المحاولة من جلسة المتصفح")
        }
        val pages = parseImages(doc, listOf(
            ".reading-content img, .page-break img, .reading-content img[data-src], .reading-content img[data-lazy-src]",
            "#readerarea img, #readerarea canvas[data-src]",
            ".chapter-content img, .chapter-content noscript img",
        ))
        if (pages.isNotEmpty()) return pages
        if (text.contains("verify") || text.contains("تحقق") || text.contains("captcha")) {
            throw IOException("يتطلب Hijala إكمال تحقق قبل إتاحة صور الفصل")
        }
        throw IOException("لم يعثر القارئ على صور صفحات الفصل")
    }
}

/** Lava Scans has a custom MangaThemesia layout and its own locked-chapter marker. */
class LavaScansSource : WebsiteScraper("site:lavascans", "مصدر مدمج 4", "ar", "https://lavascans.com") {
    override suspend fun popular(page: Int): List<SourceManga> = list(page, "", latestOrder = false)
    override suspend fun latest(page: Int): List<SourceManga> = list(page, "", latestOrder = true)
    override suspend fun search(query: String, page: Int): List<SourceManga> = list(page, query, latestOrder = false)

    private suspend fun list(page: Int, query: String, latestOrder: Boolean): List<SourceManga> {
        val builder = "$baseUrl/manga/".toHttpUrl().newBuilder()
        if (page > 0) builder.addQueryParameter("page", (page + 1).toString())
        if (query.isNotBlank()) builder.addQueryParameter("title", query)
        if (latestOrder) builder.addQueryParameter("order", "update")
        val doc = document(builder.build().toString())
        return doc.select(".listupd .manga-card-v, .listupd .bsx, .listupd .bs").mapNotNull { card(doc, it, ".bigor .tt, h3 a, .tt") }
    }

    override suspend fun details(manga: SourceManga): SourceManga {
        requireOwner(manga)
        val doc = document(manga.url)
        return manga.copy(
            title = text(doc, listOf(".lh-title", "h1")) ?: manga.title,
            coverUrl = imageUrl(doc, doc.selectFirst(".lh-poster img, .summary_image img")) ?: manga.coverUrl,
            description = text(doc, listOf("#manga-story", ".description-summary", ".entry-content")),
            status = text(doc, listOf(".status-badge-lux", ".summary-content")),
            genres = doc.select(".lh-genres a, .genres-content a").map { it.text().trim() }.filter(String::isNotBlank).distinct(),
        )
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> {
        requireOwner(manga)
        val doc = document(manga.url)
        val rows = doc.select("#chapters-list-container .ch-item")
        return rows.mapNotNull { row ->
            if (row.hasClass("locked") || row.selectFirst(".locked, [data-locked='true']") != null) return@mapNotNull null
            parseChapter(doc, row, row.selectFirst("a[href]"))?.let { chapter ->
                chapter.copy(
                    name = row.selectFirst(".ch-num")?.text()?.trim()?.ifBlank { null } ?: chapter.name,
                    uploadDate = parseDate(row.selectFirst(".ch-date")?.text()) ?: chapter.uploadDate,
                )
            }
        }.distinctBy { it.url }.sortedWith(compareByDescending<SourceChapter> { it.number ?: -1f }.thenByDescending { it.uploadDate ?: 0L })
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> {
        requireOwner(chapter)
        val doc = document(chapter.url)
        return parseImages(doc, listOf(".reading-content img, .chapter-content img", ".image_list img", ".reader-area img"))
            .ifEmpty { throw IOException("تعذر العثور على صور الفصل؛ قد يكون الفصل مقفلاً أو غير متاح") }
    }
}

/** Hijala uses a MangaThemesia page structure. The site may reject direct requests with HTTP 403. */
class HijalaSource : WebsiteScraper("site:hijala", "مصدر مدمج 5", "ar", "https://hijala.com") {
    override suspend fun popular(page: Int): List<SourceManga> = listing(page, "", latestOrder = false)
    override suspend fun latest(page: Int): List<SourceManga> = listing(page, "", latestOrder = true)
    override suspend fun search(query: String, page: Int): List<SourceManga> = listing(page, query, latestOrder = false)

    private suspend fun listing(page: Int, query: String, latestOrder: Boolean): List<SourceManga> {
        val builder = pagePath("/manga/", page).toHttpUrl().newBuilder()
        if (query.isNotBlank()) builder.addQueryParameter("title", query)
        if (latestOrder) builder.addQueryParameter("order", "update")
        val doc = document(builder.build().toString())
        return doc.select(".utao .uta .imgu, .listupd .bs .bsx, .listupd .bsx, .listupd .bs").mapNotNull { card(doc, it) }
    }

    override suspend fun details(manga: SourceManga): SourceManga {
        requireOwner(manga)
        val doc = document(manga.url)
        return manga.copy(
            title = text(doc, listOf(".entry-title", ".ts-breadcrumb li:last-child span", "h1")) ?: manga.title,
            coverUrl = imageUrl(doc, doc.selectFirst(".infomanga img, .thumb img, .summary_image img")) ?: manga.coverUrl,
            description = text(doc, listOf(".desc", ".entry-content[itemprop=description]", ".description-summary")),
            status = text(doc, listOf(".imptdt:contains(Status) i", ".summary-content")),
            genres = doc.select(".mgen a, .seriestugenre a, .gnr a").map { it.text().trim() }.filter(String::isNotBlank).distinct(),
        )
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> {
        requireOwner(manga)
        val doc = document(manga.url)
        return doc.select("#chapterlist li, .eplister ul li, li.wp-manga-chapter, .chapter-list li").mapNotNull { row ->
            if (row.hasClass("locked") || row.selectFirst(".locked") != null) return@mapNotNull null
            parseChapter(doc, row)
        }.distinctBy { it.url }.sortedWith(compareByDescending<SourceChapter> { it.number ?: -1f }.thenByDescending { it.uploadDate ?: 0L })
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> {
        requireOwner(chapter)
        val doc = document(chapter.url)
        return parseImages(doc, listOf("#readerarea img, .reading-content img", ".page-break img", ".chapter-content img"))
            .ifEmpty { throw IOException("لم يتمكن الموقع من إرجاع صفحات الفصل") }
    }
}

/** ProComic API reader. It reads public catalogue/series/chapter metadata, not protected reader sessions. */
class ProComicSource : WebsiteScraper("site:procomic", "مصدر مدمج 6", "ar", "https://procomic.pro") {
    private data class WorkKey(val type: String, val id: String, val slug: String)
    private data class ChapterKey(val id: String, val work: WorkKey, val number: String)

    private suspend fun <T> attemptOr(block: suspend () -> T, fallback: suspend () -> T): T = try {
        block()
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (_: Exception) {
        fallback()
    }

    private suspend fun <T> attemptOrNull(block: suspend () -> T): T? = try {
        block()
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (_: Exception) {
        null
    }

    override suspend fun popular(page: Int): List<SourceManga> =
        attemptOr({ listContent(page, "popular", "") }, { listSeriesHtml("/ar/series", page, "") })

    override suspend fun latest(page: Int): List<SourceManga> =
        attemptOr({ listContent(page, "latest_chapter", "") }, { listSeriesHtml("/ar/updates", page, "") })

    override suspend fun search(query: String, page: Int): List<SourceManga> {
        if (query.isBlank()) return emptyList()
        // The current public catalogue exposes search through /api/public/content?search=...
        // (the older /api/public/series/search route is not part of the published API).
        return attemptOr(
            { listContent(page, "popular", query) },
            { listSeriesHtml("/ar/series", page, query) },
        )
    }

    private fun encode(key: WorkKey): String = "${key.type}~${key.id}~${key.slug}"
    private fun decodeWork(value: String): WorkKey? {
        val parts = value.split('~', limit = 3)
        if (parts.size != 3 || parts.any(String::isBlank)) return null
        return WorkKey(parts[0], parts[1], parts[2])
    }

    private fun encodeChapter(key: ChapterKey): String =
        "${key.id}~${key.work.type}~${key.work.id}~${key.work.slug}~${key.number}"

    private fun decodeChapter(value: String): ChapterKey? {
        val parts = value.split('~', limit = 5)
        if (parts.size != 5 || parts.any(String::isBlank)) return null
        return ChapterKey(parts[0], WorkKey(parts[1], parts[2], parts[3]), parts[4])
    }

    private fun string(obj: JsonObject?, key: String): String? {
        val value = obj?.get(key)?.takeUnless { it.isJsonNull } ?: return null
        return runCatching { value.asString }.getOrNull()?.takeIf(String::isNotBlank)
    }

    private fun stringOrArray(obj: JsonObject?, key: String): String? {
        val value = obj?.get(key)?.takeUnless { it.isJsonNull } ?: return null
        return when {
            value.isJsonArray -> value.asJsonArray.mapNotNull { runCatching { it.asString }.getOrNull() }.filter(String::isNotBlank).joinToString(", ").ifBlank { null }
            else -> runCatching { value.asString }.getOrNull()?.takeIf(String::isNotBlank)
        }
    }

    private fun cover(row: JsonObject): String? {
        val metadata = row.getAsJsonObject("metadata")
        val raw = string(row, "coverImage") ?: string(metadata, "coverImage") ?: string(row, "thumbnail") ?: return null
        if (!raw.startsWith('/')) return raw
        val cdnLabel = string(row, "cdn_path") ?: return "$baseUrl$raw"
        val host = "$cdnLabel.${baseUrl.toHttpUrl().host}"
        return runCatching { HttpUrl.Builder().scheme("https").host(host).encodedPath(raw).build().toString() }.getOrNull()
    }

    private fun workFromJson(row: JsonObject): SourceManga? {
        val id = string(row, "id") ?: return null
        val type = string(row, "type") ?: return null
        if (type == "novel" || row.get("isBlockedSeries")?.let { runCatching { it.asBoolean }.getOrDefault(false) } == true) return null
        val slug = string(row, "slug") ?: return null
        val title = string(row, "title") ?: return null
        return SourceManga(sourceId = this.id, url = encode(WorkKey(type, id, slug)), title = title, coverUrl = cover(row))
    }


    private suspend fun listSeriesHtml(path: String, page: Int, query: String): List<SourceManga> {
        val url = "$baseUrl$path".toHttpUrl().newBuilder().apply {
            if (page > 0) addQueryParameter("page", (page + 1).toString())
            if (query.isNotBlank()) addQueryParameter("search", query)
        }.build()
        val doc = document(url.toString(), "$baseUrl/ar/series")
        return doc.select("a[href*='/ar/series/']").mapNotNull { anchor ->
            runCatching {
                val href = absolute(doc, anchor.attr("href")) ?: return@runCatching null
                val parts = href.toHttpUrl().pathSegments
                val seriesIndex = parts.indexOf("series")
                if (seriesIndex < 0 || parts.size <= seriesIndex + 3) return@runCatching null
                val type = parts[seriesIndex + 1]
                val id = parts[seriesIndex + 2]
                val slug = parts[seriesIndex + 3]
                if (type == "novel" || id.isBlank() || slug.isBlank()) return@runCatching null
                val image = anchor.selectFirst("img") ?: anchor.parent()?.selectFirst("img")
                val title = anchor.text().trim().ifBlank { anchor.attr("title") }
                    .ifBlank { image?.attr("alt").orEmpty() }
                if (title.isBlank()) return@runCatching null
                SourceManga(sourceId = this.id, url = encode(WorkKey(type, id, slug)), title = title, coverUrl = imageUrl(doc, image))
            }.getOrNull()
        }.distinctBy { it.url }
    }

    private suspend fun listContent(page: Int, sort: String, query: String): List<SourceManga> {
        val url = "$baseUrl/api/public/content".toHttpUrl().newBuilder()
            .addQueryParameter("sort", sort)
            .addQueryParameter("limit", "12")
            .addQueryParameter("page", (page + 1).toString())
            .apply { if (query.isNotBlank()) addQueryParameter("search", query.trim()) }
            .build()
        val root = json(url.toString())
        return root.getAsJsonArray("data")?.mapNotNull { item ->
            runCatching { workFromJson(item.asJsonObject) }.getOrNull()
        }.orEmpty()
    }

    private suspend fun json(url: String): JsonObject = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/json")
            .header("X-Requested-With", "XMLHttpRequest")
            .header("Referer", "$baseUrl/ar/series")
            .build()
        executeWebsiteRequest(request).use { response ->
            if (!response.isSuccessful) {
                val code = response.code
                throw IOException(if (code == 403) "يتطلب هذا الطلب تحقق الوصول الخاص بالموقع (HTTP 403)" else "HTTP $code")
            }
            val raw = response.body?.string().orEmpty()
            if (raw.isBlank()) throw IOException("استجابة API فارغة")
            JsonParser.parseString(raw).asJsonObject
        }
    }

    override suspend fun details(manga: SourceManga): SourceManga {
        requireOwner(manga)
        val key = decodeWork(manga.url) ?: throw IOException("بيانات العمل غير صالحة؛ أعد تحميل النتائج")
        val root = attemptOrNull { json("$baseUrl/api/public/content/${key.id}") }
        if (root != null) {
            val content = if (root.has("data") && root.get("data").isJsonObject) root.getAsJsonObject("data") else root
            return parseDetails(content, manga)
        }
        val doc = document("$baseUrl/ar/series/${key.type}/${key.id}/${key.slug}")
        return manga.copy(
            title = text(doc, listOf("h1", ".series-title")) ?: manga.title,
            coverUrl = imageUrl(doc, doc.selectFirst(".series-cover img, .cover img, img")) ?: manga.coverUrl,
            description = text(doc, listOf(".series-description", ".description", "main p")),
            genres = doc.select(".genres a, a[href*='/genre/']").map { it.text().trim() }.filter(String::isNotBlank).distinct(),
        )
    }

    private fun parseDetails(row: JsonObject, fallback: SourceManga): SourceManga {
        val metadata = row.getAsJsonObject("metadata")
        val genres = buildList {
            row.getAsJsonArray("genres")?.forEach { item ->
                runCatching { item.asJsonObject.get("name")?.asString }.getOrNull()?.let(::add)
            }
            metadata?.getAsJsonArray("genres")?.forEach { item ->
                runCatching { item.asString }.getOrNull()?.let(::add)
            }
            metadata?.getAsJsonArray("tags")?.forEach { item ->
                runCatching { item.asString }.getOrNull()?.let(::add)
            }
        }.filter(String::isNotBlank).distinct()
        val altTitles = buildList {
            string(metadata, "originalTitle")?.let(::add)
            metadata?.getAsJsonArray("altTitles")?.forEach { item -> runCatching { item.asString }.getOrNull()?.let(::add) }
        }.distinct()
        val description = buildString {
            string(row, "description")?.let { append(it.trim()) }
            if (altTitles.isNotEmpty()) {
                if (isNotEmpty()) append("\n\n")
                append("عناوين بديلة: ")
                append(altTitles.joinToString("، "))
            }
        }.ifBlank { fallback.description }
        return fallback.copy(
            title = string(row, "title") ?: fallback.title,
            coverUrl = cover(row) ?: fallback.coverUrl,
            description = description,
            status = string(row, "progress") ?: fallback.status,
            genres = genres.ifEmpty { fallback.genres },
            author = stringOrArray(metadata, "author") ?: fallback.author,
        )
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> {
        requireOwner(manga)
        val key = decodeWork(manga.url) ?: throw IOException("بيانات العمل غير صالحة؛ أعد تحميل النتائج")
        val endpoint = "$baseUrl/api/public/${key.type}/${key.id}/chapters".toHttpUrl().newBuilder()
            .addQueryParameter("limit", "100")
            .addQueryParameter("order", "desc")
            .build()
        val firstUrl = endpoint.newBuilder().addQueryParameter("page", "1").build().toString()
        val first = attemptOrNull { json(firstUrl) }
        if (first == null) {
            val doc = document("$baseUrl/ar/series/${key.type}/${key.id}/${key.slug}")
            return doc.select("a[href*='/ar/chapter/']").mapNotNull { anchor ->
                val row = anchor.parent() ?: anchor
                val words = (anchor.text() + " " + row.text()).lowercase()
                if (words.contains("مقفل") || words.contains("مدفوع") || words.contains("premium") || words.contains("coins")) return@mapNotNull null
                val href = absolute(doc, anchor.attr("href")) ?: return@mapNotNull null
                val title = anchor.text().trim().ifBlank { "فصل" }
                val number = Regex("""(?i)(?:chapter|الفصل|ch\.?|episode)?\s*([0-9]+(?:\.[0-9]+)?)""").find(title)?.groupValues?.getOrNull(1)?.toFloatOrNull()
                val chapterId = Regex("""-(\d+)$""").find(href.substringBefore('?'))?.groupValues?.getOrNull(1) ?: href.substringAfterLast('/')
                SourceChapter(this.id, encodeChapter(ChapterKey(chapterId, key, number?.toString() ?: "0")), title, number, parseDate(row.text()), "ar", href)
            }.distinctBy { it.url }
        }
        val total = first.get("total")?.let { runCatching { it.asInt }.getOrDefault(0) } ?: 0
        val pageCount = ((total + 99) / 100).coerceIn(1, 20)
        val pages = if (pageCount > 1) coroutineScope {
            (2..pageCount).map { page ->
                async { json(endpoint.newBuilder().addQueryParameter("page", page.toString()).build().toString()) }
            }.awaitAll()
        } else emptyList()
        return (listOf(first) + pages).asSequence()
            .flatMap { it.getAsJsonArray("data")?.asSequence().orEmpty() }
            .mapNotNull { item -> runCatching {
                val row = item.asJsonObject
                if (string(row, "language") != "AR") return@runCatching null
                val id = string(row, "id") ?: return@runCatching null
                val number = string(row, "chapter_number") ?: return@runCatching null
                val locked = listOf("lockedForever", "lockedByCoins", "lockedByShortlink", "lockedByExclusive")
                    .any { field -> row.get(field)?.let { runCatching { it.asBoolean }.getOrDefault(false) } == true }
                if (locked) return@runCatching null
                val title = string(row, "title")
                val name = buildString {
                    append("الفصل ", number)
                    title?.takeIf { it != number }?.let { append(" - ", it) }
                }
                SourceChapter(
                    sourceId = this.id,
                    url = encodeChapter(ChapterKey(id, key, number)),
                    name = name,
                    number = number.toFloatOrNull(),
                    uploadDate = parseDate(string(row, "published_at")),
                    language = "ar",
                    externalUrl = "${baseUrl}/ar/chapter/${key.slug}-${number}-${id}",
                )
            }.getOrNull() }
            .toList()
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> {
        requireOwner(chapter)
        val key = decodeChapter(chapter.url) ?: throw IOException("معرّف الفصل غير صالح")
        val chapterUrl = "${baseUrl}/ar/chapter/${key.work.slug}-${key.number}-${key.id}"
        val doc = document(chapterUrl)
        val text = doc.text().lowercase()
        if (text.contains("مقفل") || text.contains("coins") || text.contains("shortlink") || text.contains("exclusive")) {
            throw IOException("هذا الفصل يتطلب فتحاً من الموقع ولا يمكن قراءته مجاناً")
        }
        val pages = parseImages(doc, listOf(".chapter-pages img, .reading-content img, .reader img", "img[data-page]", "img[src*='.procomic.im']"))
        if (pages.isNotEmpty()) return pages
        if (text.contains("تحقق") || text.contains("security") || text.contains("challenge") || text.contains("captcha")) {
            throw IOException("يتطلب الموقع إكمال تحقق أمني قبل إتاحة صفحات هذا الفصل")
        }
        throw IOException("لم يعثر القارئ على صور صفحات الفصل")
    }
}

/** MeshManga's public catalogue API. Reading is only enabled when the public page API returns images. */
class MeshMangaSource : WebsiteScraper("site:meshmanga", "مصدر مدمج 7", "ar", "https://meshmanga.com") {
    private val api = "$baseUrl/v2/api/v2"

    override suspend fun popular(page: Int): List<SourceManga> = listApi("$api/series/?order_by=-followers_count&page=${page + 1}")
    override suspend fun latest(page: Int): List<SourceManga> = listApi("$api/series/releases/?page=${page + 1}")
    override suspend fun search(query: String, page: Int): List<SourceManga> {
        val url = "$api/series/".toHttpUrl().newBuilder().addQueryParameter("search", query).addQueryParameter("page", (page + 1).toString()).build()
        return listApi(url.toString())
    }

    private suspend fun json(url: String): JsonObject = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url).header("User-Agent", USER_AGENT).header("Accept", "application/json").header("Referer", "$baseUrl/").build()
        executeWebsiteRequest(request).use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            val raw = response.body?.string().orEmpty()
            if (raw.isBlank()) throw IOException("استجابة API فارغة")
            JsonParser.parseString(raw).asJsonObject
        }
    }

    private suspend fun listApi(url: String): List<SourceManga> {
        val root = json(url)
        return root.getAsJsonArray("results")?.mapNotNull { item ->
            runCatching {
                val row = item.asJsonObject
                val id = row.get("id")?.asString ?: row.get("serie_id")?.asString ?: return@runCatching null
                val title = row.get("title")?.asString?.takeIf(String::isNotBlank) ?: return@runCatching null
                val poster = row.getAsJsonObject("poster")?.get("medium")?.asString
                SourceManga(this.id, id, title, poster)
            }.getOrNull()
        }.orEmpty()
    }

    override suspend fun details(manga: SourceManga): SourceManga {
        requireOwner(manga)
        val root = json("$api/series/${manga.url}/")
        val poster = root.getAsJsonObject("poster")?.get("medium")?.asString
        val genres = root.getAsJsonArray("genres")?.mapNotNull { runCatching { it.asJsonObject.get("name")?.asString }.getOrNull() }.orEmpty()
        return manga.copy(
            title = root.get("title")?.asString ?: manga.title,
            coverUrl = poster ?: manga.coverUrl,
            description = root.get("story")?.asString,
            genres = genres,
            author = root.getAsJsonObject("author")?.get("name")?.asString,
            status = root.getAsJsonObject("status")?.get("name")?.asString,
        )
    }

    override suspend fun chapters(manga: SourceManga): List<SourceChapter> {
        requireOwner(manga)
        val url = "$api/chapters/".toHttpUrl().newBuilder()
            .addQueryParameter("serie", manga.url).addQueryParameter("order_by", "-order").addQueryParameter("page_size", "200").build().toString()
        val rows = mutableListOf<SourceChapter>()
        var next: String? = url
        var pageCount = 0
        while (next != null && pageCount++ < 20) {
            val root = json(next)
            root.getAsJsonArray("results")?.forEach { item ->
                runCatching {
                    val row = item.asJsonObject
                    val id = row.get("id")?.asString ?: return@runCatching
                    val slug = row.get("slug")?.asString.orEmpty()
                    val number = row.get("chapter")?.asString.orEmpty()
                    val date = row.get("created_at")?.asString
                    val chapterUrl = "$baseUrl/chapters/$id/$slug/"
                    rows += SourceChapter(this.id, chapterUrl, "الفصل $number", number.toFloatOrNull(), parseDate(date), "ar")
                }
            }
            next = root.get("next")?.takeIf { !it.isJsonNull }?.asString
        }
        return rows
    }

    override suspend fun pages(chapter: SourceChapter): List<SourcePage> {
        requireOwner(chapter)
        val id = Regex("/chapters/(\\d+)").find(chapter.url)?.groupValues?.getOrNull(1)
            ?: throw IOException("معرّف الفصل غير صالح")
        val root = json("$api/chapters/$id/")
        val images = root.getAsJsonArray("images")?.mapNotNull { runCatching { it.asJsonObject.get("image")?.asString }.getOrNull() }.orEmpty()
        if (images.isEmpty()) throw IOException("الموقع لا يوفّر صور الفصل عبر واجهته العامة حالياً؛ القراءة متاحة من تطبيقه الرسمي")
        return images.mapIndexed { index, url -> SourcePage(index, url, "$baseUrl/") }
    }
}

/** Creates the fixed built-in set. The providers remain private implementation details in the UI. */
fun createBuiltInWebsiteSources(): List<MangaSource> = listOf(
    TeamXSource(),
    MangaLekSource(),
    MangalinkSectionSource(),
    ProComicSource(),
    MeshMangaSource(),
    LavaScansSource(),
    HijalaSource(),
)
