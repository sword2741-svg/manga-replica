package com.example.mangareplica.data.sources

/** Registry for first-party adapters; extension adapters will implement the same contract. */
class NativeSourceRegistry(sources: List<MangaSource> = listOf(MangaDexSource()) + createBuiltInWebsiteSources()) {
    private val nativeById = sources.associateBy { it.id }
    @Volatile private var extensionById: Map<String, MangaSource> = emptyMap()

    fun replaceExtensions(sources: List<MangaSource>) {
        extensionById = sources.associateBy { it.id }
    }

    fun all(): List<MangaSource> = (nativeById.values + extensionById.values).sortedBy { it.name.lowercase() }
    fun get(id: String): MangaSource? = extensionById[id] ?: nativeById[id]
    fun find(id: String): MangaSource? = get(id)
}
