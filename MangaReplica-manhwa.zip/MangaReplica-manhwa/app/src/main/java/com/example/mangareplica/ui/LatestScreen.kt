@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.mangareplica

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.mangareplica.data.feed.CachedFeed
import com.example.mangareplica.data.feed.CachedWork
import com.example.mangareplica.data.feed.FeedCache
import com.example.mangareplica.data.feed.toGroups
import com.example.mangareplica.data.persistence.ReadingProgressEntity
import com.example.mangareplica.data.preferences.AppSettings
import com.example.mangareplica.data.sources.FederatedSourceRepository
import com.example.mangareplica.data.sources.MangaGroup
import com.example.mangareplica.data.sources.MangaSource
import com.example.mangareplica.data.sources.NativeSourceRegistry
import com.example.mangareplica.data.sources.SourceManga
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.Calendar

private const val LATEST_CACHE_KEY = "latest-v1"
private const val DAY_MILLIS = 24L * 60L * 60L * 1000L

internal data class LatestInfo(
    val chapterName: String?,
    val chapterUrl: String?,
    val chapterNumber: Float?,
    val publishedAt: Long?,
)

private data class LatestItem(val group: MangaGroup, val info: LatestInfo?)

/**
 * Best-effort work type. Extensions rarely expose it in list results, so unknown stays null and only
 * appears under "الكل".
 */
internal fun inferWorkType(manga: SourceManga): String? {
    val language = manga.originalLanguage?.lowercase().orEmpty()
    val text = manga.genres.joinToString(" ").lowercase()
    return when {
        language.startsWith("zh") || "manhua" in text || "صيني" in text -> "manhua"
        language == "ko" || "manhwa" in text || "مانهوا" in text -> "manhwa"
        language == "ja" || "manga" in text || "مانجا" in text || "مانغا" in text -> "manga"
        else -> null
    }
}

private fun mergeGroups(previous: List<MangaGroup>, next: List<MangaGroup>): List<MangaGroup> {
    val merged = LinkedHashMap<String, MangaGroup>()
    (previous + next).forEach { group ->
        val old = merged[group.normalizedTitle]
        if (old == null) merged[group.normalizedTitle] = group
        else merged[group.normalizedTitle] = old.copy(sources = (old.sources + group.sources).distinctBy { it.source.id to it.manga.url })
    }
    return merged.values.toList()
}

private fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

@Composable
fun LatestScreen(
    federated: FederatedSourceRepository,
    registry: NativeSourceRegistry,
    sources: List<MangaSource>,
    settings: AppSettings,
    progress: List<ReadingProgressEntity>,
    online: Boolean,
    cache: FeedCache,
    onTypeFilterChange: (String) -> Unit,
    onBack: () -> Unit,
    onOpenGroup: (MangaGroup) -> Unit,
    onAddToLibrary: (MangaGroup) -> Unit,
    onDownloadLatest: (MangaGroup) -> Unit,
) {
    var refreshToken by remember { mutableIntStateOf(0) }
    var pageNumber by remember { mutableIntStateOf(0) }
    var groups by remember { mutableStateOf<List<MangaGroup>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var endReached by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var fromCache by remember { mutableStateOf(false) }
    val infoMap = remember { mutableStateMapOf<String, LatestInfo>() }
    val semaphore = remember { Semaphore(4) }

    var sortMode by rememberSaveable { mutableStateOf("latest") }
        var languageFilter by rememberSaveable { mutableStateOf("all") }
    var hideRead by rememberSaveable { mutableStateOf(false) }
    var showSheet by remember { mutableStateOf(false) }
    val typeFilter = settings.latestTypeFilter
    val sourceIdsKey = sources.map { it.id }.sorted().joinToString(",")

    // 1) Show the last cached feed immediately (also what is shown offline).
    LaunchedEffect(sourceIdsKey) {
        if (groups.isEmpty()) {
            val saved = cache.read(LATEST_CACHE_KEY, CachedFeed::class.java)
            if (saved != null && saved.works.isNotEmpty()) {
                val restored = saved.works.toGroups(registry)
                if (restored.isNotEmpty()) {
                    groups = restored
                    saved.works.forEach { work ->
                        if (work.chapterName != null || work.publishedAt != null) {
                            infoMap[FederatedSourceRepository.normalizeTitle(work.title)] =
                                LatestInfo(work.chapterName, work.chapterUrl, work.chapterNumber, work.publishedAt)
                        }
                    }
                    fromCache = true
                }
            }
        }
    }

    // 2) Fetch from every enabled source in parallel, page after page.
    LaunchedEffect(pageNumber, refreshToken, sourceIdsKey, online, settings.downloadOnly) {
        if (settings.downloadOnly || !online) {
            loading = false
            return@LaunchedEffect
        }
        if (sources.isEmpty()) {
            error = "تعذّر جلب أحدث الأعمال حاليًا. تحقق من الاتصال ثم أعد المحاولة."
            return@LaunchedEffect
        }
        loading = true
        error = null
        try {
            val page = federated.latest(pageNumber, sources.map { it.id }.toSet())
            if (pageNumber == 0) {
                // Never replace a cached feed with an empty result (every source failed).
                if (page.groups.isNotEmpty()) {
                    groups = page.groups
                    fromCache = false
                }
                endReached = page.groups.isEmpty()
            } else {
                val merged = mergeGroups(groups, page.groups)
                endReached = merged.size == groups.size
                groups = merged
            }
            if (groups.isEmpty() && page.failures.isNotEmpty()) {
                error = "تعذّر الاتصال بمواقع القراءة حاليًا. تحقق من الاتصال ثم أعد المحاولة."
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (failure: Exception) {
            error = failure.message ?: "تعذر تحميل أحدث الأعمال"
        } finally {
            loading = false
        }
    }

    // 3) Persist the visible feed (with chapter info) so it survives offline launches.
    LaunchedEffect(infoMap.size, groups.size, fromCache) {
        if (fromCache || groups.isEmpty()) return@LaunchedEffect
        delay(1200)
        val works = groups.take(120).flatMap { group ->
            val info = infoMap[group.normalizedTitle]
            group.sources.map { ref ->
                CachedWork(
                    sourceId = ref.source.id, url = ref.manga.url, title = ref.manga.title, coverUrl = ref.manga.coverUrl,
                    description = ref.manga.description, status = ref.manga.status,
                    chapterName = info?.chapterName, chapterUrl = info?.chapterUrl,
                    chapterNumber = info?.chapterNumber, publishedAt = info?.publishedAt,
                )
            }
        }
        cache.write(LATEST_CACHE_KEY, CachedFeed(System.currentTimeMillis(), works))
    }

    val now = remember(refreshToken, groups.size, infoMap.size) { System.currentTimeMillis() }
    val dayStart = remember(refreshToken, groups.size) { startOfToday() }
    val allItems = groups.map { LatestItem(it, infoMap[it.normalizedTitle]) }
    val openedKeys = remember(progress) { progress.map { it.sourceId to it.mangaUrl }.toSet() }
    val readChapterUrls = remember(progress) { progress.filter { it.isComplete }.map { it.chapterUrl }.toSet() }

    val visible = allItems.filter { item ->
        val group = item.group
        val publishedAt = item.info?.publishedAt ?: 0L
        (typeFilter == "all" || inferWorkType(group.preferred.manga) == typeFilter) &&
            (languageFilter == "all" || group.sources.any { it.source.language.equals(languageFilter, ignoreCase = true) }) &&
            !(hideRead && item.info?.chapterUrl != null && item.info.chapterUrl in readChapterUrls) &&
            when (sortMode) {
                "today" -> publishedAt >= dayStart
                "week" -> publishedAt >= now - 7 * DAY_MILLIS
                else -> true
            }
    }.sortedByDescending { it.info?.publishedAt ?: Long.MIN_VALUE }
    val todayCount = allItems.count { (it.info?.publishedAt ?: 0L) >= dayStart }
    val languages = sources.map { it.language.lowercase() }.distinct().sorted()

    val gridState = rememberLazyGridState()
    LaunchedEffect(gridState, visible.size, endReached, online) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }.collect { last ->
            if (visible.isNotEmpty() && last >= visible.size - 4 && !loading && !endReached && online && groups.isNotEmpty()) {
                pageNumber += 1
            }
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
            Text("أحدث الأعمال", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            IconButton(onClick = { showSheet = true }) { Icon(Icons.Default.FilterList, "تصفية") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("all" to "الكل", "manhwa" to "مانهوا", "manga" to "مانغا", "manhua" to "مانهوا صينية").forEach { (key, label) ->
                AppPill(label, typeFilter == key) { onTypeFilterChange(key) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("latest" to "الأحدث", "today" to "اليوم", "week" to "هذا الأسبوع").forEach { (key, label) ->
                AppPill(label, sortMode == key) { sortMode = key }
            }
        }
        Text(
            if (infoMap.isEmpty() && loading) "جارٍ التحديث…" else "$todayCount عملاً تحدّث اليوم",
            Modifier.padding(vertical = 8.dp),
            color = AppMuted,
            style = MaterialTheme.typography.bodyMedium,
        )
        if (!online) AppOfflineBanner(if (groups.isEmpty()) "أنت غير متصل ولا توجد نتائج محفوظة بعد" else "أنت غير متصل · تُعرض آخر نتائج محفوظة")
        if (settings.downloadOnly) AppOfflineBanner("وضع التنزيل فقط مفعّل؛ لا تُجلب نتائج جديدة")

        PullToRefreshBox(
            isRefreshing = loading && pageNumber == 0 && groups.isNotEmpty(),
            onRefresh = {
                if (online && !settings.downloadOnly) {
                    pageNumber = 0
                    endReached = false
                    refreshToken += 1
                }
            },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) {
            when {
                loading && groups.isEmpty() -> LatestSkeleton()
                error != null && groups.isEmpty() -> AppEmptyState("تعذر إكمال الطلب", error.orEmpty(), "إعادة المحاولة") {
                    pageNumber = 0; refreshToken += 1
                }
                visible.isEmpty() -> AppEmptyState(
                    "لا توجد أعمال لعرضها",
                    if (groups.isEmpty()) "ستظهر أحدث الأعمال عند توفر الاتصال." else "غيّر المرشّحات أو النطاق الزمني لعرض أعمال أخرى.",
                )
                else -> LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    state = gridState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(visible, key = { it.group.normalizedTitle }) { item ->
                        LatestCard(
                            item = item,
                            now = now,
                            opened = item.group.sources.any { (it.source.id to it.manga.url) in openedKeys },
                            online = online,
                            onLoadInfo = {
                                val key = item.group.normalizedTitle
                                if (online && infoMap[key] == null) {
                                    semaphore.withPermit {
                                        if (infoMap[key] == null) {
                                            runCatching {
                                                val match = item.group.sources.firstNotNullOfOrNull { ref ->
                                                    val chapters = runCatching { ref.source.chapters(ref.manga) }.getOrNull().orEmpty()
                                                    val newest = chapters.maxByOrNull { it.uploadDate ?: 0L } ?: chapters.firstOrNull()
                                                    newest?.let { ref to it }
                                                }
                                                match?.second?.let { newest ->
                                                    infoMap[key] = LatestInfo(newest.name, newest.url, newest.number, newest.uploadDate)
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                            onOpen = { onOpenGroup(item.group) },
                            onAddToLibrary = { onAddToLibrary(item.group) },
                            onDownloadLatest = { onDownloadLatest(item.group) },
                        )
                    }
                }
            }
        }
    }

    if (showSheet) {
        var draftType by remember { mutableStateOf(typeFilter) }
        var draftLanguage by remember { mutableStateOf(languageFilter) }
        var draftHideRead by remember { mutableStateOf(hideRead) }
        ModalBottomSheet(onDismissRequest = { showSheet = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تصفية أحدث الأعمال", style = MaterialTheme.typography.titleLarge)
                Text("النوع", color = AppMuted)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("all" to "الكل", "manhwa" to "مانهوا", "manga" to "مانغا", "manhua" to "مانهوا صينية").forEach { (key, label) ->
                        AppPill(label, draftType == key) { draftType = key }
                    }
                }
                Text("اللغة", color = AppMuted)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppPill("الكل", draftLanguage == "all") { draftLanguage = "all" }
                    languages.forEach { code ->
                        AppPill(
                            when (code) { "ar" -> "العربية"; "en" -> "الإنجليزية"; else -> code.uppercase() },
                            draftLanguage == code,
                        ) { draftLanguage = code }
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("إخفاء ما قرأته")
                    Switch(draftHideRead, { draftHideRead = it }, colors = SwitchDefaults.colors(checkedThumbColor = AppCoral))
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            onTypeFilterChange(draftType)
                            languageFilter = draftLanguage
                            hideRead = draftHideRead
                            showSheet = false
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = AppCoral, contentColor = Color(0xFF1A0A06)),
                    ) { Text("تطبيق") }
                    OutlinedButton(
                        onClick = {
                            draftType = "all"; draftLanguage = "all"; draftHideRead = false
                            onTypeFilterChange("all"); languageFilter = "all"; hideRead = false
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text("إعادة ضبط") }
                }
            }
        }
    }
}

@Composable
private fun LatestSkeleton() {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(6) {
            Box(Modifier.fillMaxWidth().aspectRatio(0.72f).clip(RoundedCornerShape(16.dp)).background(Color(0xFF1B1F2A)))
        }
    }
}

@Composable
private fun LatestCard(
    item: LatestItem,
    now: Long,
    opened: Boolean,
    online: Boolean,
    onLoadInfo: suspend () -> Unit,
    onOpen: () -> Unit,
    onAddToLibrary: () -> Unit,
    onDownloadLatest: () -> Unit,
) {
    val group = item.group
    val info = item.info
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(group.normalizedTitle, online) { onLoadInfo() }
    val isNew = info?.publishedAt != null && now - info.publishedAt in 0..DAY_MILLIS && !opened
    val chapterLabel = when {
        info?.chapterNumber != null && info.chapterNumber >= 0f ->
            "الفصل ${com.example.mangareplica.data.sources.ChapterGrouping.formatNumber(info.chapterNumber)}"
        !info?.chapterName.isNullOrBlank() -> info?.chapterName
        else -> null
    }
    Box {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .clip(RoundedCornerShape(16.dp))
                .background(AppPanel)
                .combinedClickable(onClick = onOpen, onLongClick = { menu = true }),
        ) {
            group.preferred.manga.coverUrl?.takeIf { it.isNotBlank() }?.let {
                AsyncImage(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(120.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE0B0D12)))),
            )
            if (isNew) {
                Text(
                    "جديد",
                    Modifier.align(Alignment.TopStart).padding(8.dp).clip(RoundedCornerShape(8.dp)).background(AppCoral).padding(horizontal = 8.dp, vertical = 3.dp),
                    color = Color(0xFF1A0A06), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                )
            }
            Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(group.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (chapterLabel != null) {
                        Text(
                            chapterLabel,
                            Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0x33FFFFFF)).padding(horizontal = 7.dp, vertical = 2.dp),
                            color = Color.White, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    val ago = timeAgoArabic(info?.publishedAt, now)
                    if (ago.isNotEmpty()) Text(ago, color = Color(0xFFD8D2CA), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("أضف للمكتبة") }, onClick = { menu = false; onAddToLibrary() })
            DropdownMenuItem(text = { Text(if (online) "نزّل آخر فصل" else "نزّل آخر فصل (يحتاج اتصالاً)") }, enabled = online, onClick = { menu = false; onDownloadLatest() })
        }
    }
}
