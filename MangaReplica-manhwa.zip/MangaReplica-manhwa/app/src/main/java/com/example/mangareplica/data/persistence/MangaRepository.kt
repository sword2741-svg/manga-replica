package com.example.mangareplica.data.persistence

import kotlinx.coroutines.flow.Flow

/**
 * Coroutine/Compose-facing persistence API. Collect exposed flows with collectAsStateWithLifecycle;
 * call suspend writes from a coroutine (for example, a ViewModel scope), never from the UI thread.
 */
class MangaRepository(database: MangaDatabase) {
    private val library = database.libraryDao()
    private val progress = database.readingProgressDao()
    private val downloads = database.chapterDownloadDao()
    private val searches = database.searchHistoryDao()
    private val categories = database.mangaCategoryDao()
    private val stats = database.readingStatsDao()

    fun observeLibrary(): Flow<List<LibraryMangaEntity>> = library.observeAll()
    fun observeManga(sourceId: String, mangaUrl: String): Flow<LibraryMangaEntity?> = library.observe(sourceId, mangaUrl)
    fun observeFavorites(): Flow<List<LibraryMangaEntity>> = library.observeFavorites()
    fun observeCategory(categoryId: String): Flow<List<LibraryMangaEntity>> = library.observeCategory(categoryId)
    suspend fun saveManga(manga: LibraryMangaEntity) = library.upsert(manga)
    suspend fun saveManga(manga: List<LibraryMangaEntity>) = library.upsertAll(manga)
    suspend fun replaceLibrary(manga: List<LibraryMangaEntity>) = library.replaceAll(manga)
    suspend fun removeManga(sourceId: String, mangaUrl: String) = library.delete(sourceId, mangaUrl)

    fun observeProgress(sourceId: String, mangaUrl: String): Flow<List<ReadingProgressEntity>> =
        progress.observeForManga(sourceId, mangaUrl)
    fun observeAllProgress(): Flow<List<ReadingProgressEntity>> = progress.observeAll()
    fun observeProgress(sourceId: String, mangaUrl: String, chapterUrl: String): Flow<ReadingProgressEntity?> =
        progress.observe(sourceId, mangaUrl, chapterUrl)
    suspend fun saveProgress(entry: ReadingProgressEntity) = progress.upsert(entry)
    suspend fun removeProgress(sourceId: String, mangaUrl: String, chapterUrl: String) =
        progress.delete(sourceId, mangaUrl, chapterUrl)
    suspend fun clearProgress(sourceId: String, mangaUrl: String) = progress.deleteForManga(sourceId, mangaUrl)

    fun observeDownloads(): Flow<List<ChapterDownloadEntity>> = downloads.observeAll()
    fun observeDownloads(sourceId: String, mangaUrl: String): Flow<List<ChapterDownloadEntity>> =
        downloads.observeForManga(sourceId, mangaUrl)
    suspend fun saveDownload(entry: ChapterDownloadEntity) = downloads.upsert(entry)
    suspend fun removeDownload(sourceId: String, mangaUrl: String, chapterUrl: String) =
        downloads.delete(sourceId, mangaUrl, chapterUrl)
    suspend fun clearDownloads(sourceId: String, mangaUrl: String) = downloads.deleteForManga(sourceId, mangaUrl)

    fun observeRecentSearches(limit: Int = 50): Flow<List<SearchHistoryEntity>> = searches.observeRecent(limit)
    suspend fun recordSearch(query: String, searchedAt: Long = System.currentTimeMillis()) {
        val normalized = query.trim()
        if (normalized.isNotEmpty()) searches.insert(SearchHistoryEntity(query = normalized, searchedAt = searchedAt))
    }
    suspend fun removeSearch(id: Long) = searches.delete(id)
    suspend fun clearSearchHistory() = searches.clear()

    fun observeCategories(): Flow<List<MangaCategoryEntity>> = categories.observeAll()
    suspend fun saveCategory(category: MangaCategoryEntity) = categories.upsert(category)
    suspend fun removeCategory(id: String) = categories.delete(id)

    fun observeReadingStats(): Flow<List<ReadingDayStatEntity>> = stats.observeAll()
    suspend fun addReadingSeconds(day: Long, seconds: Int) {
        if (seconds > 0) stats.add(day, seconds)
    }
    /** Merges restored statistics, keeping the larger value per day so a restore never loses time. */
    suspend fun mergeReadingStats(restored: List<ReadingDayStatEntity>) {
        if (restored.isEmpty()) return
        val current = stats.getAll().associateBy { it.day }
        stats.upsertAll(restored.filter { it.seconds > 0 }.map { r ->
            val existing = current[r.day]
            if (existing != null && existing.seconds >= r.seconds) existing else r
        })
    }
}
