package com.example.mangareplica

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.room.Room
import com.example.mangareplica.data.extensions.ExtensionApkInstaller
import com.example.mangareplica.data.extensions.ExtensionCatalog
import com.example.mangareplica.data.extensions.ExtensionEntry
import com.example.mangareplica.data.extensions.InstalledExtension
import com.example.mangareplica.data.extensions.InstalledExtensionRegistry
import com.example.mangareplica.data.extensions.ExtensionStoreRepository
import com.example.mangareplica.data.persistence.ChapterDownloadEntity
import com.example.mangareplica.data.persistence.ChapterDownloadService
import com.example.mangareplica.data.persistence.LibraryMangaEntity
import com.example.mangareplica.data.persistence.MangaDatabase
import com.example.mangareplica.data.persistence.MangaRepository
import com.example.mangareplica.data.persistence.MangaCategoryEntity
import com.example.mangareplica.data.persistence.ReadingProgressEntity
import com.example.mangareplica.data.preferences.AppSettings
import com.example.mangareplica.data.preferences.AppSettingsRepository
import com.example.mangareplica.data.sources.FederatedPage
import com.example.mangareplica.data.sources.FederatedSourceRepository
import com.example.mangareplica.data.sources.MangaDexSource
import com.example.mangareplica.data.sources.createBuiltInWebsiteSources
import com.example.mangareplica.data.sources.MangaGroup
import com.example.mangareplica.data.sources.NativeSourceRegistry
import com.example.mangareplica.data.sources.SourceChapter
import com.example.mangareplica.data.sources.SourceManga
import com.example.mangareplica.data.sources.SourceMangaRef
import com.example.mangareplica.ui.MangaReplicaTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.Job
import androidx.compose.ui.platform.LocalWindowInfo
import com.example.mangareplica.data.feed.CachedDetail
import com.example.mangareplica.data.feed.FeedCache
import com.example.mangareplica.data.feed.HomeCache
import com.example.mangareplica.data.persistence.MIGRATION_1_2
import com.example.mangareplica.data.persistence.MIGRATION_2_3
import com.example.mangareplica.data.profile.ProfileStatsCalculator
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MangaReplicaApp() }
    }
}

enum class AppScreen {
    HOME, EXPLORE, SEARCH, LIBRARY, DOWNLOADS, MORE, DETAILS, READER,
    EXTENSIONS, APPEARANCE, LIBRARY_SETTINGS, TRACKING, PRIVACY, ADVANCED, ABOUT, LATEST, PROFILE
}

private data class ChapterUpdate(
    val ref: SourceMangaRef,
    val chapter: SourceChapter,
    val publishedAt: Long
)

@Composable
private fun MangaReplicaApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val database = remember(context) {
        Room.databaseBuilder(context.applicationContext, MangaDatabase::class.java, "mangareplica.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
            .build()
    }
    val store = remember(database) { MangaRepository(database) }
    val settingsStore = remember(context) { AppSettingsRepository(context.applicationContext) }
    val settings by settingsStore.settings.collectAsState(initial = AppSettings())
    val library by store.observeLibrary().collectAsState(initial = emptyList())
    val progress by store.observeAllProgress().collectAsState(initial = emptyList())
    val downloads by store.observeDownloads().collectAsState(initial = emptyList())
    val categories by store.observeCategories().collectAsState(initial = emptyList())
    val recentSearches by store.observeRecentSearches().collectAsState(initial = emptyList())
    val readingStats by store.observeReadingStats().collectAsState(initial = emptyList())
    val online by rememberOnlineState()
    val feedCache = remember(context) { FeedCache(context.applicationContext) }
    val downloadJobs = remember { mutableMapOf<String, Job>() }
    var activeDownloads by remember { mutableStateOf(setOf<String>()) }
    var homeFromCache by remember { mutableStateOf(false) }

    val registry = remember(settings.hideAdultContent) {
        NativeSourceRegistry(listOf(MangaDexSource(includeAdultContent = !settings.hideAdultContent)) + createBuiltInWebsiteSources())
    }
    val federated = remember(registry, settings.hideAdultContent) {
        FederatedSourceRepository(registry, includeAdultContent = !settings.hideAdultContent)
    }
    val extensionStore = remember { ExtensionStoreRepository() }
    val apkInstaller = remember(context) { ExtensionApkInstaller(context.applicationContext) }
    val installedExtensionRegistry = remember(context) { InstalledExtensionRegistry(context.applicationContext) }

    val stack = remember { mutableStateListOf(AppScreen.HOME) }
    var selectedTab by rememberSaveable { mutableStateOf(AppScreen.HOME) }
    val screen = stack.lastOrNull() ?: AppScreen.HOME
    var scrollTopToken by rememberSaveable { mutableIntStateOf(0) }
    var homeRefreshToken by rememberSaveable { mutableIntStateOf(0) }
    var homeLoading by remember { mutableStateOf(false) }
    var homePopular by remember { mutableStateOf(FederatedPage(emptyList(), emptyList())) }
    var homeLatest by remember { mutableStateOf(FederatedPage(emptyList(), emptyList())) }
    var homeError by remember { mutableStateOf<String?>(null) }

    var query by rememberSaveable { mutableStateOf("") }
    var searchSourceId by rememberSaveable { mutableStateOf("all") }
    var searchPageNumber by rememberSaveable { mutableIntStateOf(0) }
    var searchLoading by remember { mutableStateOf(false) }
    var searchResult by remember { mutableStateOf(FederatedPage(emptyList(), emptyList())) }
    var searchError by remember { mutableStateOf<String?>(null) }

    var explorePageNumber by rememberSaveable { mutableIntStateOf(0) }
    var exploreSort by rememberSaveable { mutableStateOf("popular") }
    var exploreLoading by remember { mutableStateOf(false) }
    var exploreResult by remember { mutableStateOf(FederatedPage(emptyList(), emptyList())) }
    var exploreGenre by rememberSaveable { mutableStateOf("") }

    var selectedGroup by remember { mutableStateOf<MangaGroup?>(null) }
    var detailRef by remember { mutableStateOf<SourceMangaRef?>(null) }
    var detailData by remember { mutableStateOf<SourceManga?>(null) }
    var detailChapters by remember { mutableStateOf<List<SourceChapter>>(emptyList()) }
    var detailLoading by remember { mutableStateOf(false) }
    var detailError by remember { mutableStateOf<String?>(null) }
    var downloadedWorkMode by remember { mutableStateOf(false) }

    var readerRef by remember { mutableStateOf<SourceMangaRef?>(null) }
    var readerChapters by remember { mutableStateOf<List<SourceChapter>>(emptyList()) }
    var readerChapter by remember { mutableStateOf<SourceChapter?>(null) }

    var extensionCatalog by remember { mutableStateOf<ExtensionCatalog?>(null) }
    var installedExtensions by remember { mutableStateOf<List<InstalledExtension>>(emptyList()) }
    var extensionLoading by remember { mutableStateOf(false) }
    var extensionError by remember { mutableStateOf<String?>(null) }
    var extensionInstallMessage by remember { mutableStateOf<String?>(null) }
    var extensionLoadToken by rememberSaveable { mutableIntStateOf(0) }
    var extensionUrlOverride by remember { mutableStateOf<String?>(null) }
    val extensionRepositoryUrl = extensionUrlOverride ?: settings.extensionRepositoryIndexUrl
    LaunchedEffect(settings.extensionRepositoryIndexUrl) { extensionUrlOverride = null }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) extensionLoadToken++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    suspend fun refreshMihonSources() {
        try {
            val packages = withContext(Dispatchers.IO) { installedExtensionRegistry.all() }
            installedExtensions = packages
            registry.replaceExtensions(packages.flatMap { it.sources })
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            Log.e("MihonRuntime", "stage=APKDetection error=${error.javaClass.name}")
            extensionError = "تعذر تحديث قائمة إضافات Mihon (${error.javaClass.simpleName})"
        }
    }

    // The shipped website readers are first-party adapters and are available without installing extensions.
    LaunchedEffect(Unit) {
        settingsStore.update { if (it.profileJoinedAt == 0L) it.copy(profileJoinedAt = System.currentTimeMillis()) else it }
    }
    val windowInfo = LocalWindowInfo.current
    LaunchedEffect(screen, settings.incognitoMode) {
        if (screen != AppScreen.READER || settings.incognitoMode) return@LaunchedEffect
        while (true) {
            delay(15_000)
            if (windowInfo.isWindowFocused) store.addReadingSeconds(ProfileStatsCalculator.today(), 15)
        }
    }

    val activity = context as? ComponentActivity
    DisposableEffect(activity, screen, settings.keepScreenOn, settings.fullscreen) {
        val window = activity?.window
        val insetsController = window?.let { WindowInsetsControllerCompat(it, it.decorView) }
        val reading = screen == AppScreen.READER
        if (window != null) {
            if (reading && settings.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (reading && settings.fullscreen) insetsController?.hide(WindowInsetsCompat.Type.systemBars())
            else insetsController?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (window != null) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                insetsController?.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    fun navigate(destination: AppScreen) {
        if (destination in ROOT_SCREENS) {
            selectedTab = destination
            stack.clear()
            stack.add(destination)
        } else stack.add(destination)
    }
    fun back() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex) else navigate(AppScreen.HOME)
    }
    fun openGroup(group: MangaGroup) {
        selectedGroup = group
        detailRef = group.preferred
        detailData = group.preferred.manga
        detailChapters = emptyList()
        downloadedWorkMode = false
        navigate(AppScreen.DETAILS)
    }
    fun openDownloadedWork(ref: SourceMangaRef?, manga: SourceManga, chapters: List<SourceChapter>) {
        selectedGroup = ref?.let {
            MangaGroup(FederatedSourceRepository.normalizeTitle(manga.title), manga.title, listOf(it))
        }
        detailRef = ref
        detailData = manga
        detailChapters = chapters
        detailLoading = false
        detailError = null
        downloadedWorkMode = true
        navigate(AppScreen.DETAILS)
    }
    fun openChapter(ref: SourceMangaRef, chapter: SourceChapter, chapters: List<SourceChapter>) {
        readerRef = ref
        readerChapter = chapter
        readerChapters = chapters
        navigate(AppScreen.READER)
    }

    fun toast(message: String) = android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()

    fun startDownload(ref: SourceMangaRef, chapter: SourceChapter) {
        val key = com.example.mangareplica.downloadKey(ref.source.id, ref.manga.url, chapter.url)
        if (key in downloadJobs) return
        if (!online) { toast("التنزيل يحتاج اتصالاً بالإنترنت"); return }
        val job = scope.launch {
            try {
                store.saveManga(LibraryMangaEntity(ref.source.id, ref.manga.url, ref.manga.title, ref.manga.coverUrl, ref.manga.description, ref.manga.status))
                downloadChapter(context, ref, chapter, store)
            } finally {
                downloadJobs.remove(key)
                activeDownloads = activeDownloads - key
            }
        }
        downloadJobs[key] = job
        activeDownloads = activeDownloads + key
    }
    fun cancelDownload(ref: SourceMangaRef, chapter: SourceChapter) {
        downloadJobs[com.example.mangareplica.downloadKey(ref.source.id, ref.manga.url, chapter.url)]?.cancel()
    }
    fun deleteDownload(ref: SourceMangaRef, chapter: SourceChapter) {
        scope.launch {
            val record = downloads.firstOrNull { it.sourceId == ref.source.id && it.mangaUrl == ref.manga.url && it.chapterUrl == chapter.url }
            withContext(Dispatchers.IO) { record?.localPath?.takeIf { it.isNotBlank() }?.let { runCatching { File(it).deleteRecursively() } } }
            store.removeDownload(ref.source.id, ref.manga.url, chapter.url)
        }
    }
    fun markChapters(ref: SourceMangaRef, chapters: List<SourceChapter>, read: Boolean) {
        scope.launch {
            chapters.forEach { chapter ->
                if (read) store.saveProgress(ReadingProgressEntity(ref.source.id, ref.manga.url, chapter.url, Int.MAX_VALUE, isComplete = true))
                else store.removeProgress(ref.source.id, ref.manga.url, chapter.url)
            }
        }
    }
    fun openLibraryItem(item: LibraryMangaEntity) {
        val source = registry.find(item.sourceId)
        if (source != null) {
            val manga = SourceManga(sourceId = item.sourceId, url = item.mangaUrl, title = item.title, coverUrl = item.coverUrl, description = item.description, status = item.status)
            openGroup(MangaGroup(FederatedSourceRepository.normalizeTitle(item.title), item.title, listOf(SourceMangaRef(source, manga))))
        } else toast("هذا العمل محفوظ من مصدر قديم غير متاح في الإصدار الحالي")
    }
    fun downloadNewestChapter(group: MangaGroup) {
        val ref = group.preferred
        scope.launch {
            runCatching { ref.source.chapters(ref.manga) }.onSuccess { chapters ->
                val newest = chapters.maxByOrNull { it.uploadDate ?: 0L } ?: chapters.firstOrNull()
                if (newest != null) startDownload(ref, newest) else toast("لا توجد فصول لهذا العمل")
            }.onFailure { toast("تعذر جلب الفصول: ${it.message ?: "خطأ غير معروف"}") }
        }
    }
    suspend fun saveAvatar(uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "profile").apply { mkdirs() }
            val dest = File(dir, "avatar-${System.currentTimeMillis()}.img")
            val input = context.contentResolver.openInputStream(uri) ?: return@runCatching null
            input.use { source -> dest.outputStream().use { out -> source.copyTo(out) } }
            dir.listFiles()?.filter { it != dest }?.forEach { it.delete() }
            dest.absolutePath
        }.getOrNull()
    }

    BackHandler(enabled = stack.size > 1 || screen != AppScreen.HOME) { back() }

    LaunchedEffect(screen, homeRefreshToken, settings.homeSourceFilter, settings.downloadOnly, settings.hideAdultContent, online) {
        if (screen != AppScreen.HOME) return@LaunchedEffect
        if (settings.downloadOnly) {
            homePopular = FederatedPage(emptyList(), emptyList())
            homeLatest = FederatedPage(emptyList(), emptyList())
            homeError = null
            return@LaunchedEffect
        }
        if (!online) {
            val cached = withContext(Dispatchers.IO) { HomeCache.load(feedCache, registry) }
            if (cached != null) {
                homePopular = FederatedPage(cached.first, emptyList())
                homeLatest = FederatedPage(cached.second, emptyList())
                homeFromCache = true
                homeError = null
                return@LaunchedEffect
            }
        }
        homeLoading = true
        homeError = null
        val enabledIds = registry.all().filter { it.isBuiltIn || settings.isSourceEnabled(it.id) }.map { it.id }.toSet()
        val filter = enabledIds
        try {
            val popularTask = async { federated.popular(0, filter) }
            val latestTask = async { federated.latest(0, filter) }
            val results = awaitAll(popularTask, latestTask)
            homePopular = results[0]
            homeLatest = results[1]
            val failures = (homePopular.failures + homeLatest.failures).distinctBy { it.sourceId }
            if (homePopular.groups.isNotEmpty() || homeLatest.groups.isNotEmpty()) {
                homeFromCache = false
                withContext(Dispatchers.IO) { HomeCache.save(feedCache, homePopular.groups, homeLatest.groups) }
            } else {
                val cached = withContext(Dispatchers.IO) { HomeCache.load(feedCache, registry) }
                if (cached != null) {
                    homePopular = FederatedPage(cached.first, emptyList())
                    homeLatest = FederatedPage(cached.second, emptyList())
                    homeFromCache = true
                }
            }
            homeError = if (homePopular.groups.isEmpty() && homeLatest.groups.isEmpty() && failures.isNotEmpty()) {
                "تعذّر الاتصال بمواقع القراءة حاليًا. تحقق من الاتصال ثم أعد المحاولة."
            } else null
        } catch (error: Exception) {
            homeError = error.message ?: "تعذر تحديث الصفحة"
        } finally {
            homeLoading = false
        }
    }

    LaunchedEffect(screen, query, searchSourceId, searchPageNumber, settings.downloadOnly, settings.incognitoMode) {
        if (screen != AppScreen.SEARCH || query.isBlank()) return@LaunchedEffect
        if (settings.downloadOnly) {
            searchError = "وضع التنزيل فقط مفعّل؛ البحث الشبكي متوقف"
            return@LaunchedEffect
        }
        delay(350)
        searchLoading = true
        searchError = null
        try {
            val enabledIds = registry.all().filter { it.isBuiltIn || settings.isSourceEnabled(it.id) }.map { it.id }.toSet()
            val filter = enabledIds
            val result = federated.search(query, searchPageNumber, filter)
            searchResult = if (searchPageNumber == 0) result else mergeFederatedPages(searchResult, result)
            searchError = result.failures.takeIf { it.isNotEmpty() }?.let {
                if (result.groups.isEmpty()) "تعذّر الاتصال ببعض مواقع القراءة. تحقق من الاتصال وأعد المحاولة."
                else "تم عرض النتائج المتاحة؛ تعذّر جلب نتائج إضافية من بعض المواقع."
            }
            if (!settings.incognitoMode && searchPageNumber == 0) store.recordSearch(query)
        } catch (error: Exception) {
            searchError = error.message ?: "تعذر البحث"
        } finally {
            searchLoading = false
        }
    }

    LaunchedEffect(screen, explorePageNumber, exploreSort, settings.downloadOnly) {
        if (screen != AppScreen.EXPLORE) return@LaunchedEffect
        if (settings.downloadOnly) {
            exploreResult = FederatedPage(emptyList(), emptyList())
            return@LaunchedEffect
        }
        exploreLoading = true
        try {
            val enabledIds = registry.all().filter { it.isBuiltIn || settings.isSourceEnabled(it.id) }.map { it.id }.toSet()
            val page = if (exploreSort == "latest") federated.latest(explorePageNumber, enabledIds) else federated.popular(explorePageNumber, enabledIds)
            exploreResult = if (explorePageNumber == 0) page else mergeFederatedPages(exploreResult, page)
        } catch (_: Exception) {
            // A provider failure is represented in the result while other providers remain visible.
        } finally {
            exploreLoading = false
        }
    }

    LaunchedEffect(screen, selectedGroup?.normalizedTitle, downloadedWorkMode) {
        if (screen != AppScreen.DETAILS) return@LaunchedEffect
        if (downloadedWorkMode) {
            val ref = detailRef
            if (ref != null) {
                val key = "detail|${ref.source.id}|${ref.manga.url}"
                val cached = withContext(Dispatchers.IO) { feedCache.read(key, CachedDetail::class.java) }
                cached?.manga?.let { detailData = it }
                if (online && !settings.downloadOnly) {
                    detailLoading = true
                    try {
                        withTimeoutOrNull(6_500L) { ref.source.details(cached?.manga ?: ref.manga) }
                            ?.let { details ->
                                detailData = details
                                withContext(Dispatchers.IO) {
                                    feedCache.write(key, CachedDetail(details, cached?.chapters.orEmpty(), System.currentTimeMillis()))
                                }
                            }
                    } catch (cancelled: kotlinx.coroutines.CancellationException) {
                        throw cancelled
                    } catch (_: Exception) {
                        // Keep the downloaded work and its local chapters usable if details are unavailable.
                    }
                }
            }
            detailLoading = false
            return@LaunchedEffect
        }
        val initialRef = detailRef ?: return@LaunchedEffect
        val candidates = (selectedGroup?.sources ?: listOf(initialRef))
            .distinctBy { it.source.id to it.manga.url }
        detailLoading = true
        detailError = null

        data class CandidateResult(
            val ref: SourceMangaRef,
            val manga: SourceManga,
            val chapters: List<SourceChapter>,
        )

        try {
            val results = kotlinx.coroutines.coroutineScope {
                candidates.map { candidate ->
                    async {
                        val key = "detail|${candidate.source.id}|${candidate.manga.url}"
                        val cached = withContext(Dispatchers.IO) { feedCache.read(key, CachedDetail::class.java) }
                        if (!online && cached?.manga != null && cached.chapters.isNotEmpty()) {
                            return@async CandidateResult(candidate, cached.manga, cached.chapters)
                        }
                        try {
                            withTimeoutOrNull(6_500L) {
                                val details = candidate.source.details(candidate.manga)
                                val chapters = candidate.source.chapters(details)
                                withContext(Dispatchers.IO) {
                                    feedCache.write(key, CachedDetail(details, chapters, System.currentTimeMillis()))
                                }
                                CandidateResult(candidate, details, chapters)
                            }
                        } catch (cancelled: kotlinx.coroutines.CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            null
                        }
                    }
                }.awaitAll()
            }
            val chosen = results.filterNotNull().firstOrNull { it.chapters.isNotEmpty() }
                ?: results.filterNotNull().firstOrNull()
            if (chosen != null) {
                detailRef = chosen.ref
                detailData = chosen.manga
                detailChapters = chosen.chapters
                if (chosen.chapters.isEmpty()) {
                    detailError = "لم تُرجع المواقع فصولاً متاحة لهذا العمل حالياً."
                }
            } else {
                detailChapters = emptyList()
                detailError = if (online) "تعذّر تحميل تفاصيل العمل أو فصوله من المواقع المتاحة." else "لا توجد نسخة محفوظة لهذا العمل. اتصل بالإنترنت ثم أعد المحاولة."
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } finally {
            detailLoading = false
        }
    }

    LaunchedEffect(screen, extensionLoadToken, extensionRepositoryUrl) {
        if (screen != AppScreen.EXTENSIONS) return@LaunchedEffect
        if (extensionCatalog != null || extensionLoading) return@LaunchedEffect
        extensionLoading = true
        extensionError = null
        try {
            extensionStore.refresh(extensionRepositoryUrl).onSuccess { extensionCatalog = it }
                .onFailure { extensionError = it.message ?: "تعذر تحميل مستودع الإضافات" }
        } finally {
            extensionLoading = false
        }
    }

    MangaReplicaTheme(settings) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.fillMaxSize()) {
            when (screen) {
                AppScreen.HOME -> HomeScreen(
                    popular = homePopular.groups,
                    latest = homeLatest.groups,
                    continueItems = library.filter { item -> progress.any { it.sourceId == item.sourceId && it.mangaUrl == item.mangaUrl && !it.isComplete } },
                    sources = emptyList(),
                    sourceFilter = "all",
                    settings = settings,
                    loading = homeLoading,
                    error = homeError,
                    scrollToken = scrollTopToken,

                    onSearch = { query = ""; searchPageNumber = 0; searchResult = FederatedPage(emptyList(), emptyList()); navigate(AppScreen.SEARCH) },
                    onDownloads = { navigate(AppScreen.DOWNLOADS) },
                    onSourceFilter = { },
                    onRefresh = { homeRefreshToken++ },
                    onOpenGroup = ::openGroup,
                    onOpenContinue = { item ->
                        val source = registry.find(item.sourceId)
                        if (source != null) {
                            val ref = SourceMangaRef(source, SourceManga(sourceId = item.sourceId, url = item.mangaUrl, title = item.title, coverUrl = item.coverUrl, description = item.description, status = item.status))
                            scope.launch {
                                runCatching { source.chapters(ref.manga) }.onSuccess { chapters ->
                                    val saved = progress.filter { it.sourceId == item.sourceId && it.mangaUrl == item.mangaUrl && !it.isComplete }.maxByOrNull { it.updatedAt }
                                    val chapter = chapters.find { it.url == saved?.chapterUrl } ?: chapters.firstOrNull()
                                    if (chapter != null) openChapter(ref, chapter, chapters)
                                }
                            }
                        }
                    },
                    onAddToLibrary = { group -> addToLibrary(group.preferred, store, library, scope) },
                    onExploreGenre = { genre -> exploreGenre = genre; navigate(AppScreen.EXPLORE) },
                    onShowAll = { navigate(AppScreen.EXPLORE) },
                    onOpenExtensions = { },
                    onOpenProfile = { navigate(AppScreen.PROFILE) },
                    onOpenLatest = { navigate(AppScreen.LATEST) },
                    offline = !online && homeFromCache
                )
                AppScreen.SEARCH -> SearchScreen(
                    query = query,
                    onQueryChange = { query = it; searchPageNumber = 0; searchResult = FederatedPage(emptyList(), emptyList()) },
                    result = searchResult,
                    sources = emptyList(),
                    sourceId = searchSourceId,
                    onSourceChange = { },
                    history = if (settings.incognitoMode) emptyList() else recentSearches,
                    loading = searchLoading,
                    error = searchError,
                    onOpen = ::openGroup,
                    onHistorySelect = { query = it; searchPageNumber = 0 },
                    onDeleteHistory = { search -> scope.launch { store.removeSearch(search.id) } },
                    onClearHistory = { scope.launch { store.clearSearchHistory() } },
                    onMore = { searchPageNumber++ },
                    onBack = ::back,
                    onOpenExtensions = { }
                )
                AppScreen.EXPLORE -> ExploreScreen(
                    result = exploreResult,
                    loading = exploreLoading,
                    sort = exploreSort,
                    onSort = { exploreSort = it; explorePageNumber = 0; exploreResult = FederatedPage(emptyList(), emptyList()) },
                    genre = exploreGenre,
                    onGenre = { exploreGenre = it },
                    onOpen = ::openGroup,
                    onMore = { explorePageNumber++ },
                    scrollToken = scrollTopToken,
                    onOpenExtensions = { }
                )
                AppScreen.LIBRARY -> LibraryScreen(
                    items = library,
                    progress = progress,
                    downloads = downloads,
                    categories = categories,
                    onOpen = { item ->
                        val source = registry.find(item.sourceId)
                        if (source != null) {
                            val manga = SourceManga(sourceId = item.sourceId, url = item.mangaUrl, title = item.title, coverUrl = item.coverUrl, description = item.description, status = item.status)
                            openGroup(MangaGroup(FederatedSourceRepository.normalizeTitle(item.title), item.title, listOf(SourceMangaRef(source, manga))))
                        } else toast("هذا العمل محفوظ من مصدر قديم غير متاح في الإصدار الحالي")
                    },
                    onRemove = { item -> scope.launch { store.removeManga(item.sourceId, item.mangaUrl) } },
                    onToggleFavorite = { item -> scope.launch { store.saveManga(item.copy(isFavorite = !item.isFavorite, updatedAt = System.currentTimeMillis())) } },
                    onMarkRead = { item -> scope.launch { store.saveManga(item.copy(isRead = true, updatedAt = System.currentTimeMillis())) } },
                    onOpenDownloads = { navigate(AppScreen.DOWNLOADS) },
                    scrollToken = scrollTopToken
                )
                AppScreen.DOWNLOADS -> DownloadsScreen(
                    downloads = downloads,
                    library = library,
                    registry = registry,
                    onOpen = ::openDownloadedWork,
                    onDeleteAll = { sourceId, mangaUrl ->
                        scope.launch {
                            downloads.filter { it.sourceId == sourceId && it.mangaUrl == mangaUrl }
                                .forEach { record -> withContext(Dispatchers.IO) { record.localPath?.let { runCatching { File(it).deleteRecursively() } } } }
                            store.clearDownloads(sourceId, mangaUrl)
                        }
                    },
                )
                AppScreen.MORE -> MoreScreen(
                    settings = settings,
                    onSetting = { destination -> navigate(destination) },
                    onExtensions = { },
                    onIncognito = { scope.launch { settingsStore.setIncognitoMode(it) } },
                    onDownloadOnly = { scope.launch { settingsStore.setDownloadOnly(it) } },
                    onAbout = { navigate(AppScreen.ABOUT) },
                    onOpenProfile = { navigate(AppScreen.PROFILE) }
                )
                AppScreen.DETAILS -> DetailScreen(
                    group = selectedGroup,
                    selectedRef = detailRef,
                    details = detailData,
                    chapters = detailChapters,
                    loading = detailLoading,
                    error = detailError,
                    library = library,
                    progress = progress,
                    downloads = downloads,
                    activeDownloads = activeDownloads,
                    online = online,
                    onBack = ::back,
                    onOpenChapter = { chapter -> detailRef?.let { openChapter(it, chapter, detailChapters) } },
                    onToggleLibrary = { ref -> toggleLibrary(ref, store, library, scope, detailData?.takeIf { it.url == ref.manga.url }?.genres.orEmpty()) },
                    onMarkChapters = { chapters, read -> detailRef?.let { markChapters(it, chapters, read) } },
                    onDownloadChapters = { chapters -> detailRef?.let { ref -> chapters.forEach { startDownload(ref, it) } } },
                    onCancelDownload = { chapter -> detailRef?.let { cancelDownload(it, chapter) } },
                    onDeleteDownload = { chapter -> detailRef?.let { deleteDownload(it, chapter) } }
                )
                AppScreen.READER -> ReaderScreen(
                    ref = readerRef,
                    chapter = readerChapter,
                    chapters = readerChapters,
                    settings = settings,
                    progress = progress,
                    downloads = downloads,
                    repository = store,
                    onBack = ::back,
                    onSettings = { },
                    onChapterChange = { chapter -> readerChapter = chapter },
                    onProgress = { chapter, page, complete, pageCount ->
                        val ref = readerRef
                        if (ref != null && !settings.incognitoMode) {
                            scope.launch {
                                store.saveProgress(ReadingProgressEntity(ref.source.id, ref.manga.url, chapter.url, page, complete, pageCount = pageCount))
                                val existing = library.firstOrNull { it.sourceId == ref.source.id && it.mangaUrl == ref.manga.url }
                                val genreText = detailData?.takeIf { it.url == ref.manga.url }?.genres?.joinToString(",")?.ifBlank { null }
                                store.saveManga(existing?.copy(updatedAt = System.currentTimeMillis(), genres = existing.genres ?: genreText) ?: LibraryMangaEntity(
                                    ref.source.id, ref.manga.url, ref.manga.title, ref.manga.coverUrl, ref.manga.description, ref.manga.status, genres = genreText
                                ))
                            }
                        }
                    },
                    onOpenSettings = { },
                    onUpdateSettings = { updated -> scope.launch { settingsStore.update { updated } } },
                    activeDownloads = activeDownloads,
                    online = online,
                    onDownloadChapter = { chapter -> readerRef?.let { startDownload(it, chapter) } },
                    onCancelDownload = { chapter -> readerRef?.let { cancelDownload(it, chapter) } },
                    onDeleteDownload = { chapter -> readerRef?.let { deleteDownload(it, chapter) } }
                )
                AppScreen.LATEST -> LatestScreen(
                    federated = federated,
                    registry = registry,
                    sources = emptyList(),
                    settings = settings,
                    progress = progress,
                    online = online,
                    cache = feedCache,
                    onTypeFilterChange = { value -> scope.launch { settingsStore.update { it.copy(latestTypeFilter = value) } } },
                    onBack = ::back,
                    onOpenGroup = ::openGroup,
                    onAddToLibrary = { group -> addToLibrary(group.preferred, store, library, scope) },
                    onDownloadLatest = ::downloadNewestChapter
                )
                AppScreen.PROFILE -> ProfileScreen(
                    settings = settings,
                    library = library,
                    progress = progress,
                    stats = readingStats,
                    comments = emptyList(),
                    account = null,
                    onBack = ::back,
                    onOpenWork = ::openLibraryItem,
                    onOpenComment = { },
                    onSaveProfile = { name, bio, avatarUri ->
                        scope.launch {
                            val path = avatarUri?.let { saveAvatar(it) }
                            settingsStore.update { it.copy(profileName = name, profileBio = bio, profileAvatarPath = path ?: it.profileAvatarPath) }
                        }
                    },
                    onShare = { text ->
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                        runCatching { context.startActivity(Intent.createChooser(send, "مشاركة الملف الشخصي")) }
                    },
                    onOpenSettings = { navigate(AppScreen.MORE) },
                    onOpenBackup = { navigate(AppScreen.LIBRARY_SETTINGS) }
                )
                AppScreen.EXTENSIONS -> ExtensionsScreen(
                    catalog = extensionCatalog,
                    installedExtensions = installedExtensions,
                    sources = registry.all(),
                    loading = extensionLoading,
                    error = extensionError,
                    installMessage = extensionInstallMessage,
                    settings = settings,
                    onBack = ::back,
                    onRefresh = { extensionCatalog = null; extensionError = null; extensionLoadToken++ },
                    onRefreshInstalled = { scope.launch { refreshMihonSources() } },
                    onTrustInstalled = { packageName ->
                        scope.launch {
                            runCatching {
                                withContext(Dispatchers.IO) { installedExtensionRegistry.trustAndLoad(packageName) }
                            }.onSuccess { packages ->
                                installedExtensions = packages
                                registry.replaceExtensions(packages.flatMap { it.sources })
                            }.onFailure { extensionInstallMessage = it.message ?: "تعذر تحميل الإضافة" }
                        }
                    },
                    onRepositoryChange = { value ->
                        val url = value.trim()
                        val valid = url.startsWith("https://", ignoreCase = true) && url.substringBefore('?').trimEnd('/').endsWith("/index.pb", ignoreCase = true)
                        if (valid) {
                            extensionUrlOverride = url
                            extensionCatalog = null
                            extensionError = null
                            extensionLoadToken++
                            scope.launch { settingsStore.update { it.copy(extensionRepositoryIndexUrl = url) } }
                        } else {
                            extensionCatalog = null
                            extensionLoading = false
                            extensionError = "أدخل رابط HTTPS ينتهي بـ /index.pb"
                        }
                    },
                    onFilterAdult = { scope.launch { settingsStore.setHideAdultContent(it) } },
                    onSourceToggle = { id, enabled -> scope.launch { settingsStore.setSourceEnabled(id, enabled, registry.all().map { it.id }.toSet()) } },
                    onInstalledPackageDetails = { packageName ->
                        val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                        runCatching { context.startActivity(intent) }
                    },
                    onInstall = { entry ->
                        scope.launch {
                            val fingerprint = extensionCatalog?.metadata?.signingKeyFingerprint.orEmpty()
                            val result = runCatching { apkInstaller.downloadAndVerify(entry, fingerprint) }
                            result.onSuccess { verified ->
                                extensionInstallMessage = "تم فحص التوقيع والحزمة. سيطلب Android موافقتك النهائية على التثبيت."
                                if (apkInstaller.openInstallPermissionSettings()) {
                                    extensionInstallMessage = "امنح إذن التثبيت لهذا التطبيق من إعدادات Android، ثم عُد واضغط تثبيت مرة أخرى."
                                } else apkInstaller.launchSystemInstaller(verified)
                            }.onFailure { extensionInstallMessage = it.message ?: "فشل التحقق من الإضافة" }
                        }
                    }
                )
                AppScreen.APPEARANCE -> AppearanceScreen(
                    settings = settings,
                    onBack = ::back,
                    onUpdate = { updated -> scope.launch { settingsStore.update { updated } } },
                    onAdultConfirm = { scope.launch { settingsStore.setHideAdultContent(false) } }
                )
                AppScreen.LIBRARY_SETTINGS -> LibrarySettingsScreen(
                    settings = settings,
                    store = store,
                    library = library,
                    progress = progress,
                    downloads = downloads,
                    categories = categories,
                    searchHistory = recentSearches,
                    onBack = ::back,
                    onUpdate = { updated -> scope.launch { settingsStore.update { updated } } }
                )
                AppScreen.TRACKING -> StaticSettingsScreen("التتبّع", "ربط MyAnimeList وAniList يتطلب إعداد OAuth وموافقة الحساب؛ لم يُفعّل تسجيل دخول وهمي.", ::back)
                AppScreen.PRIVACY -> StaticSettingsScreen("الأمان والخصوصية", "وضع التصفح المتخفي لا يحفظ عمليات البحث أو تقدم القراءة. قفل التطبيق بالبصمة أو الرمز يحتاج شاشة إعداد مستقلة.", ::back)
                AppScreen.ADVANCED -> StaticSettingsScreen("متقدم", "امسح الملفات المؤقتة أو راجع سجل الأخطاء. لا تُحذف قاعدة المكتبة عند مسح ذاكرة الصور.", ::back)
                AppScreen.ABOUT -> AboutScreen(::back)
            }
            if (screen in NAV_BAR_SCREENS) {
                FloatingBottomNavigation(
                    selected = selectedTab,
                    onSelect = { destination ->
                        if (selectedTab == destination && screen == destination) scrollTopToken++
                        selectedTab = destination
                        stack.clear(); stack.add(destination)
                    },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
            }
        }
        }
    }
}

private val ROOT_SCREENS = setOf(AppScreen.HOME, AppScreen.EXPLORE, AppScreen.LIBRARY, AppScreen.DOWNLOADS, AppScreen.MORE)
private val NAV_BAR_SCREENS = setOf(AppScreen.HOME, AppScreen.EXPLORE, AppScreen.SEARCH, AppScreen.LIBRARY, AppScreen.DOWNLOADS, AppScreen.MORE)

private fun mergeFederatedPages(previous: FederatedPage, next: FederatedPage): FederatedPage {
    val merged = LinkedHashMap<String, MangaGroup>()
    (previous.groups + next.groups).forEach { group ->
        val old = merged[group.normalizedTitle]
        if (old == null) merged[group.normalizedTitle] = group
        else {
            val refs = (old.sources + group.sources).distinctBy { it.source.id to it.manga.url }
            merged[group.normalizedTitle] = old.copy(sources = refs)
        }
    }
    return FederatedPage(merged.values.toList(), (previous.failures + next.failures).distinctBy { it.sourceId })
}

private fun addToLibrary(ref: SourceMangaRef, store: MangaRepository, current: List<LibraryMangaEntity>, scope: kotlinx.coroutines.CoroutineScope) {
    toggleLibrary(ref, store, current, scope)
}

private fun toggleLibrary(ref: SourceMangaRef, store: MangaRepository, current: List<LibraryMangaEntity>, scope: kotlinx.coroutines.CoroutineScope, genres: List<String> = emptyList()) {
    val saved = current.any { it.sourceId == ref.source.id && it.mangaUrl == ref.manga.url }
    scope.launch {
        if (saved) store.removeManga(ref.source.id, ref.manga.url)
        else store.saveManga(LibraryMangaEntity(ref.source.id, ref.manga.url, ref.manga.title, ref.manga.coverUrl, ref.manga.description, ref.manga.status, genres = genres.joinToString(",").ifBlank { null }))
    }
}

private suspend fun downloadChapter(
    context: android.content.Context,
    ref: SourceMangaRef,
    chapter: SourceChapter,
    store: MangaRepository
) {
    runCatching { ChapterDownloadService(context, store).download(ref, chapter) }.onFailure { error ->
        if (error !is kotlinx.coroutines.CancellationException) {
            android.widget.Toast.makeText(context, "فشل تنزيل الفصل: ${error.message ?: "خطأ غير معروف"}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}
