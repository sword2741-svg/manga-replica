@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.mangareplica

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.mangareplica.data.persistence.ChapterDownloadEntity
import com.example.mangareplica.data.persistence.LibraryMangaEntity
import com.example.mangareplica.data.persistence.ReadingProgressEntity
import com.example.mangareplica.data.sources.ChapterEntry
import com.example.mangareplica.data.sources.ChapterGrouping
import com.example.mangareplica.data.sources.MangaGroup
import com.example.mangareplica.data.sources.SourceChapter
import com.example.mangareplica.data.sources.SourceManga
import com.example.mangareplica.data.sources.SourceMangaRef
import java.text.DateFormat
import java.util.Date

private const val DAY_MS = 24L * 60L * 60L * 1000L

internal enum class ChapterVisual { NORMAL, NEW, READ, CURRENT }
internal enum class DlKind { NONE, ACTIVE, DONE }
internal data class DlUi(val kind: DlKind, val percent: Int = 0)

internal fun downloadKey(sourceId: String, mangaUrl: String, chapterUrl: String): String = "$sourceId|$mangaUrl|$chapterUrl"

/** Everything needed to decide how each chapter row looks, computed once per list. */
internal class ChapterContext(
    val sourceId: String,
    val mangaUrl: String,
    val progress: Map<String, ReadingProgressEntity>,
    val downloads: Map<String, ChapterDownloadEntity>,
    val activeDownloads: Set<String>,
    val currentChapterUrl: String?,
    val latestProgress: ReadingProgressEntity?,
    val now: Long,
) {
    fun visualOf(entry: ChapterEntry): ChapterVisual {
        if (currentChapterUrl != null && entry.chapters.any { it.url == currentChapterUrl }) return ChapterVisual.CURRENT
        if (entry.chapters.any { progress[it.url]?.isComplete == true }) return ChapterVisual.READ
        val opened = entry.chapters.any { progress[it.url] != null }
        val date = entry.latestDate
        if (!opened && date != null && now - date in 0..DAY_MS) return ChapterVisual.NEW
        return ChapterVisual.NORMAL
    }

    fun progressOf(entry: ChapterEntry): ReadingProgressEntity? =
        entry.chapters.mapNotNull { progress[it.url] }.maxByOrNull { it.updatedAt }

    fun downloadedVariant(entry: ChapterEntry): SourceChapter? = entry.chapters.firstOrNull { chapter ->
        val record = downloads[chapter.url]
        record != null && record.status == "completed" && !record.localPath.isNullOrBlank()
    }

    fun activeVariant(entry: ChapterEntry): SourceChapter? =
        entry.chapters.firstOrNull { downloadKey(sourceId, mangaUrl, it.url) in activeDownloads }

    fun progressVariant(entry: ChapterEntry): SourceChapter? =
        entry.chapters.filter { progress[it.url] != null }.maxByOrNull { progress[it.url]!!.updatedAt }

    fun downloadOf(entry: ChapterEntry): DlUi {
        if (downloadedVariant(entry) != null) return DlUi(DlKind.DONE, 100)
        val active = activeVariant(entry)
        if (active != null) return DlUi(DlKind.ACTIVE, downloads[active.url]?.progressPercent ?: 0)
        return DlUi(DlKind.NONE)
    }
}

internal fun buildChapterContext(
    sourceId: String,
    mangaUrl: String,
    progress: List<ReadingProgressEntity>,
    downloads: List<ChapterDownloadEntity>,
    activeDownloads: Set<String>,
): ChapterContext {
    val mine = progress.filter { it.sourceId == sourceId && it.mangaUrl == mangaUrl }
    val latest = mine.maxByOrNull { it.updatedAt }
    return ChapterContext(
        sourceId = sourceId,
        mangaUrl = mangaUrl,
        progress = mine.associateBy { it.chapterUrl },
        downloads = downloads.filter { it.sourceId == sourceId && it.mangaUrl == mangaUrl }.associateBy { it.chapterUrl },
        activeDownloads = activeDownloads,
        currentChapterUrl = latest?.takeIf { !it.isComplete }?.chapterUrl,
        latestProgress = latest,
        now = System.currentTimeMillis(),
    )
}

@Composable
internal fun ChapterDownloadButton(
    state: DlUi,
    canStart: Boolean,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Box {
        IconButton(
            onClick = {
                when (state.kind) {
                    DlKind.NONE -> onDownload()
                    DlKind.ACTIVE -> onCancel()
                    DlKind.DONE -> menu = true
                }
            },
            enabled = state.kind != DlKind.NONE || canStart,
            modifier = Modifier.size(48.dp),
        ) {
            when (state.kind) {
                DlKind.NONE -> Icon(Icons.Default.Download, "تنزيل الفصل", tint = AppMuted)
                DlKind.ACTIVE -> Box(contentAlignment = Alignment.Center) {
                    if (state.percent <= 0) {
                        CircularProgressIndicator(Modifier.size(26.dp), color = AppCoral, strokeWidth = 2.5.dp)
                    } else {
                        CircularProgressIndicator(progress = { state.percent / 100f }, modifier = Modifier.size(26.dp), color = AppCoral, strokeWidth = 2.5.dp)
                    }
                    Icon(Icons.Default.Stop, "إلغاء التنزيل", tint = AppCoral, modifier = Modifier.size(12.dp))
                }
                DlKind.DONE -> Icon(Icons.Default.CheckCircle, "منزّل", tint = AppCoral)
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("حذف التنزيل") }, onClick = { menu = false; onDelete() })
        }
    }
}

@Composable
internal fun ChapterRow(
    entry: ChapterEntry,
    visual: ChapterVisual,
    progress: ReadingProgressEntity?,
    dl: DlUi,
    selected: Boolean,
    enabled: Boolean,
    hint: String?,
    currentLabel: String?,
    canStartDownload: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
) {
    val isCurrent = visual == ChapterVisual.CURRENT || currentLabel != null
    val coral = AppCoral
    val shape = RoundedCornerShape(14.dp)
    val number = ChapterGrouping.formatNumber(entry.number)
    val title = if (number.isNotEmpty()) "الفصل $number" else entry.primary.name
    val subtitle = if (number.isNotEmpty()) entry.primary.name.takeIf { it.isNotBlank() } else null
    val dim = if (visual == ChapterVisual.READ && currentLabel == null) 0.55f else if (!enabled) 0.5f else 1f
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(dim)
            .clip(shape)
            .background(if (selected) Color(0x33FF6B4A) else AppPanel)
            .then(if (isCurrent) Modifier.background(Color(0x14FF6B4A)).border(1.5.dp, coral, shape) else Modifier)
            .combinedClickable(enabled = enabled, onClick = onClick, onLongClick = onLongClick)
            .padding(start = 10.dp, end = 2.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (isCurrent) coral else Color(0xFF232733)),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Icon(Icons.Default.Check, null, tint = if (isCurrent) Color(0xFF1A0A06) else coral)
            } else if (visual == ChapterVisual.READ && currentLabel == null) {
                Icon(Icons.Default.Check, "مقروء", tint = coral)
            } else {
                Text(
                    number.ifEmpty { "—" },
                    color = if (isCurrent) Color(0xFF1A0A06) else MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (!subtitle.isNullOrBlank()) {
                Text(subtitle, color = AppMuted, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                entry.latestDate?.let {
                    Text(DateFormat.getDateInstance().format(Date(it)), color = AppMuted, style = MaterialTheme.typography.labelSmall)
                }
                if (visual == ChapterVisual.NEW) {
                    Text(
                        "جديد",
                        Modifier.clip(RoundedCornerShape(6.dp)).background(coral).padding(horizontal = 6.dp, vertical = 1.dp),
                        color = Color(0xFF1A0A06),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
                if (entry.hasVariants) {
                    Text("${entry.chapters.size} نسخ", color = coral, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (currentLabel != null) {
                Text(currentLabel, color = coral, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            } else if (visual == ChapterVisual.CURRENT && progress != null) {
                val page = progress.pageIndex.coerceAtLeast(0)
                val total = progress.pageCount
                Spacer(Modifier.height(4.dp))
                if (total > 0) {
                    LinearProgressIndicator(
                        progress = { ((page + 1f) / total).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = coral,
                        trackColor = Color(0xFF232733),
                    )
                }
                Text(
                    if (total > 0) "متابعة · الصفحة ${page + 1} من $total" else "متابعة · الصفحة ${page + 1}",
                    color = coral,
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            if (hint != null) Text(hint, color = AppMuted, style = MaterialTheme.typography.labelSmall)
        }
        ChapterDownloadButton(dl, canStartDownload, onDownload, onCancel, onDelete)
    }
}

@Composable
private fun VariantChooser(entry: ChapterEntry, onPick: (SourceChapter) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اختر النسخة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                entry.chapters.forEach { chapter ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(AppPanel)
                            .clickable { onPick(chapter) }.padding(12.dp),
                    ) {
                        Text(chapter.name.ifBlank { "الفصل ${ChapterGrouping.formatNumber(entry.number)}" }, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        val meta = listOfNotNull(
                            chapter.uploadDate?.let { DateFormat.getDateInstance().format(Date(it)) },
                            chapter.language?.takeIf { it.isNotBlank() }?.uppercase(),
                        ).joinToString(" · ")
                        if (meta.isNotEmpty()) Text(meta, color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}

@Composable
fun DetailScreen(
    group: MangaGroup?,
    selectedRef: SourceMangaRef?,
    details: SourceManga?,
    chapters: List<SourceChapter>,
    loading: Boolean,
    error: String?,
    library: List<LibraryMangaEntity>,
    progress: List<ReadingProgressEntity>,
    downloads: List<ChapterDownloadEntity>,
    activeDownloads: Set<String>,
    online: Boolean,
    onBack: () -> Unit,
    onOpenChapter: (SourceChapter) -> Unit,
    onToggleLibrary: (SourceMangaRef) -> Unit,
    onMarkChapters: (List<SourceChapter>, Boolean) -> Unit,
    onDownloadChapters: (List<SourceChapter>) -> Unit,
    onCancelDownload: (SourceChapter) -> Unit,
    onDeleteDownload: (SourceChapter) -> Unit,
) {
    val context = LocalContext.current
    val ref = selectedRef
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var searchText by rememberSaveable { mutableStateOf("") }
    var newestFirst by rememberSaveable { mutableStateOf(true) }
    var filter by rememberSaveable { mutableStateOf("all") }
    var descExpanded by rememberSaveable { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var chooser by remember { mutableStateOf<Pair<ChapterEntry, (SourceChapter) -> Unit>?>(null) }

    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }

    val sourceId = ref?.source?.id.orEmpty()
    val mangaUrl = ref?.manga?.url.orEmpty()
    val ctx = remember(sourceId, mangaUrl, progress, downloads, activeDownloads) {
        buildChapterContext(sourceId, mangaUrl, progress, downloads, activeDownloads)
    }
    val entries = remember(chapters) { ChapterGrouping.group(chapters) }
    val ordered = remember(entries, newestFirst) { ChapterGrouping.order(entries, newestFirst) }
    val shown = remember(ordered, searchText, filter, ctx) {
        val query = searchText.trim()
        ordered.filter { entry ->
            val matchesSearch = query.isEmpty() ||
                ChapterGrouping.formatNumber(entry.number).contains(query, ignoreCase = true) ||
                entry.chapters.any { it.name.contains(query, ignoreCase = true) }
            val matchesFilter = when (filter) {
                "unread" -> ctx.visualOf(entry) != ChapterVisual.READ
                "downloaded" -> ctx.downloadOf(entry).kind == DlKind.DONE
                else -> true
            }
            matchesSearch && matchesFilter
        }
    }
    val oldestFirst = remember(entries) { ChapterGrouping.order(entries, false) }

    val continueTarget: SourceChapter? = remember(entries, ctx) {
        val currentUrl = ctx.currentChapterUrl
        val currentEntry = entries.firstOrNull { e -> e.chapters.any { it.url == currentUrl } }
        when {
            currentEntry != null -> currentEntry.chapters.first { it.url == currentUrl }
            ctx.latestProgress != null -> {
                val latestUrl = ctx.latestProgress.chapterUrl
                val index = oldestFirst.indexOfFirst { e -> e.chapters.any { it.url == latestUrl } }
                if (index >= 0) (oldestFirst.getOrNull(index + 1) ?: oldestFirst[index]).primary else oldestFirst.firstOrNull()?.primary
            }
            else -> oldestFirst.firstOrNull()?.primary
        }
    }

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

    fun openChapterSafely(chapter: SourceChapter, downloaded: Boolean) {
        if (!online && !downloaded) {
            toast("هذا الفصل غير منزّل ويحتاج اتصالاً بالإنترنت")
            return
        }
        onOpenChapter(chapter)
    }

    fun openEntry(entry: ChapterEntry) {
        val downloaded = ctx.downloadedVariant(entry)
        val reading = ctx.progressVariant(entry)
        when {
            downloaded != null -> onOpenChapter(downloaded)
            !online -> toast("هذا الفصل غير منزّل ويحتاج اتصالاً بالإنترنت")
            reading != null -> onOpenChapter(reading)
            entry.hasVariants -> chooser = entry to { picked -> onOpenChapter(picked) }
            else -> openChapterSafely(entry.primary, false)
        }
    }

    fun downloadEntry(entry: ChapterEntry) {
        if (!online) {
            toast("التنزيل يحتاج اتصالاً بالإنترنت")
            return
        }
        if (entry.hasVariants) chooser = entry to { picked -> onDownloadChapters(listOf(picked)) }
        else onDownloadChapters(listOf(entry.primary))
    }

    fun toggleSelection(entry: ChapterEntry) {
        selected = if (entry.key in selected) selected - entry.key else selected + entry.key
    }

    val selectedEntries = entries.filter { it.key in selected }
    val inLibrary = ref != null && details != null && library.any { it.sourceId == ref.source.id && it.mangaUrl == details.url }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = if (selected.isEmpty()) 24.dp else 110.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item(key = "top") {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
                    Text("تفاصيل العمل", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                }
            }
            if (details == null) {
                item(key = "state") {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        when {
                            loading -> CircularProgressIndicator(color = AppCoral)
                            error != null -> {
                                Text("تعذر إكمال الطلب", color = AppCoral)
                                Text(error, color = AppMuted)
                                TextButton(onClick = onBack) { Text("رجوع") }
                            }
                            else -> AppEmptyState("لا توجد بيانات", "لم يتم تحميل تفاصيل هذا العمل.")
                        }
                    }
                }
            } else {
                item(key = "header") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        Box(Modifier.size(96.dp, 136.dp).clip(RoundedCornerShape(14.dp)).background(AppPanel)) {
                            details.coverUrl?.let { AsyncImage(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        }
                        Column(Modifier.weight(1f).padding(start = 14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(details.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            Text(details.author ?: "المؤلف غير معروف", color = AppMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                details.status ?: "حالة النشر غير محددة",
                                Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0x22FF6B4A)).padding(horizontal = 8.dp, vertical = 3.dp),
                                color = AppCoral, style = MaterialTheme.typography.labelMedium,
                            )
                        }
                    }
                }
                item(key = "actions") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                val target = continueTarget
                                if (target != null) {
                                    val entry = entries.firstOrNull { e -> e.chapters.any { it.url == target.url } }
                                    val downloaded = entry?.let { ctx.downloadedVariant(it) } != null
                                    openChapterSafely(target, downloaded)
                                }
                            },
                            enabled = continueTarget != null,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = AppCoral, contentColor = Color(0xFF1A0A06)),
                        ) { Text("متابعة القراءة") }
                        OutlinedButton(onClick = { ref?.let(onToggleLibrary) }, modifier = Modifier.weight(1f)) {
                            Text(if (inLibrary) "إزالة من المكتبة" else "أضف للمكتبة")
                        }
                    }
                }
                details.description?.takeIf { it.isNotBlank() }?.let { description ->
                    item(key = "description") {
                        Column(Modifier.fillMaxWidth()) {
                            Text(description, maxLines = if (descExpanded) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface)
                            TextButton(onClick = { descExpanded = !descExpanded }) { Text(if (descExpanded) "أقل" else "المزيد", color = AppCoral) }
                        }
                    }
                }
                item(key = "toolbar") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الفصول (${entries.size})", style = MaterialTheme.typography.titleLarge)
                            Row {
                                IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) searchText = "" }) {
                                    Icon(Icons.Default.Search, "بحث في الفصول", tint = if (searchOpen) AppCoral else MaterialTheme.colorScheme.onSurface)
                                }
                                IconButton(onClick = { newestFirst = !newestFirst }) {
                                    Icon(Icons.Default.SwapVert, if (newestFirst) "الأحدث أولاً" else "الأقدم أولاً")
                                }
                            }
                        }
                        if (searchOpen) {
                            OutlinedTextField(
                                value = searchText,
                                onValueChange = { searchText = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("ابحث برقم الفصل أو اسمه") },
                                trailingIcon = {
                                    if (searchText.isNotEmpty()) IconButton(onClick = { searchText = "" }) { Icon(Icons.Default.Close, "مسح") }
                                },
                            )
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AppPill("الكل", filter == "all") { filter = "all" }
                            AppPill("غير مقروءة", filter == "unread") { filter = "unread" }
                            AppPill("منزّلة", filter == "downloaded") { filter = "downloaded" }
                            Text(if (newestFirst) "الأحدث أولاً" else "الأقدم أولاً", color = AppMuted, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 8.dp).align(Alignment.CenterVertically))
                        }
                        if (!online) Text("أنت غير متصل · يمكنك فتح الفصول المنزّلة فقط", color = AppMuted, style = MaterialTheme.typography.bodySmall)
                    }
                }
                when {
                    loading && entries.isEmpty() -> item(key = "loading") {
                        Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AppCoral) }
                    }
                    error != null && entries.isEmpty() -> item(key = "error") {
                        AppEmptyState("تعذر تحميل الفصول", error)
                    }
                    shown.isEmpty() -> item(key = "empty") {
                        AppEmptyState(
                            if (entries.isEmpty()) "لا توجد فصول متاحة" else "لا توجد نتائج",
                            if (entries.isEmpty()) "لم يُرجع المصدر فصولًا لهذا العمل." else "غيّر البحث أو المرشّح لعرض فصول أخرى.",
                        )
                    }
                    else -> items(shown, key = { it.key }) { entry ->
                        val visual = ctx.visualOf(entry)
                        val dl = ctx.downloadOf(entry)
                        val downloaded = dl.kind == DlKind.DONE
                        val offlineBlocked = !online && !downloaded
                        ChapterRow(
                            entry = entry,
                            visual = visual,
                            progress = ctx.progressOf(entry),
                            dl = dl,
                            selected = entry.key in selected,
                            enabled = true,
                            hint = if (offlineBlocked) "غير منزّل · يحتاج اتصالاً" else null,
                            currentLabel = null,
                            canStartDownload = online,
                            onClick = { if (selected.isNotEmpty()) toggleSelection(entry) else openEntry(entry) },
                            onLongClick = { toggleSelection(entry) },
                            onDownload = { downloadEntry(entry) },
                            onCancel = { (ctx.activeVariant(entry) ?: entry.primary).let(onCancelDownload) },
                            onDelete = { (ctx.downloadedVariant(entry) ?: entry.primary).let(onDeleteDownload) },
                        )
                    }
                }
            }
        }

        if (selected.isNotEmpty()) {
            Surface(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp),
                shape = RoundedCornerShape(20.dp),
                color = AppPanel,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                shadowElevation = 8.dp,
            ) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Default.Close, "إلغاء التحديد") }
                    Text("${selected.size}", fontWeight = FontWeight.Bold, color = AppCoral)
                    TextButton(onClick = { onMarkChapters(selectedEntries.flatMap { it.chapters }, true); selected = emptySet() }) { Text("مقروء") }
                    TextButton(onClick = { onMarkChapters(selectedEntries.flatMap { it.chapters }, false); selected = emptySet() }) { Text("غير مقروء") }
                    TextButton(
                        enabled = online,
                        onClick = {
                            val todo = selectedEntries.filter { ctx.downloadOf(it).kind == DlKind.NONE }.map { it.primary }
                            if (todo.isNotEmpty()) onDownloadChapters(todo)
                            selected = emptySet()
                        },
                    ) { Text("تنزيل") }
                    TextButton(
                        onClick = {
                            val last = oldestFirst.indexOfLast { it.key in selected }
                            if (last >= 0) onMarkChapters(oldestFirst.take(last + 1).flatMap { it.chapters }, true)
                            selected = emptySet()
                        },
                    ) {
                        Icon(Icons.Default.DoneAll, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("كل ما قبله")
                    }
                }
            }
        }
    }

    chooser?.let { (entry, action) ->
        VariantChooser(entry, onPick = { picked -> chooser = null; action(picked) }, onDismiss = { chooser = null })
    }
}

/** Reader bottom sheet (about 3/4 of the screen): jump to any chapter, with download state per row. */
@Composable
internal fun ReaderChapterSheet(
    ref: SourceMangaRef?,
    chapters: List<SourceChapter>,
    current: SourceChapter?,
    progress: List<ReadingProgressEntity>,
    downloads: List<ChapterDownloadEntity>,
    activeDownloads: Set<String>,
    online: Boolean,
    onSelect: (SourceChapter) -> Unit,
    onDownload: (SourceChapter) -> Unit,
    onCancel: (SourceChapter) -> Unit,
    onDelete: (SourceChapter) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var query by remember { mutableStateOf("") }
    val sourceId = ref?.source?.id.orEmpty()
    val mangaUrl = ref?.manga?.url.orEmpty()
    val ctx = remember(sourceId, mangaUrl, progress, downloads, activeDownloads) {
        buildChapterContext(sourceId, mangaUrl, progress, downloads, activeDownloads)
    }
    val entries = remember(chapters) { ChapterGrouping.order(ChapterGrouping.group(chapters), true) }
    val shown = remember(entries, query) {
        val q = query.trim()
        if (q.isEmpty()) entries else entries.filter { e ->
            ChapterGrouping.formatNumber(e.number).contains(q, ignoreCase = true) || e.chapters.any { it.name.contains(q, ignoreCase = true) }
        }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) {
        val index = entries.indexOfFirst { e -> e.chapters.any { it.url == current?.url } }
        if (index > 1) listState.scrollToItem(index - 1) else if (index >= 0) listState.scrollToItem(index)
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.75f).padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الفصول (${entries.size})", style = MaterialTheme.typography.titleLarge)
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "إغلاق") }
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("ابحث برقم الفصل") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
            )
            Spacer(Modifier.height(8.dp))
            if (shown.isEmpty()) {
                AppEmptyState("لا توجد فصول", "لا يوجد فصل يطابق بحثك.")
            } else {
                LazyColumn(Modifier.fillMaxSize(), state = listState, verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(shown, key = { it.key }) { entry ->
                        val isHere = current != null && entry.chapters.any { it.url == current.url }
                        val dl = ctx.downloadOf(entry)
                        val blocked = !online && dl.kind != DlKind.DONE && !isHere
                        ChapterRow(
                            entry = entry,
                            visual = ctx.visualOf(entry),
                            progress = null,
                            dl = dl,
                            selected = false,
                            enabled = !blocked,
                            hint = if (blocked) "غير منزّل · يحتاج اتصالاً" else null,
                            currentLabel = if (isHere) "أنت هنا" else null,
                            canStartDownload = online,
                            onClick = {
                                val target = ctx.downloadedVariant(entry) ?: ctx.progressVariant(entry) ?: entry.primary
                                onSelect(target)
                            },
                            onLongClick = {},
                            onDownload = { onDownload(entry.primary) },
                            onCancel = { onCancel(ctx.activeVariant(entry) ?: entry.primary) },
                            onDelete = { onDelete(ctx.downloadedVariant(entry) ?: entry.primary) },
                        )
                    }
                }
            }
        }
    }
}
