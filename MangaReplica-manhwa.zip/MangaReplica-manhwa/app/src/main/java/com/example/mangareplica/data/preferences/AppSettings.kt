package com.example.mangareplica.data.preferences

/** Appearance preference; SYSTEM delegates to the device setting. */
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class ReaderMode { PAGED, CONTINUOUS, WEBTOON }
enum class ReaderDirection { LEFT_TO_RIGHT, RIGHT_TO_LEFT }
enum class ImageScale { FIT_SCREEN, FIT_WIDTH, FIT_HEIGHT, ORIGINAL_SIZE }
enum class BackupFrequency { NEVER, DAILY, WEEKLY, MONTHLY }

/** Persisted application preferences. Defaults intentionally favor privacy and safe data usage. */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val trueBlackAmoled: Boolean = false,
    /** ARGB color as a signed Kotlin Int; convert to/from #AARRGGBB when displaying. */
    val accentColorArgb: Int = 0xFFFF6B4A.toInt(),
    /** "all" means no source restriction; otherwise this is the selected source ID. */
    val homeSourceFilter: String = "all",
    /** A single "*" means all current and newly-added sources are enabled. */
    val enabledSourceIds: Set<String> = setOf("*"),
    val extensionRepositoryIndexUrl: String = "https://github.com/keiyoushi/extensions/raw/repo/index.pb",
    val showBanners: Boolean = true,
    val showContinueReading: Boolean = true,
    val showTrending: Boolean = true,
    val showUpdates: Boolean = true,
    val showNew: Boolean = true,
    val showSourceBadges: Boolean = true,
    /** Adult content is hidden unless the user explicitly opts in. */
    val hideAdultContent: Boolean = true,
    val wifiOnlyUpdates: Boolean = true,
    val wifiOnlyDownloads: Boolean = true,
    val deleteChapterAfterRead: Boolean = false,
    val downloadFolder: String = "",
    val readerMode: ReaderMode = ReaderMode.PAGED,
    val readerDirection: ReaderDirection = ReaderDirection.RIGHT_TO_LEFT,
    val fullscreen: Boolean = true,
    val cropPages: Boolean = false,
    val keepScreenOn: Boolean = true,
    val volumeKeysNavigation: Boolean = false,
    val touchZonesEnabled: Boolean = true,
    val imageScale: ImageScale = ImageScale.FIT_SCREEN,
    val grayscaleFilter: Boolean = false,
    /** Normalized display brightness from 0.0 (minimum) to 1.0 (maximum). */
    val readerBrightness: Float = 1.0f,
    val incognitoMode: Boolean = false,
    val downloadOnly: Boolean = false,
    val backupFrequency: BackupFrequency = BackupFrequency.WEEKLY,
    /** Local profile; nothing here requires an account or a server. */
    val profileName: String = "",
    val profileBio: String = "",
    /** Absolute path of the avatar copied into app storage, or empty. */
    val profileAvatarPath: String = "",
    /** Epoch millis of first launch with the profile feature; 0 until recorded. */
    val profileJoinedAt: Long = 0L,
    /** Latest-works type filter: all, manhwa, manga or manhua. */
    val latestTypeFilter: String = "all",
    /** Epoch millis of the last successful manual backup; 0 if never. */
    val lastBackupAt: Long = 0L,
) {
    fun isSourceEnabled(sourceId: String): Boolean = "*" in enabledSourceIds || sourceId in enabledSourceIds

    /** Hex color suitable for UI text fields, in #AARRGGBB form. */
    val accentColorHex: String get() = "#%08X".format(accentColorArgb.toLong() and 0xFFFFFFFFL)
}
