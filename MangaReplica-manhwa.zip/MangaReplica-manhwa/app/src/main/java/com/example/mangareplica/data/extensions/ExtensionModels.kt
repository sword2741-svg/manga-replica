package com.example.mangareplica.data.extensions

import com.google.gson.JsonElement

/** A source extension as listed by Keiyoushi index.proto or its full index.json companion. */
data class ExtensionEntry(
    val name: String = "",
    val pkg: String = "",
    val apk: String = "",
    val lang: String = "",
    val code: Long = 0,
    val version: String = "",
    val nsfw: JsonElement? = null,
    val sources: List<ExtensionSourceEntry> = emptyList(),
    val iconUrl: String = "",
    val jarUrl: String = "",
    val extensionLib: String = "",
    val contentWarning: Int? = null
) {
    /** Languages represented by this package and its individual source entries. */
    val languages: Set<String>
        get() = (sources.map { it.lang } + lang)
            .map(String::trim)
            .filter(String::isNotEmpty)
            .toSet()

    val hasArabicSource: Boolean
        get() = languages.any { it.equals("ar", ignoreCase = true) || it.startsWith("ar-", ignoreCase = true) }

    val isNsfw: Boolean
        get() = contentWarning == 3 || when {
            nsfw == null || nsfw.isJsonNull -> false
            nsfw.isJsonPrimitive && nsfw.asJsonPrimitive.isBoolean -> nsfw.asBoolean
            nsfw.isJsonPrimitive && nsfw.asJsonPrimitive.isNumber -> nsfw.asInt == 3
            nsfw.isJsonPrimitive -> nsfw.asString.contains("NSFW", ignoreCase = true) || nsfw.asString == "3"
            else -> false
        }

    val hasMixedContent: Boolean
        get() = contentWarning == 2 || nsfw?.let { it.isJsonPrimitive && it.asString.contains("MIXED", true) } == true
}

data class ExtensionSourceEntry(
    val name: String = "",
    val lang: String = "",
    val id: Long = 0,
    val baseUrl: String = ""
)

data class ExtensionRepoMetadata(
    val name: String = "",
    val website: String = "",
    val signingKeyFingerprint: String = "",
    val signingKey: String = ""
)

data class ExtensionCatalog(
    val repositoryUrl: String,
    val metadata: ExtensionRepoMetadata?,
    val entries: List<ExtensionEntry>,
    val protobufBytes: Int,
    val indexFormat: String,
    val warning: String? = null
)
