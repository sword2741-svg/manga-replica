package com.example.mangareplica.data.sources

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChapterGroupingTest {
    private fun chapter(url: String, number: Float?, date: Long? = null) =
        SourceChapter(sourceId = "s", url = url, name = "ch $url", number = number, uploadDate = date)

    @Test
    fun chaptersWithTheSameNumberAreMergedIntoOneEntry() {
        val entries = ChapterGrouping.group(listOf(chapter("a", 1f), chapter("b", 2f), chapter("c", 2f)))
        assertEquals(2, entries.size)
        val two = entries.first { it.number == 2f }
        assertTrue(two.hasVariants)
        assertEquals(listOf("b", "c"), two.chapters.map { it.url })
    }

    @Test
    fun chaptersWithoutNumbersStayDistinct() {
        val entries = ChapterGrouping.group(listOf(chapter("a", null), chapter("b", -1f)))
        assertEquals(2, entries.size)
        assertFalse(entries.any { it.hasVariants })
    }

    @Test
    fun orderSortsByNumberWhenAllHaveOne() {
        val entries = ChapterGrouping.group(listOf(chapter("a", 1f), chapter("c", 3f), chapter("b", 2f)))
        assertEquals(listOf(3f, 2f, 1f), ChapterGrouping.order(entries, newestFirst = true).map { it.number })
        assertEquals(listOf(1f, 2f, 3f), ChapterGrouping.order(entries, newestFirst = false).map { it.number })
    }

    @Test
    fun orderKeepsSourceOrderWhenNumbersAreMissing() {
        val entries = ChapterGrouping.group(listOf(chapter("x", null), chapter("y", 5f)))
        assertEquals(listOf("x", "y"), ChapterGrouping.order(entries, newestFirst = true).map { it.primary.url })
        assertEquals(listOf("y", "x"), ChapterGrouping.order(entries, newestFirst = false).map { it.primary.url })
    }

    @Test
    fun formatNumberDropsTrailingZero() {
        assertEquals("12", ChapterGrouping.formatNumber(12f))
        assertEquals("12.5", ChapterGrouping.formatNumber(12.5f))
        assertEquals("", ChapterGrouping.formatNumber(null))
    }
}
