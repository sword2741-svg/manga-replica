package com.example.mangareplica.data.extensions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KeiyoushiIndexProtoTest {
    @Test fun decodesPublishedIndexSchemaAndField501JarUrl() {
        val source = varintField(1, 8_600_626_646_399_125_374L) +
            text(2, "Akuma") + text(3, "ar") + text(4, "https://example.org")
        val resources = text(1, "https://repo.example/ext.apk") +
            text(2, "https://repo.example/icon.png") + text(501, "https://repo.example/ext.jar")
        val extension = text(1, "Akuma") +
            text(2, "eu.kanade.tachiyomi.extension.all.akuma") +
            message(3, resources) + text(4, "1.6") + varintField(5, 106010) +
            text(6, "1.6.10") + varintField(7, 3) + message(8, source)
        val extensionList = message(1, extension)
        val contact = text(1, "https://keiyoushi.github.io") + text(2, "https://discord.gg/example")
        val index = text(1, "Keiyoushi") + text(2, "KEI") +
            text(3, "9add655a78e96c4ec7a53ef89dccb557cb5d767489fac5e785d671a5a75d4da2") +
            message(4, contact) + message(101, extensionList) + varintField(600, 7)

        val decoded = KeiyoushiIndexProto.decode(index)
        assertEquals("Keiyoushi", decoded.name)
        assertEquals("https://keiyoushi.github.io", decoded.website)
        assertEquals(1, decoded.entries.size)
        val entry = decoded.entries.single()
        assertEquals("Akuma", entry.name)
        assertEquals("eu.kanade.tachiyomi.extension.all.akuma", entry.pkg)
        assertEquals("https://repo.example/ext.apk", entry.apk)
        assertEquals("https://repo.example/ext.jar", entry.jarUrl)
        assertEquals(106010L, entry.code)
        assertEquals("1.6.10", entry.version)
        assertEquals(3, entry.contentWarning)
        assertTrue(entry.isNsfw)
        assertEquals(8_600_626_646_399_125_374L, entry.sources.single().id)
        assertEquals("ar", entry.sources.single().lang)
    }

    @Test fun decodesStandaloneExtensionListForRemoteListOneof() {
        val ext = text(1, "Manga") + text(2, "example.manga") +
            message(3, text(1, "https://repo.example/manga.apk")) + text(6, "1.0")
        val result = KeiyoushiIndexProto.decodeExtensionList(message(1, ext))
        assertEquals("example.manga", result.single().pkg)
    }

    @Test fun reportsTruncatedProtobufInsteadOfReturningPartialCatalog() {
        val malformed = byteArrayOf(0x0a, 0x05, 0x41)
        val error = runCatching { KeiyoushiIndexProto.decode(malformed) }.exceptionOrNull()
        assertTrue(error != null)
    }

    private fun text(field: Int, value: String) = message(field, value.toByteArray(Charsets.UTF_8))

    private fun message(field: Int, value: ByteArray) =
        varint((field.toLong() shl 3) or 2L) + varint(value.size.toLong()) + value

    private fun varintField(field: Int, value: Long) = varint(field.toLong() shl 3) + varint(value)

    private fun varint(input: Long): ByteArray {
        var value = input
        val out = ArrayList<Byte>()
        while (value and -128L != 0L) {
            out += ((value and 0x7f) or 0x80).toByte()
            value = value ushr 7
        }
        out += value.toByte()
        return out.toByteArray()
    }
}
