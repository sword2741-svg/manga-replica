package com.example.mangareplica.data.extensions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExtensionArabicLanguageTest {
    @Test
    fun detectsArabicFromExtensionLanguage() {
        val entry = ExtensionEntry(lang = "ar")

        assertTrue(entry.hasArabicSource)
        assertTrue("ar" in entry.languages)
    }

    @Test
    fun detectsArabicAmongMultipleSourcesInOnePackage() {
        val entry = ExtensionEntry(
            lang = "all",
            sources = listOf(
                ExtensionSourceEntry(name = "English source", lang = "en"),
                ExtensionSourceEntry(name = "Arabic source", lang = "ar"),
            ),
        )

        assertTrue(entry.hasArabicSource)
        assertEquals(setOf("all", "en", "ar"), entry.languages)
    }

    @Test
    fun ignoresNonArabicLanguages() {
        val entry = ExtensionEntry(
            lang = "en",
            sources = listOf(ExtensionSourceEntry(name = "English source", lang = "en")),
        )

        assertFalse(entry.hasArabicSource)
    }
}
