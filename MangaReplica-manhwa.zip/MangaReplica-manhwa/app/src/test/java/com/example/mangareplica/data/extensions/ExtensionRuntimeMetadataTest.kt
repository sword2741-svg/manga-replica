package com.example.mangareplica.data.extensions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class ExtensionRuntimeMetadataTest {
    @Test
    fun parsesStringAndNumericExtensionLibMetadata() {
        assertEquals("1.6", parseExtensionLibVersion("1.6", "1.6.22"))
        assertEquals("1.6", parseExtensionLibVersion(1.6f, "1.6.22"))
        assertEquals("1.6", parseExtensionLibVersion(null, "1.6.22"))
    }

    @Test
    fun missingOrMalformedMetadataDoesNotInventASupportedApi() {
        assertEquals("", parseExtensionLibVersion(null, "unknown"))
        assertEquals("not-an-api", parseExtensionLibVersion("not-an-api", "1.6.22"))
    }

    @Test
    fun sourceIdsAreUniqueAcrossExtensionPackages() {
        val sourceId = 1234L
        assertNotEquals(
            mihonSourceId("org.example.first", "en", sourceId),
            mihonSourceId("org.example.second", "en", sourceId),
        )
        assertEquals("mihon:org.example.first:ar:1234", mihonSourceId("org.example.first", "AR", sourceId))
    }
}
