package com.example.mangareplica.data.sources

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FederatedSourceRepositoryFailureTest {
    @Test
    fun linkageErrorFromExtensionIsReportedAsSourceFailure() = runBlocking {
        val broken = object : MangaSource {
            override val id = "mihon:en:broken"
            override val name = "Broken English Source"
            override val language = "en"
            override suspend fun popular(page: Int) = emptyList<SourceManga>()
            override suspend fun search(query: String, page: Int): List<SourceManga> =
                throw NoClassDefFoundError("missing extension runtime class")
            override suspend fun details(manga: SourceManga) = manga
            override suspend fun chapters(manga: SourceManga) = emptyList<SourceChapter>()
            override suspend fun pages(chapter: SourceChapter) = emptyList<SourcePage>()
        }
        val registry = NativeSourceRegistry(emptyList()).apply { replaceExtensions(listOf(broken)) }

        val result = FederatedSourceRepository(registry).search("solo", 0)

        assertTrue(result.groups.isEmpty())
        assertEquals(1, result.failures.size)
        assertEquals("Broken English Source", result.failures.single().sourceName)
        assertTrue(result.failures.single().message.contains("missing extension runtime class"))
    }
}
