package com.example.mangareplica.data.sources

import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Request
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

/** Opt-in live tests: MANGADEX_LIVE_TEST=1 ./gradlew testDebugUnitTest */
class MangaDexLiveIntegrationTest {
    @Test fun liveSearchDetailsChaptersAndRealPageImage() = runBlocking {
        assumeTrue("Set MANGADEX_LIVE_TEST=1 to make public network requests", System.getenv("MANGADEX_LIVE_TEST") == "1")
        val source = MangaDexSource()
        val results = source.search("The Eminence in Shadow", 0)
        val manga = results.firstOrNull { it.title.contains("Eminence in Shadow", ignoreCase = true) }
        assertNotNull("Search must return the real manga", manga)
        manga!!
        assertNotNull("The API result must include a cover URL", manga.coverUrl)
        println("LIVE_SEARCH status=200 query=The Eminence in Shadow id=${manga.url} title=${manga.title} cover=${manga.coverUrl}")

        val details = source.details(manga)
        assertTrue("Details must return a title", details.title.isNotBlank())
        assertTrue("Details should expose the source description when available", !details.description.isNullOrBlank())
        println("LIVE_DETAILS title=${details.title} status=${details.status} descriptionChars=${details.description?.length}")

        val chapters = source.chapters(details)
        assertFalse("At least one chapter record should be returned", chapters.isEmpty())
        val chapter = chapters.firstOrNull { it.language == "en" && it.externalUrl.isNullOrBlank() }
        assertNotNull("A chapter with MangaDex-hosted pages should be returned", chapter)
        chapter!!
        println("LIVE_CHAPTER_LIST count=${chapters.size} firstInternalId=${chapter.url} number=${chapter.number} language=${chapter.language}")

        val pages = source.pages(chapter)
        assertFalse("At least one real page URL should be returned", pages.isEmpty())
        assertTrue(pages.zipWithNext().all { (first, second) -> first.index < second.index })
        println("LIVE_AT_HOME status=200 chapter=${chapter.url} pages=${pages.size} first=${pages.first().imageUrl}")

        val imageClient = OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build()
        val imageRequest = Request.Builder().url(pages.first().imageUrl)
            .header("User-Agent", "MangaReplica/0.8 (Android public API client)")
            .build()
        imageClient.newCall(imageRequest).execute().use { response ->
            val body = response.body?.bytes() ?: ByteArray(0)
            assertTrue("MangaDex page image must return a successful response", response.isSuccessful)
            assertTrue("Page response must be an image", response.header("Content-Type").orEmpty().startsWith("image/"))
            assertTrue("Downloaded page must contain actual image bytes", body.size > 2_000)
            println("LIVE_IMAGE status=${response.code} contentType=${response.header("Content-Type")} bytes=${body.size}")
        }
    }

    @Test fun liveSoloLevelingShowsPublisherHostedAvailabilityWithoutInventingPages() = runBlocking {
        assumeTrue("Set MANGADEX_LIVE_TEST=1 to make public network requests", System.getenv("MANGADEX_LIVE_TEST") == "1")
        val source = MangaDexSource()
        val results = source.search("Solo Leveling", 0)
        val manga = results.firstOrNull { it.title.equals("Solo Leveling", ignoreCase = true) }
        assertNotNull("Search must match its English alternate title", manga)
        manga!!
        val chapters = source.chapters(source.details(manga))
        assertFalse("MangaDex should return chapter records", chapters.isEmpty())
        val externalChapters = chapters.filter { !it.externalUrl.isNullOrBlank() }
        println("LIVE_SOLO_LEVELING id=${manga.url} title=${manga.title} chapters=${chapters.size} publisherHosted=${externalChapters.size}")
        println("LIVE_SOLO_LEVELING_NOTE MangaDex chapter feed marks publisher-hosted chapters with externalUrl; no internal page images are fabricated.")
    }
}
