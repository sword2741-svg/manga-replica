package com.example.mangareplica.data.extensions

import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File
import java.util.zip.GZIPInputStream

class KeiyoushiIndexLiveIntegrationTest {
    @Test fun decodesDownloadedOfficialKeiyoushiIndex() {
        val path = System.getenv("KEIYOSHI_INDEX_FIXTURE")
        assumeTrue("Set KEIYOSHI_INDEX_FIXTURE to run the optional live-schema check", !path.isNullOrBlank())
        val bytes = File(path!!).readBytes()
        val decodedBytes = if (bytes.size > 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()) {
            GZIPInputStream(bytes.inputStream()).use { it.readBytes() }
        } else bytes
        val index = KeiyoushiIndexProto.decode(decodedBytes)
        assertTrue("The official index must include entries or a remote-list URL", index.entries.isNotEmpty() || !index.extensionListUrl.isNullOrBlank())
        assertTrue("The index should carry a repository name", index.name.isNotBlank())
        if (index.entries.isNotEmpty()) {
            assertTrue("Expected valid package names", index.entries.all { it.pkg.isNotBlank() })
            assertTrue("Expected APK resource URLs", index.entries.all { it.apk.startsWith("https://") })
        }
    }
}
