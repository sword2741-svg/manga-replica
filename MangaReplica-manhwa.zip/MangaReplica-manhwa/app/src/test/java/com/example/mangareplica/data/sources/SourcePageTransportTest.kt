package com.example.mangareplica.data.sources

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class SourcePageTransportTest {
    @Test
    fun loadPageSendsRefererCookieAndSourceHeaders() = runBlocking {
        val expected = byteArrayOf(0x11, 0x22, 0x33, 0x44)
        val server = ServerSocket(0)
        val receivedHeaders = java.util.concurrent.CompletableFuture<String>()
        val worker = thread(name = "source-page-test-server") {
            server.accept().use { socket ->
                val reader = BufferedReader(InputStreamReader(socket.getInputStream(), StandardCharsets.US_ASCII))
                val lines = mutableListOf<String>()
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    lines += line
                }
                receivedHeaders.complete(lines.joinToString("\n"))
                val header = "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nContent-Length: ${expected.size}\r\nConnection: close\r\n\r\n"
                socket.getOutputStream().apply {
                    write(header.toByteArray(StandardCharsets.US_ASCII))
                    write(expected)
                    flush()
                }
            }
        }

        try {
            val page = SourcePage(
                index = 0,
                imageUrl = "http://127.0.0.1:${server.localPort}/page.jpg",
                referer = "https://reader.example/work/chapter-1",
                headers = mapOf(
                    "User-Agent" to "MangaReplica-test-agent",
                    "Cookie" to "reader_session=active",
                    "Accept" to "image/jpeg",
                ),
            )
            val loaded = TestSource.loadPage(page)
            assertArrayEquals(expected, loaded)
            val headers = receivedHeaders.get(5, TimeUnit.SECONDS).lowercase()
            assertTrue(headers.contains("referer: https://reader.example/work/chapter-1"))
            assertTrue(headers.contains("cookie: reader_session=active"))
            assertTrue(headers.contains("user-agent: mangareplica-test-agent"))
            assertTrue(headers.contains("accept: image/jpeg"))
        } finally {
            server.close()
            worker.join(5_000)
        }
    }

    @Test
    fun loadPageReadsSavedChapterImageFromFileUri() = runBlocking {
        val expected = byteArrayOf(0x01, 0x02, 0x03)
        val file = java.io.File.createTempFile("mangareplica-page", ".img")
        try {
            file.writeBytes(expected)
            val page = SourcePage(index = 0, imageUrl = file.toURI().toString())
            assertArrayEquals(expected, TestSource.loadPage(page))
        } finally {
            file.delete()
        }
    }

    private object TestSource : MangaSource {
        override val id = "test-source"
        override val name = "Test source"
        override val language = "en"
        override suspend fun popular(page: Int) = emptyList<SourceManga>()
        override suspend fun search(query: String, page: Int) = emptyList<SourceManga>()
        override suspend fun details(manga: SourceManga) = manga
        override suspend fun chapters(manga: SourceManga) = emptyList<SourceChapter>()
        override suspend fun pages(chapter: SourceChapter) = emptyList<SourcePage>()
    }
}
