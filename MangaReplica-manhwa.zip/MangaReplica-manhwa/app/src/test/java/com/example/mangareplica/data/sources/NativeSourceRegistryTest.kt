package com.example.mangareplica.data.sources

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NativeSourceRegistryTest {
    @Test fun registersMangaDexByDefault() {
        val registry = NativeSourceRegistry()
        assertEquals("mangadex", registry.get("mangadex")?.id)
        assertNotNull(registry.get("mangadex"))
    }

    @Test fun registersTheSevenPrivateBuiltInWebsiteReaders() {
        val registry = NativeSourceRegistry()
        val builtIns = registry.all().filter { it.isBuiltIn }

        assertEquals(7, builtIns.size)
        assertEquals(
            setOf(
                "site:teamx", "site:mangalek", "site:mangalink-section", "site:procomic",
                "site:meshmanga", "site:lavascans", "site:hijala",
            ),
            builtIns.map { it.id }.toSet(),
        )
        assertTrue(builtIns.all { it.language == "ar" })
    }

    @Test fun sortsSourcesByDisplayNameAndResolvesById() {
        val zeta = TestSource("zeta", "Zeta")
        val alpha = TestSource("alpha", "Alpha")
        val registry = NativeSourceRegistry(listOf(zeta, alpha))
        assertEquals(listOf("alpha", "zeta"), registry.all().map { it.id })
        assertEquals(zeta, registry.get("zeta"))
        assertNull(registry.get("missing"))
    }

    private data class TestSource(override val id: String, override val name: String) : MangaSource {
        override val language = "en"
        override suspend fun popular(page: Int) = emptyList<SourceManga>()
        override suspend fun search(query: String, page: Int) = emptyList<SourceManga>()
        override suspend fun details(manga: SourceManga) = manga
        override suspend fun chapters(manga: SourceManga) = emptyList<SourceChapter>()
        override suspend fun pages(chapter: SourceChapter) = emptyList<SourcePage>()
    }
}
