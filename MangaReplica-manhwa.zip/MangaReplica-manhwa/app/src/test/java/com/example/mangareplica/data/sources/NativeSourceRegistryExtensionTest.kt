package com.example.mangareplica.data.sources

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test

class NativeSourceRegistryExtensionTest {
    private class FakeSource(override val id: String, override val name: String) : MangaSource {
        override val language: String = "ar"
        override suspend fun popular(page: Int) = emptyList<SourceManga>()
        override suspend fun search(query: String, page: Int) = emptyList<SourceManga>()
        override suspend fun details(manga: SourceManga) = manga
        override suspend fun chapters(manga: SourceManga) = emptyList<SourceChapter>()
        override suspend fun pages(chapter: SourceChapter) = emptyList<SourcePage>()
    }

    @Test
    fun loadedExtensionSourcesAreDiscoverableWithNativeSources() {
        val native = FakeSource("native", "MangaDex")
        val plugin = FakeSource("mihon:ar:42", "مصدر عربي")
        val registry = NativeSourceRegistry(listOf(native))

        registry.replaceExtensions(listOf(plugin))

        assertEquals(setOf("native", "mihon:ar:42"), registry.all().map { it.id }.toSet())
        assertSame(plugin, registry.find(plugin.id))
    }

    @Test
    fun identicalSourceInstalledFromMirrorsIsListedOnlyOnce() {
        val firstPackage = FakeSource("mihon:en:1234", "EnglishSource")
        val duplicatePackage = FakeSource("mihon:en:1234", "EnglishSource")
        val registry = NativeSourceRegistry(emptyList())

        registry.replaceExtensions(listOf(firstPackage, duplicatePackage))

        assertEquals(1, registry.all().size)
        assertSame(duplicatePackage, registry.find(firstPackage.id))
    }

    @Test
    fun replacingLoadedExtensionsRemovesUnloadedPackageSources() {
        val registry = NativeSourceRegistry(emptyList())
        val oldPlugin = FakeSource("mihon:ar:1", "قديم")
        registry.replaceExtensions(listOf(oldPlugin))

        registry.replaceExtensions(emptyList())

        assertNull(registry.find(oldPlugin.id))
        assertEquals(emptyList<MangaSource>(), registry.all())
    }
}
