package com.example.mangareplica.data.profile

import com.example.mangareplica.data.persistence.LibraryMangaEntity
import com.example.mangareplica.data.persistence.ReadingDayStatEntity
import com.example.mangareplica.data.persistence.ReadingProgressEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileStatsCalculatorTest {
    private val dayMs = 86_400_000L

    @Test
    fun dayOfRespectsTimeZoneOffset() {
        // 23:30 UTC on day 10 is already day 11 at UTC+1.
        val ts = 10 * dayMs + 23 * 3_600_000L + 30 * 60_000L
        assertEquals(10L, ProfileStatsCalculator.dayOf(ts, 0))
        assertEquals(11L, ProfileStatsCalculator.dayOf(ts, 3_600_000))
    }

    @Test
    fun dayOfWeekMatchesKnownDates() {
        assertEquals(4, ProfileStatsCalculator.dayOfWeek(0)) // 1970-01-01 Thursday
        assertEquals(0, ProfileStatsCalculator.dayOfWeek(3)) // Sunday
    }

    @Test
    fun streakCountsConsecutiveDaysEndingTodayOrYesterday() {
        val stats = listOf(ReadingDayStatEntity(98, 60), ReadingDayStatEntity(99, 60), ReadingDayStatEntity(100, 60), ReadingDayStatEntity(95, 60))
        val endingToday = ProfileStatsCalculator.compute(stats, emptyList(), emptyList(), today = 100, offsetMillis = 0)
        assertEquals(3, endingToday.streakDays)
        val endingYesterday = ProfileStatsCalculator.compute(stats, emptyList(), emptyList(), today = 101, offsetMillis = 0)
        assertEquals(3, endingYesterday.streakDays)
        val broken = ProfileStatsCalculator.compute(stats, emptyList(), emptyList(), today = 103, offsetMillis = 0)
        assertEquals(0, broken.streakDays)
    }

    @Test
    fun totalsWeekAndChaptersAreComputedFromHistory() {
        val stats = listOf(ReadingDayStatEntity(100, 600), ReadingDayStatEntity(97, 300), ReadingDayStatEntity(50, 1200))
        val progress = listOf(
            ReadingProgressEntity("s", "m", "c1", 5, isComplete = true, updatedAt = 100 * dayMs),
            ReadingProgressEntity("s", "m", "c2", 2, isComplete = false, updatedAt = 100 * dayMs),
        )
        val result = ProfileStatsCalculator.compute(stats, progress, emptyList(), today = 100, offsetMillis = 0)
        assertEquals(2100L, result.totalSeconds)
        assertEquals(900, result.weekSeconds)
        assertEquals(1, result.chaptersRead)
        assertEquals(7, result.weekBars.size)
        assertEquals(100L, result.weekBars.last().day)
    }

    @Test
    fun topGenresAreCountedAcrossReadWorks() {
        val library = listOf(
            LibraryMangaEntity("s", "a", "A", genres = "Action,Drama"),
            LibraryMangaEntity("s", "b", "B", genres = "Action"),
            LibraryMangaEntity("s", "c", "C", genres = null),
        )
        val result = ProfileStatsCalculator.compute(emptyList(), emptyList(), library, today = 1, offsetMillis = 0)
        assertEquals("Action" to 2, result.topGenres.first())
        assertTrue(result.topGenres.any { it.first == "Drama" })
    }

    @Test
    fun formatDurationUsesHoursAndMinutes() {
        assertEquals("0 د", ProfileStatsCalculator.formatDuration(20))
        assertEquals("45 د", ProfileStatsCalculator.formatDuration(45 * 60L))
        assertEquals("2 س 5 د", ProfileStatsCalculator.formatDuration(125 * 60L))
    }
}
