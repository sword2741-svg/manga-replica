package eu.kanade.tachiyomi.network

import okhttp3.Interceptor
import okhttp3.Response
import okhttp3.OkHttpClient
import org.junit.Assert.assertThrows
import org.junit.Test

class MihonClientContractTest {
    @Test
    fun acceptsKeiyoushiDefaultClientContract() {
        val client = OkHttpClient.Builder()
            .addInterceptor(UncaughtExceptionInterceptor())
            .addInterceptor(UserAgentInterceptor())
            .addInterceptor(CloudflareInterceptor())
            .build()

        MihonClientContract.verify(client)
    }

    @Test
    fun rejectsMissingCloudflareInterceptor() {
        val client = OkHttpClient.Builder()
            .addInterceptor(UncaughtExceptionInterceptor())
            .addInterceptor(UserAgentInterceptor())
            .build()

        assertThrows(IllegalStateException::class.java) {
            MihonClientContract.verify(client)
        }
    }

    @Test
    fun rejectsCompressionInterceptorsOnDefaultNetworkClient() {
        val client = OkHttpClient.Builder()
            .addInterceptor(UncaughtExceptionInterceptor())
            .addInterceptor(UserAgentInterceptor())
            .addInterceptor(CloudflareInterceptor())
            .addNetworkInterceptor(IgnoreGzipInterceptor())
            .build()

        assertThrows(IllegalStateException::class.java) {
            MihonClientContract.verify(client)
        }
    }

    @Test
    fun rejectsBrotliOnDefaultNetworkClient() {
        val client = OkHttpClient.Builder()
            .addInterceptor(UncaughtExceptionInterceptor())
            .addInterceptor(UserAgentInterceptor())
            .addInterceptor(CloudflareInterceptor())
            .addNetworkInterceptor(BrotliInterceptor())
            .build()

        assertThrows(IllegalStateException::class.java) {
            MihonClientContract.verify(client)
        }
    }
}

private class UncaughtExceptionInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response = chain.proceed(chain.request())
}

private class UserAgentInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response = chain.proceed(chain.request())
}

private class CloudflareInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response = chain.proceed(chain.request())
}

private class IgnoreGzipInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response = chain.proceed(chain.request())
}

private class BrotliInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response = chain.proceed(chain.request())
}
